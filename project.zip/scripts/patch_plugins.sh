#!/usr/bin/env bash
# Fixes third-party plugins that still resolve from the shut-down jcenter repo.
# jcenter.bintray.com now returns HTTP 403, which breaks plugin classpath
# resolution and aborts the build. Rewrites those references to mavenCentral().
# Currently affects: syncfusion_flutter_pdfviewer.
set -euo pipefail
PUB_CACHE="${PUB_CACHE:-$HOME/.pub-cache}"
fixed=0
while IFS= read -r f; do
  if grep -q 'jcenter()' "$f"; then
    echo "Patching $f"; sed -i 's/jcenter()/mavenCentral()/g' "$f"; fixed=$((fixed+1))
  fi
done < <(find "$PUB_CACHE/hosted/pub.dev" -maxdepth 3 -path '*/android/build.gradle' 2>/dev/null)
echo "Patched $fixed plugin file(s)."
