#!/usr/bin/env bash
# Build a release APK for EduSwap from a clean checkout.
# Requirements: Flutter 3.22+ (3.24 recommended), JDK 17, Android SDK
# (platform 34 + build-tools 34). Run from the repository root.
set -euo pipefail
cd "$(dirname "$0")/.."

echo "==> Checking Flutter"; flutter --version
echo "==> Generating platform folders (android/ etc.) if missing"
if [ ! -d "android" ]; then
  flutter create --platforms=android --org com.eduswap --project-name eduswap .
fi
echo "==> Applying Android build configuration"; ./scripts/configure_android.sh
echo "==> Installing packages"; flutter pub get
echo "==> Patching plugins that still reference the dead jcenter repo"; ./scripts/patch_plugins.sh
echo "==> Generating Freezed / json_serializable code"
dart run build_runner build --delete-conflicting-outputs

if [ ! -f "android/app/google-services.json" ]; then
  echo ""
  echo "!! android/app/google-services.json is missing."
  echo "!! Download it from Firebase Console > Project settings > Your apps,"
  echo "!! or run: flutterfire configure --project=<your-project-id>"
  exit 1
fi

echo "==> Building release APK"; flutter build apk --release
echo ""; echo "Done. APK is at: build/app/outputs/flutter-apk/app-release.apk"
