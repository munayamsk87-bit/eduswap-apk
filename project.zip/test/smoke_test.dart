import 'package:flutter_test/flutter_test.dart';
import 'package:eduswap/core/utils/validators.dart';

void main() {
  group('Validators', () {
    test('email rejects invalid input', () {
      expect(Validators.email('nope'), isNotNull);
      expect(Validators.email('student@example.com'), isNull);
    });
    test('password requires 8 characters', () {
      expect(Validators.password('short'), isNotNull);
      expect(Validators.password('longenough'), isNull);
    });
  });
}
