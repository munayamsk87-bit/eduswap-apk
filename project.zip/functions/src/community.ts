import { onCall } from 'firebase-functions/v2/https';
import { onDocumentCreated } from 'firebase-functions/v2/firestore';
import { HttpsError } from 'firebase-functions/v2/https';

import {
  db,
  FieldValue,
  requireAuth,
  assertString,
  claims,
  recordVoteGuard,
  awardReputation,
  createNotification,
} from './shared';

/** Upvote a question once per user. */
export const voteQuestion = onCall(async (req) => {
  const uid = requireAuth(req);
  const questionId = assertString(req.data.questionId, 'questionId', 128);

  const isNew = await recordVoteGuard(`q_${questionId}_${uid}`, uid);
  if (!isNew) {
    throw new HttpsError('already-exists', 'You already upvoted this question.');
  }

  const ref = db.collection('questions').doc(questionId);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError('not-found', 'Question not found.');
  await ref.update({ upvotes: FieldValue.increment(1) });

  const authorId = snap.get('authorId') as string;
  if (authorId && authorId !== uid) {
    await awardReputation({ userId: authorId, points: 1, reason: 'question_upvoted' });
  }
  return { ok: true };
});

/** Upvote an answer once per user. */
export const voteAnswer = onCall(async (req) => {
  const uid = requireAuth(req);
  const questionId = assertString(req.data.questionId, 'questionId', 128);
  const answerId = assertString(req.data.answerId, 'answerId', 128);

  const isNew = await recordVoteGuard(`a_${answerId}_${uid}`, uid);
  if (!isNew) {
    throw new HttpsError('already-exists', 'You already upvoted this answer.');
  }

  const ref = db
    .collection('questions').doc(questionId)
    .collection('answers').doc(answerId);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError('not-found', 'Answer not found.');
  await ref.update({ upvotes: FieldValue.increment(1) });

  const authorId = snap.get('authorId') as string;
  if (authorId && authorId !== uid) {
    await awardReputation({ userId: authorId, points: 1, reason: 'answer_upvoted' });
  }
  return { ok: true };
});

/** Mark an answer as the accepted solution — question owner or moderator only. */
export const acceptAnswer = onCall(async (req) => {
  const uid = requireAuth(req);
  const questionId = assertString(req.data.questionId, 'questionId', 128);
  const answerId = assertString(req.data.answerId, 'answerId', 128);

  const questionRef = db.collection('questions').doc(questionId);
  const snap = await questionRef.get();
  if (!snap.exists) throw new HttpsError('not-found', 'Question not found.');
  const token = claims(req);
  const isMod = token.admin === true || token.moderator === true;
  if (snap.get('authorId') !== uid && !isMod) {
    throw new HttpsError('permission-denied', 'Only the asker can accept an answer.');
  }

  const answers = questionRef.collection('answers');
  const previous = snap.get('acceptedAnswerId') as string | undefined;
  const batch = db.batch();
  if (previous && previous !== answerId) {
    batch.update(answers.doc(previous), { isAccepted: false });
  }
  batch.update(answers.doc(answerId), { isAccepted: true });
  batch.update(questionRef, { acceptedAnswerId: answerId });
  await batch.commit();

  const answerSnap = await answers.doc(answerId).get();
  const authorId = answerSnap.get('authorId') as string;
  if (authorId && authorId !== uid) {
    await awardReputation({ userId: authorId, points: 5, reason: 'answer_accepted' });
    await createNotification({
      userId: authorId,
      type: 'helpfulAnswer',
      title: 'Your answer was accepted',
      body: `Your answer on "${snap.get('title')}" was marked as the solution.`,
      data: { questionId },
    });
  }
  return { ok: true };
});

/** Notify the asker when a new answer arrives. */
export const onAnswerCreated = onDocumentCreated(
  'questions/{questionId}/answers/{answerId}',
  async (event) => {
    const answer = event.data?.data();
    if (!answer) return;
    const questionId = event.params.questionId;
    const question = await db.collection('questions').doc(questionId).get();
    const authorId = question.get('authorId') as string | undefined;
    if (!authorId || authorId === answer.authorId) return;
    await createNotification({
      userId: authorId,
      type: 'questionReply',
      title: 'New answer to your question',
      body: `${answer.authorName} answered "${question.get('title')}".`,
      data: { questionId },
    });
  }
);
