import * as functionsV1 from 'firebase-functions/v1';

import { db, storage } from './shared';

/**
 * Purge a departing user's data when their Auth record is deleted. Removes
 * their documents and Storage objects, keeping only what must be retained for
 * safety/audit (e.g. resolved reports reference the uid but hold no profile).
 *
 * Uses the v1 auth trigger, which is the stable deletion hook.
 */
export const onUserDeleted = functionsV1.auth.user().onDelete(async (user) => {
  const uid = user.uid;

  const batch = db.batch();
  batch.delete(db.collection('users').doc(uid));

  const [resources, saved, notifications] = await Promise.all([
    db.collection('resources').where('ownerId', '==', uid).get(),
    db.collection('savedResources').where('userId', '==', uid).get(),
    db.collection('notifications').where('userId', '==', uid).get(),
  ]);
  resources.docs.forEach((d) => batch.delete(d.ref));
  saved.docs.forEach((d) => batch.delete(d.ref));
  notifications.docs.forEach((d) => batch.delete(d.ref));

  await batch.commit();

  // Remove their uploaded files from Storage.
  const bucket = storage.bucket();
  for (const prefix of [
    `resource_files/${uid}/`,
    `avatars/${uid}/`,
    `covers/${uid}/`,
  ]) {
    await bucket.deleteFiles({ prefix });
  }
});
