import { onCall } from 'firebase-functions/v2/https';
import { onDocumentCreated } from 'firebase-functions/v2/firestore';
import { HttpsError } from 'firebase-functions/v2/https';

import {
  db,
  FieldValue,
  requireAuth,
  assertString,
  optionalString,
  createNotification,
  awardReputation,
} from './shared';

type SwapStatus =
  | 'requested'
  | 'accepted'
  | 'declined'
  | 'cancelled'
  | 'completed'
  | 'expired'
  | 'disputed';

/**
 * Create a non-monetary swap request. Rejects duplicate live requests for the
 * same resource by the same requester, and blocks self-swaps.
 */
export const createSwapRequest = onCall(async (req) => {
  const uid = requireAuth(req);
  const resourceId = assertString(req.data.resourceId, 'resourceId', 128);
  const requesterName = assertString(req.data.requesterName, 'requesterName', 120);
  const message = optionalString(req.data.message) ?? '';

  const resourceRef = db.collection('resources').doc(resourceId);
  const resource = await resourceRef.get();
  if (!resource.exists) {
    throw new HttpsError('not-found', 'Resource not found.');
  }
  const ownerId = resource.get('ownerId') as string;
  if (ownerId === uid) {
    throw new HttpsError('failed-precondition', 'You cannot swap with yourself.');
  }
  if (resource.get('type') !== 'physicalBook') {
    throw new HttpsError('failed-precondition', 'Only physical books can be swapped.');
  }

  // Duplicate-request prevention: one live request per requester+resource.
  const dupes = await db
    .collection('swapRequests')
    .where('resourceId', '==', resourceId)
    .where('requesterId', '==', uid)
    .where('status', 'in', ['requested', 'accepted'])
    .limit(1)
    .get();
  if (!dupes.empty) {
    throw new HttpsError('already-exists', 'You already have a live request for this book.');
  }

  const ref = db.collection('swapRequests').doc();
  const expires = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000); // 14 days
  await ref.set({
    id: ref.id,
    resourceId,
    resourceTitle: resource.get('title') ?? '',
    requesterId: uid,
    requesterName,
    ownerId,
    ownerName: resource.get('ownerName') ?? '',
    offeredResourceId: optionalString(req.data.offeredResourceId, 128),
    offeredResourceTitle: optionalString(req.data.offeredResourceTitle, 200),
    message,
    status: 'requested' as SwapStatus,
    participants: [uid, ownerId],
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
    expiresAt: expires,
  });

  await createNotification({
    userId: ownerId,
    type: 'newSwapRequest',
    title: 'New swap request',
    body: `${requesterName} wants to swap "${resource.get('title')}".`,
    data: { swapRequestId: ref.id },
  });

  return { id: ref.id };
});

/**
 * Server-validated state machine. Only the correct party may trigger each
 * transition, so neither student can forge the other's action.
 */
export const transitionSwapRequest = onCall(async (req) => {
  const uid = requireAuth(req);
  const requestId = assertString(req.data.requestId, 'requestId', 128);
  const action = assertString(req.data.action, 'action', 32);

  const ref = db.collection('swapRequests').doc(requestId);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists) {
      throw new HttpsError('not-found', 'Swap request not found.');
    }
    const data = snap.data()!;
    const status = data.status as SwapStatus;
    const isOwner = data.ownerId === uid;
    const isRequester = data.requesterId === uid;
    if (!isOwner && !isRequester) {
      throw new HttpsError('permission-denied', 'You are not part of this swap.');
    }

    let next: SwapStatus;
    switch (action) {
      case 'accept':
        if (!isOwner || status !== 'requested') {
          throw new HttpsError('failed-precondition', 'Only the owner can accept a pending request.');
        }
        next = 'accepted';
        break;
      case 'decline':
        if (!isOwner || status !== 'requested') {
          throw new HttpsError('failed-precondition', 'Only the owner can decline a pending request.');
        }
        next = 'declined';
        break;
      case 'cancel':
        if (!isRequester || !['requested', 'accepted'].includes(status)) {
          throw new HttpsError('failed-precondition', 'Only the requester can cancel.');
        }
        next = 'cancelled';
        break;
      case 'complete':
        if (!['accepted'].includes(status)) {
          throw new HttpsError('failed-precondition', 'Only an accepted swap can be completed.');
        }
        next = 'completed';
        break;
      case 'dispute':
        next = 'disputed';
        break;
      default:
        throw new HttpsError('invalid-argument', `Unknown action: ${action}`);
    }

    tx.update(ref, { status: next, updatedAt: FieldValue.serverTimestamp() });
  });

  const after = await ref.get();
  const data = after.data()!;
  const other = uid === data.ownerId ? data.requesterId : data.ownerId;
  const titles: Record<string, string> = {
    accepted: 'Swap accepted',
    declined: 'Swap declined',
    cancelled: 'Swap cancelled',
    completed: 'Swap completed',
    disputed: 'Swap disputed',
  };
  if (titles[action]) {
    await createNotification({
      userId: other,
      type: action === 'accepted' ? 'swapAccepted' : 'swapDeclined',
      title: titles[action],
      body: `Regarding "${data.resourceTitle}".`,
      data: { swapRequestId: requestId },
    });
  }
  if (action === 'complete') {
    await awardReputation({ userId: data.ownerId, points: 2, reason: 'swap_completed' });
    await awardReputation({ userId: data.requesterId, points: 2, reason: 'swap_completed' });
  }

  return { status: after.get('status') };
});

/** Optional feedback after a completed swap. */
export const submitSwapFeedback = onCall(async (req) => {
  const uid = requireAuth(req);
  const requestId = assertString(req.data.requestId, 'requestId', 128);
  const rating = Number(req.data.rating);
  if (!Number.isFinite(rating) || rating < 1 || rating > 5) {
    throw new HttpsError('invalid-argument', 'Rating must be between 1 and 5.');
  }
  const feedback = optionalString(req.data.feedback, 1000) ?? '';

  const ref = db.collection('swapRequests').doc(requestId);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError('not-found', 'Swap request not found.');
  const data = snap.data()!;
  if (data.status !== 'completed') {
    throw new HttpsError('failed-precondition', 'You can leave feedback after completion.');
  }
  const isOwner = data.ownerId === uid;
  const isRequester = data.requesterId === uid;
  if (!isOwner && !isRequester) {
    throw new HttpsError('permission-denied', 'You are not part of this swap.');
  }
  await ref.update({
    [isOwner ? 'ownerRating' : 'requesterRating']: rating,
    [isOwner ? 'ownerFeedback' : 'requesterFeedback']: feedback,
    updatedAt: FieldValue.serverTimestamp(),
  });
  return { ok: true };
});

/** Safety net for swap requests created through any trusted path. */
export const onSwapRequestCreated = onDocumentCreated(
  'swapRequests/{requestId}',
  async (event) => {
    // Notifications are sent inside createSwapRequest. This trigger exists so
    // delivery can be retried/extended without touching the client, and it
    // keeps a lightweight server-side log of swap activity.
    console.log('swapRequest created', event.params.requestId);
  }
);
