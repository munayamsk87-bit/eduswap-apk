import { onCall } from 'firebase-functions/v2/https';
import { HttpsError } from 'firebase-functions/v2/https';

import { db, FieldValue, requireAuth, assertString, optionalString } from './shared';

const MAX_REQUESTS_PER_HOUR = 20;
const MAX_INPUT_CHARS = 8000;

const TASK_PROMPTS: Record<string, string> = {
  explain: 'Explain the following concept in simple, accurate language.',
  summarize: 'Summarize the following study notes into concise key points.',
  practiceQuestions: 'Create 5 practice questions on the following topic.',
  generateMcq: 'Create 5 multiple-choice questions with answers and explanations.',
  explainMistake: 'Explain what is wrong in the following answer and how to fix it.',
  revisionNotes: 'Produce short revision notes for the following topic.',
  studyPlan: 'Build a realistic study plan for the following goal.',
  flashcards: 'Create 8 flashcards (question/answer pairs) for the following topic.',
  translate: 'Translate the following into the requested language, keeping meaning.',
};

/** Simple per-user hourly rate limit backed by Firestore. */
async function checkRateLimit(uid: string): Promise<void> {
  const hourKey = new Date().toISOString().slice(0, 13); // YYYY-MM-DDTHH
  const ref = db
    .collection('users').doc(uid)
    .collection('aiUsage').doc(hourKey);
  const snap = await ref.get();
  const count = (snap.get('count') as number | undefined) ?? 0;
  if (count >= MAX_REQUESTS_PER_HOUR) {
    throw new HttpsError(
      'resource-exhausted',
      'You have reached the hourly limit for the AI assistant. Please try again later.'
    );
  }
  await ref.set({ count: FieldValue.increment(1) }, { merge: true });
}

async function callGemini(prompt: string, apiKey: string): Promise<string> {
  const url =
    'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';
  const res = await fetch(`${url}?key=${apiKey}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.4, maxOutputTokens: 1024 },
    }),
  });
  if (!res.ok) {
    throw new HttpsError('internal', `AI provider error (${res.status}).`);
  }
  const json = (await res.json()) as any;
  return (
    json?.candidates?.[0]?.content?.parts?.[0]?.text ??
    'The assistant returned no text.'
  );
}

async function callOpenAI(prompt: string, apiKey: string): Promise<string> {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: [{ role: 'user', content: prompt }],
      max_tokens: 1024,
    }),
  });
  if (!res.ok) {
    throw new HttpsError('internal', `AI provider error (${res.status}).`);
  }
  const json = (await res.json()) as any;
  return json?.choices?.[0]?.message?.content ?? 'The assistant returned no text.';
}

/**
 * Secure AI proxy. Keys live only here (env vars), never in the app. If no
 * provider is configured the function reports `configured: false` rather than
 * pretending AI works.
 */
export const aiAssistant = onCall(
  { secrets: [], timeoutSeconds: 60 },
  async (req) => {
    const uid = requireAuth(req);
    const task = assertString(req.data.task, 'task', 40);
    const input = assertString(req.data.input, 'input', MAX_INPUT_CHARS);
    const level = optionalString(req.data.level, 40) ?? 'secondary';
    const language = optionalString(req.data.language, 20) ?? 'english';

    const geminiKey = process.env.GEMINI_API_KEY;
    const openaiKey = process.env.OPENAI_API_KEY;
    if (!geminiKey && !openaiKey) {
      return { configured: false, text: '' };
    }

    await checkRateLimit(uid);

    const instruction = TASK_PROMPTS[task] ?? TASK_PROMPTS.explain;
    const prompt = [
      'You are EduSwap\'s study assistant for school and college students.',
      'Answer accurately and clearly. Never claim certainty you do not have,',
      'and never help with exam cheating.',
      `Target education level: ${level}.`,
      `Preferred language: ${language}.`,
      instruction,
      '',
      input,
    ].join('\n');

    const text = geminiKey
      ? await callGemini(prompt, geminiKey)
      : await callOpenAI(prompt, openaiKey as string);

    return { configured: true, text };
  }
);
