/**
 * EduSwap Cloud Functions — trusted backend entry point.
 *
 * Every privileged operation lives here so the client can never forge a state
 * transition, counter, role or notification. API keys stay in the environment.
 */
export {
  createSwapRequest,
  transitionSwapRequest,
  submitSwapFeedback,
  onSwapRequestCreated,
} from './swaps';

export { toggleSaveResource, getResourceAccess, moderateResource } from './resources';

export { voteQuestion, voteAnswer, acceptAnswer, onAnswerCreated } from './community';

export {
  getAdminDashboard,
  resolveReport,
  setUserSuspended,
  setAdminClaim,
} from './admin';

export { aiAssistant } from './ai';

export { onMessageCreated } from './notifications';

export { onUserDeleted } from './account';
