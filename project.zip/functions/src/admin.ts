import { onCall } from 'firebase-functions/v2/https';
import { HttpsError } from 'firebase-functions/v2/https';

import {
  db,
  auth,
  FieldValue,
  requireAdmin,
  requireModerator,
  assertString,
  optionalString,
  audit,
  createNotification,
} from './shared';

/** Server-derived dashboard counts — the client never counts whole collections. */
export const getAdminDashboard = onCall(async (req) => {
  requireModerator(req);

  const count = async (
    col: string,
    field: string,
    value: string
  ): Promise<number> => {
    const snap = await db.collection(col).where(field, '==', value).count().get();
    return snap.data().count;
  };

  const [totalUsers, pendingResources, approvedResources, openReports] =
    await Promise.all([
      db.collection('users').count().get().then((s) => s.data().count),
      count('resources', 'status', 'pendingReview'),
      count('resources', 'status', 'approved'),
      count('reports', 'status', 'open'),
    ]);

  return {
    totalUsers,
    pendingResources,
    approvedResources,
    reportedResources: openReports,
    openReports,
  };
});

/** Resolve or dismiss a report. Moderator-only and audit-logged. */
export const resolveReport = onCall(async (req) => {
  const uid = requireModerator(req);
  const reportId = assertString(req.data.reportId, 'reportId', 128);
  const resolution = assertString(req.data.resolution, 'resolution', 40);
  const note = optionalString(req.data.note, 500) ?? '';

  const ref = db.collection('reports').doc(reportId);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError('not-found', 'Report not found.');

  await ref.update({
    status: resolution === 'dismissed' ? 'dismissed' : 'resolved',
    resolvedBy: uid,
    resolutionNote: note,
    resolvedAt: FieldValue.serverTimestamp(),
  });

  await audit({
    actorId: uid,
    action: 'report.resolve',
    targetType: 'report',
    targetId: reportId,
    note,
  });

  await createNotification({
    userId: snap.get('reporterId') as string,
    type: 'reportResolution',
    title: 'Your report was reviewed',
    body: note || 'Thanks for helping keep EduSwap safe.',
    data: { reportId },
  });

  return { ok: true };
});

/** Suspend or restore an account. Admin-only, audit-logged. */
export const setUserSuspended = onCall(async (req) => {
  const uid = requireAdmin(req);
  const userId = assertString(req.data.userId, 'userId', 128);
  const suspended = req.data.suspended === true;

  await db.collection('users').doc(userId).set(
    { isSuspended: suspended, updatedAt: FieldValue.serverTimestamp() },
    { merge: true }
  );
  await auth.updateUser(userId, { disabled: suspended });

  await audit({
    actorId: uid,
    action: suspended ? 'user.suspend' : 'user.restore',
    targetType: 'user',
    targetId: userId,
  });

  await createNotification({
    userId,
    type: 'accountSecurity',
    title: suspended ? 'Your account was suspended' : 'Your account was restored',
    body: 'Contact support if you believe this is a mistake.',
  });

  return { suspended };
});

/**
 * Grant or revoke privileged roles via custom claims. Roles are NEVER set from
 * a client-editable profile field — only here, by an existing admin.
 */
export const setAdminClaim = onCall(async (req) => {
  const uid = requireAdmin(req);
  const targetUid = assertString(req.data.targetUid, 'targetUid', 128);
  const role = assertString(req.data.role, 'role', 20); // admin | moderator | student

  const claims: Record<string, boolean> = { admin: false, moderator: false };
  if (role === 'admin') claims.admin = true;
  else if (role === 'moderator') claims.moderator = true;
  else if (role !== 'student') {
    throw new HttpsError('invalid-argument', 'Unknown role.');
  }

  await auth.setCustomUserClaims(targetUid, claims);
  await db.collection('users').doc(targetUid).set({ role }, { merge: true });

  await audit({
    actorId: uid,
    action: 'role.set',
    targetType: 'user',
    targetId: targetUid,
    note: role,
  });

  return { role };
});
