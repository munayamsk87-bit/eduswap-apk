import * as admin from 'firebase-admin';
import { HttpsError, CallableRequest } from 'firebase-functions/v2/https';

admin.initializeApp();

export const db = admin.firestore();
export const auth = admin.auth();
export const storage = admin.storage();
export const FieldValue = admin.firestore.FieldValue;

/** Throw unless the caller is signed in. Returns the uid. */
export function requireAuth(req: CallableRequest): string {
  if (!req.auth) {
    throw new HttpsError('unauthenticated', 'Please sign in.');
  }
  return req.auth.uid;
}

/** Read the caller's custom claims as a plain record. */
export function claims(req: CallableRequest): Record<string, unknown> {
  return (req.auth?.token ?? {}) as Record<string, unknown>;
}

/** Throw unless the caller carries the admin custom claim. */
export function requireAdmin(req: CallableRequest): string {
  const uid = requireAuth(req);
  if (claims(req).admin !== true) {
    throw new HttpsError('permission-denied', 'Admin access required.');
  }
  return uid;
}

/** Throw unless the caller carries admin or moderator. */
export function requireModerator(req: CallableRequest): string {
  const uid = requireAuth(req);
  const token = claims(req);
  if (token.admin !== true && token.moderator !== true) {
    throw new HttpsError('permission-denied', 'Moderator access required.');
  }
  return uid;
}

export function assertString(value: unknown, field: string, max = 2000): string {
  if (typeof value !== 'string' || value.trim().length === 0) {
    throw new HttpsError('invalid-argument', `${field} is required.`);
  }
  if (value.length > max) {
    throw new HttpsError('invalid-argument', `${field} is too long.`);
  }
  return value.trim();
}

export function optionalString(value: unknown, max = 2000): string | null {
  if (value == null) return null;
  if (typeof value !== 'string') return null;
  return value.slice(0, max);
}

/** Write an in-app notification. Backend-only; FCM is sent separately. */
export async function createNotification(params: {
  userId: string;
  type: string;
  title: string;
  body?: string;
  data?: Record<string, string>;
}): Promise<void> {
  const ref = db.collection('notifications').doc();
  await ref.set({
    id: ref.id,
    userId: params.userId,
    type: params.type,
    title: params.title,
    body: params.body ?? '',
    data: params.data ?? {},
    read: false,
    createdAt: FieldValue.serverTimestamp(),
  });
}

/** Append an entry to the immutable admin audit log. */
export async function audit(params: {
  actorId: string;
  action: string;
  targetType: string;
  targetId: string;
  note?: string;
}): Promise<void> {
  await db.collection('adminAuditLogs').add({
    ...params,
    note: params.note ?? '',
    createdAt: FieldValue.serverTimestamp(),
  });
}

/** Award non-monetary reputation points (clamped) and record the event. */
export async function awardReputation(params: {
  userId: string;
  points: number;
  reason: string;
}): Promise<void> {
  const userRef = db.collection('users').doc(params.userId);
  await userRef.set(
    { reputation: FieldValue.increment(params.points) },
    { merge: true }
  );
  await db.collection('reputationEvents').add({
    userId: params.userId,
    points: params.points,
    reason: params.reason,
    createdAt: FieldValue.serverTimestamp(),
  });
}

/** Deduplicate a vote by user+target using a deterministic guard doc id. */
export async function recordVoteGuard(
  guardId: string,
  userId: string
): Promise<boolean> {
  const ref = db.collection('voteGuards').doc(guardId);
  try {
    await ref.create({ userId, createdAt: FieldValue.serverTimestamp() });
    return true; // first vote
  } catch {
    return false; // already voted
  }
}
