import { onDocumentCreated } from 'firebase-functions/v2/firestore';
import * as admin from 'firebase-admin';

import { db, createNotification } from './shared';

/**
 * When a chat message is created, bump the conversation preview is already
 * handled client-side; here we notify the recipient in-app and via FCM.
 */
export const onMessageCreated = onDocumentCreated(
  'conversations/{conversationId}/messages/{messageId}',
  async (event) => {
    const message = event.data?.data();
    if (!message) return;
    const conversationId = event.params.conversationId;

    const convo = await db
      .collection('conversations')
      .doc(conversationId)
      .get();
    if (!convo.exists) return;
    const participants = (convo.get('participants') as string[]) ?? [];
    const senderId = message.senderId as string;
    const recipients = participants.filter((p) => p !== senderId);
    if (recipients.length === 0) return;

    const preview =
      (message.text as string | undefined)?.slice(0, 80) ??
      (message.imageUrl ? 'Photo' : 'New message');

    for (const recipient of recipients) {
      await createNotification({
        userId: recipient,
        type: 'newMessage',
        title: message.senderName ?? 'New message',
        body: preview,
        data: { conversationId },
      });
      await sendPush(recipient, message.senderName ?? 'New message', preview, {
        conversationId,
      });
    }
  }
);

/** Deliver an FCM push to every device token registered for a user. */
async function sendPush(
  userId: string,
  title: string,
  body: string,
  data: Record<string, string>
): Promise<void> {
  const userSnap = await db.collection('users').doc(userId).get();
  const tokens = (userSnap.get('fcmTokens') as string[] | undefined) ?? [];
  if (tokens.length === 0) return;

  const res = await admin.messaging().sendEachForMulticast({
    tokens,
    notification: { title, body },
    data,
  });

  // Prune tokens that are no longer valid so the list stays clean.
  const stale: string[] = [];
  res.responses.forEach((r, i) => {
    if (!r.success) stale.push(tokens[i]);
  });
  if (stale.length > 0) {
    await db
      .collection('users')
      .doc(userId)
      .update({
        fcmTokens: admin.firestore.FieldValue.arrayRemove(...stale),
      });
  }
}
