import { onCall } from 'firebase-functions/v2/https';
import { HttpsError } from 'firebase-functions/v2/https';

import {
  db,
  storage,
  FieldValue,
  requireAuth,
  requireModerator,
  assertString,
  optionalString,
  claims,
  awardReputation,
  createNotification,
} from './shared';

/**
 * Toggle a wishlist save. Runs in a transaction so the resource's `saveCount`
 * can never drift, and uses a deterministic id so a user cannot save twice.
 */
export const toggleSaveResource = onCall(async (req) => {
  const uid = requireAuth(req);
  const resourceId = assertString(req.data.resourceId, 'resourceId', 128);
  const savedId = `${uid}_${resourceId}`;

  const savedRef = db.collection('savedResources').doc(savedId);
  const resourceRef = db.collection('resources').doc(resourceId);

  const saved = await db.runTransaction(async (tx) => {
    const [savedSnap, resourceSnap] = await Promise.all([
      tx.get(savedRef),
      tx.get(resourceRef),
    ]);
    if (!resourceSnap.exists) {
      throw new HttpsError('not-found', 'Resource not found.');
    }
    if (savedSnap.exists) {
      tx.delete(savedRef);
      tx.update(resourceRef, { saveCount: FieldValue.increment(-1) });
      return false;
    }
    tx.set(savedRef, {
      id: savedId,
      userId: uid,
      resourceId,
      resourceTitle: optionalString(req.data.resourceTitle, 200) ?? '',
      coverUrl: optionalString(req.data.coverUrl, 500),
      savedAt: FieldValue.serverTimestamp(),
    });
    tx.update(resourceRef, { saveCount: FieldValue.increment(1) });
    return true;
  });

  // Small, non-monetary reward to the uploader when someone saves their work.
  if (saved) {
    const ownerId = (await resourceRef.get()).get('ownerId') as string | undefined;
    if (ownerId && ownerId !== uid) {
      await awardReputation({ userId: ownerId, points: 1, reason: 'resource_saved' });
    }
  }
  return { saved };
});

/**
 * Authorize a download and return a short-lived signed URL. Restricted files
 * are never exposed by a permanent public link; this is the only path to them.
 */
export const getResourceAccess = onCall(async (req) => {
  const uid = requireAuth(req);
  const resourceId = assertString(req.data.resourceId, 'resourceId', 128);

  const snap = await db.collection('resources').doc(resourceId).get();
  if (!snap.exists) throw new HttpsError('not-found', 'Resource not found.');
  const data = snap.data()!;
  const filePath = data.filePath as string | undefined;
  if (!filePath) throw new HttpsError('not-found', 'This resource has no file.');

  const isOwner = data.ownerId === uid;
  const approved = data.status === 'approved';
  const token = claims(req);
  const isMod = token.admin === true || token.moderator === true;
  if (!approved && !isOwner && !isMod) {
    throw new HttpsError('permission-denied', 'This resource is not available yet.');
  }

  const [url] = await storage.bucket().file(filePath).getSignedUrl({
    action: 'read',
    expires: Date.now() + 15 * 60 * 1000, // 15 minutes
  });

  await db.collection('resources').doc(resourceId).update({
    downloadCount: FieldValue.increment(1),
  });

  return { url };
});

/**
 * Approve or reject a pending resource. Moderator-only, audit-logged, and it
 * notifies the uploader of the outcome.
 */
export const moderateResource = onCall(async (req) => {
  const uid = requireModerator(req);
  const resourceId = assertString(req.data.resourceId, 'resourceId', 128);
  const approve = req.data.approve === true;
  const note = optionalString(req.data.note, 500) ?? '';

  const ref = db.collection('resources').doc(resourceId);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError('not-found', 'Resource not found.');
  const ownerId = snap.get('ownerId') as string;

  await ref.update({
    status: approve ? 'approved' : 'rejected',
    moderationNote: note,
    updatedAt: FieldValue.serverTimestamp(),
  });

  await db.collection('adminAuditLogs').add({
    actorId: uid,
    action: approve ? 'resource.approve' : 'resource.reject',
    targetType: 'resource',
    targetId: resourceId,
    note,
    createdAt: FieldValue.serverTimestamp(),
  });

  await createNotification({
    userId: ownerId,
    type: 'moderationResult',
    title: approve ? 'Your resource is live' : 'Your resource was not approved',
    body: approve
      ? `"${snap.get('title')}" is now visible to students.`
      : note || 'It did not meet the community guidelines.',
    data: { resourceId },
  });

  if (approve) {
    await awardReputation({ userId: ownerId, points: 5, reason: 'resource_approved' });
  }

  return { status: approve ? 'approved' : 'rejected' };
});
