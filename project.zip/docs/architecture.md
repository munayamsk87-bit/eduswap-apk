# EduSwap — architecture

## Layers

```
presentation   →  screens & widgets (ConsumerWidget / ConsumerStatefulWidget)
                 read state from Riverpod providers, never touch Firebase directly
      ↓
state           →  providers (shared/providers) — auth, feeds, settings
                 expose AsyncValue<T> streams and Futures to the UI
      ↓
data            →  repositories (features/*/data) — the only place that talks
                 to Firestore / Storage / Functions
      ↓
domain          →  Freezed models (shared/models) — immutable, json-serializable
      ↓
backend         →  Cloud Functions (functions/src) — all trusted mutations
```

The presentation layer never imports `cloud_firestore` or `firebase_auth`.
Repositories own those dependencies and expose plain Dart types, which keeps
screens testable and lets you swap an implementation (e.g. an emulator-backed
one) without touching the UI.

## State management

- **Riverpod** providers wrap the Firebase SDKs (`firebase_providers.dart`) and
  the repositories (`repositoryProvider` in each data file).
- Live data is exposed as `StreamProvider`s (`feed_providers.dart`); one-shot
  reads as `FutureProvider`s.
- Screens render `AsyncValue<T>` through `AsyncValueView`, which centralizes
  loading / empty / error / retry behaviour so every list behaves the same way.

## Navigation

- **GoRouter** with a `StatefulShellRoute.indexedStack` for the five primary
  tabs (Home, Explore, Add, Chat, Profile) so the bottom bar persists and each
  tab keeps its own stack.
- All other screens are pushed routes (`/resource/:id`, `/question/:id`,
  `/swaps`, `/ai`, `/chat-room/:id`, `/admin`, …).
- A single `redirect` gate protects everything except splash, onboarding, login,
  register and password reset — unauthenticated users can never land on a
  protected screen.

## Security model

**Nothing important is trusted to the client.**

| Concern | Enforced by |
|---|---|
| Who can read/write a document | Firestore Security Rules |
| Who can read/write a file | Storage Rules + signed URLs |
| Swap state transitions | `transitionSwapRequest` (validates the actor per action) |
| Vote/save counters | `toggleSaveResource`, `voteQuestion`, `voteAnswer` (transactional) |
| Accepted answers | `acceptAnswer` (asker or moderator only) |
| Moderation outcomes | `moderateResource` (moderator claim, audit-logged) |
| Roles / admin | Firebase **custom claims** set only by `setAdminClaim` |
| Notifications | written only by backend triggers |
| AI keys | server-only env secrets; app never sees them |

A hidden button is not security: every privileged Cloud Function re-verifies
the caller's custom claims, and the rules independently reject direct writes to
server-managed fields (status, counters, role, reputation, badges).

## Key flows

**Upload → review → live.** A signed-in student uploads a file to
`resource_files/{uid}/{resourceId}/…` (size + MIME validated client-side and by
Storage Rules), the doc is created with `status: pendingReview`, a moderator
approves via `moderateResource`, and the owner is notified. Files are never
publicly readable — `getResourceAccess` issues a 15-minute signed URL only after
an authorization check.

**Book swap.** `createSwapRequest` blocks self-swaps and duplicate live
requests, then notifies the owner. Every later transition
(accept/decline/cancel/complete/dispute) is validated against the caller's role
in `transitionSwapRequest`; neither party can forge the other's action.
Completion awards non-monetary reputation.

**Chat.** Conversations use deterministic ids and enforce membership in both
the rules and the messages subcollection. Sending a message writes the message
and bumps the preview + the recipient's unread count in one batch; an
`onMessageCreated` trigger sends in-app + FCM notifications.

**AI assistant.** The app calls the `aiAssistant` function; keys live in the
function environment. If unconfigured, the function returns
`{configured:false}` and the UI explains how to enable it — the app never
pretends AI is working. Requests are rate-limited per user per hour.

## Non-negotiables

- **No monetization.** No payment, wallet, subscription or gateway code exists,
  and the data model has no place to put one.
- **Privacy for minors.** Approximate locality only; no precise location, no
  published contact details, no public leaderboards that expose personal data.
- **Copyright.** Uploads are framed as "only content you have permission to
  share", with a report/takedown path via the reports collection.
