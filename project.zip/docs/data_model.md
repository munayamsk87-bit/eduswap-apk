# EduSwap — Firestore data model

Server timestamps, stable document IDs, validated fields, and no large files
(or base64 blobs) inside documents. Files live in Cloud Storage; documents hold
metadata and storage paths only.

## Collections

### `users/{uid}`
Public-facing profile. Private settings live in a subcollection.

| field | type | notes |
|---|---|---|
| uid | string | equals the Auth uid |
| displayName | string | |
| email | string | |
| photoUrl | string? | |
| educationLevel | enum name | primary … postgraduate |
| institution | string? | optional |
| board | string? | optional |
| preferredLanguage | enum name | english / bengali / hindi |
| subjects | string[] | interests for personalization |
| interests | string[] | skills the student wants to learn |
| locality | string? | **approximate only** |
| role | string | display only — authz uses custom claims |
| reputation | int | server-managed |
| badges | string[] | server-managed |
| isSuspended | bool | server-managed |
| onboardingComplete | bool | |
| createdAt / updatedAt | timestamp | server timestamps |
| fcmTokens | string[] | device tokens, pruned by backend |

`users/{uid}/settings/{docId}` — private prefs, owner-only.
`users/{uid}/aiUsage/{YYYY-MM-DDTHH}` — hourly AI rate-limit counter.

### `resources/{resourceId}`
An educational listing (book, notes, paper, worksheet…).

Key fields: `ownerId`, `ownerName`, `title`, `titleLower` (prefix search),
`description`, `type` (enum), `category`, `subject`, `educationLevel`, `board`,
`language`, `tags[]`, `coverUrl`, `filePath` (Storage path — the only way to
reach the file), `fileSizeBytes`, `mimeType`, `bookAuthor`, `condition`,
`exchangeLocality`, `swapPreferences[]`, `available`, `status`
(draft/pendingReview/approved/rejected/removed), `moderationNote`,
`saveCount`, `downloadCount`, `createdAt`, `updatedAt`.

### `swapRequests/{requestId}`
`resourceId`, `resourceTitle`, `requesterId`, `requesterName`, `ownerId`,
`ownerName`, `offeredResourceId?`, `offeredResourceTitle?`, `message`, `status`
(requested/accepted/declined/cancelled/completed/expired/disputed),
`participants[]`, optional ratings/feedback, `createdAt`, `updatedAt`,
`expiresAt`. **All transitions are applied by Cloud Functions.**

### `conversations/{conversationId}`
Deterministic id `{uidA}_{uidB}` (sorted) plus `_{resourceId}` when linked.
Fields: `participants[]`, `participantNames{uid:name}`, `resourceId?`,
`swapRequestId?`, `lastMessage`, `unread{uid:int}`, `lastMessageAt`, `createdAt`.

`conversations/{id}/messages/{messageId}` — `senderId`, `senderName`, `text?`,
`imageUrl?`, `replyToId?`, `readBy[]`, `createdAt`.

### `questions/{questionId}`
`authorId`, `authorName`, `authorPhotoUrl`, `title`, `body`, `subject`,
`educationLevel`, `imageUrl?`, `tags[]`, `upvotes`, `answerCount`,
`acceptedAnswerId?`, `createdAt`.

`questions/{id}/answers/{answerId}` — `authorId`, `authorName`, `body`,
`imageUrl?`, `upvotes`, `isAccepted`, `createdAt`.

### `savedResources/{userId}_{resourceId}`
`userId`, `resourceId`, `resourceTitle`, `coverUrl`, `savedAt`. Deterministic id
prevents duplicate saves; `saveCount` is adjusted by `toggleSaveResource`.

### `skillListings/{listingId}`
`ownerId`, `ownerName`, `title`, `description`, `difficulty`, `subjects[]`,
`format`, `availability`, `languages[]`, `isOffer`, `createdAt`.

### `learningRequests/{requestId}`
`participants[]`, listing ref, status, timestamps.

### `notifications/{notificationId}`
`userId`, `type`, `title`, `body`, `data{}`, `read`, `createdAt`.
Written by backend only; users may read and flip `read`.

### `reports/{reportId}`
`reporterId`, `targetType` (resource/message/user/question/answer), `targetId`,
`reason`, `details`, `status` (open/reviewing/resolved/dismissed),
`resolvedBy`, `resolutionNote`, `createdAt`, `resolvedAt`.

### Server-only
- `moderationCases/{caseId}` — moderator-only.
- `userBlocks/{blockerId}_{blockedId}` — owner-managed.
- `reputationEvents/{eventId}` — append-only, server-written.
- `adminAuditLogs/{logId}` — append-only, admin-read, server-written.
- `appConfiguration/{docId}` — flags/limits; admin-writable.
- `voteGuards/{guardId}` — internal dedup for votes.

## Composite indexes

Declared in `firebase/firestore.indexes.json`; the notable ones:

- `resources`: `status` + `createdAt desc`
- `resources`: `ownerId` + `createdAt desc`
- `resources`: `status` + `type` + `createdAt desc`
- `resources`: `status` + `subject` + `createdAt desc`
- `resources`: `status` + `educationLevel` + `createdAt desc`
- `resources`: `status` + `language` + `createdAt desc`
- `resources`: `status` + `saveCount desc`
- `resources`: `status` + `titleLower` (prefix search)
- `swapRequests`: `requesterId` + `createdAt desc`, `ownerId` + `createdAt desc`
- `conversations`: `participants array-contains` + `lastMessageAt desc`
- `questions`: `subject` + `createdAt desc`
- `savedResources`: `userId` + `savedAt desc`
- `notifications`: `userId` + `createdAt desc`, `userId` + `read`
- `reports`: `reporterId` + `createdAt desc`, `status` + `createdAt desc`

## Design rules

- **Stable IDs.** Resource ids are generated client-side before upload so the
  Storage path and the document share the id.
- **Server timestamps** everywhere time matters (`FieldValue.serverTimestamp()`).
- **Transactions/batches** for multi-document changes (swap transitions, save
  toggles, votes, accepting answers).
- **Counters never drift.** `saveCount`, `downloadCount`, `upvotes`,
  `answerCount` are only changed inside Cloud Functions.
- **No duplication.** One canonical `status` per swap; one `acceptedAnswerId`
  per question; deterministic ids for saves and conversations.
