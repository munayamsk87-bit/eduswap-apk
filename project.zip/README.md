# EduSwap

A free, student-focused learning ecosystem: share notes and PDFs, swap books,
ask and answer questions, learn new skills, and study with an AI assistant.
**No payments, ever** — EduSwap is a community, not a marketplace.

Built with Flutter + Firebase: Riverpod for state, GoRouter for navigation,
Material 3 theming, Freezed models, Firestore/Storage security rules, and
TypeScript Cloud Functions for all trusted backend logic.

> This is a working, production-oriented **scaffold**: real architecture, real
> Firebase integration, real security rules and Cloud Functions. It is not a
> UI mockup, and it does not pretend anything is connected when it is not.

---

## 1. What's inside

```
eduswap/
├── lib/
│   ├── main.dart                 # bootstrap + graceful setup-error screen
│   ├── app.dart                  # MaterialApp.router, themes, locales
│   ├── core/
│   │   ├── constants/            # app constants, enums, collection names
│   │   ├── theme/                # Material 3 theme + brand colours
│   │   ├── router/               # GoRouter with all routes + auth redirect
│   │   ├── utils/                # validators
│   │   ├── errors/               # single UI-friendly AppException
│   │   └── widgets/              # shell, empty/error/loading states
│   ├── shared/
│   │   ├── models/               # Freezed models (user, resource, swap, …)
│   │   ├── providers/            # Firebase, auth, feed, settings providers
│   │   ├── services/             # Firebase bootstrap (App Check, Crashlytics)
│   │   └── widgets/              # reusable cards
│   └── features/                 # one folder per feature (data + presentation)
│       ├── auth/ home/ explore/ upload/ resources/ swap/ chat/
│       ├── community/ ai/ skills/ notifications/ wishlist/
│       └── profile/ settings/ admin/
├── firebase/
│   ├── firestore.rules           # production-oriented Firestore rules
│   ├── storage.rules             # Storage rules (private files by default)
│   └── firestore.indexes.json    # composite indexes for every query
├── functions/                    # Cloud Functions (TypeScript)
│   └── src/                      # swaps, resources, community, admin, ai, …
├── docs/
│   ├── data_model.md             # Firestore schema + indexes
│   └── architecture.md           # layers, flows, security model
├── firebase.json  .firebaserc
└── pubspec.yaml
```

## 2. Prerequisites

- Flutter 3.22+ / Dart 3.4+ (`flutter --version`)
- Node.js 20 + npm (for Cloud Functions)
- A Firebase project (Spark/free tier is enough to start)
- The Firebase CLI: `npm i -g firebase-tools`
- FlutterFire CLI (recommended): `dart pub global activate flutterfire_cli`

## 3. Set up Firebase

1. Create a project at <https://console.firebase.google.com>.
2. Enable **Authentication** → Email/Password, and **Google**.
3. Enable **Cloud Firestore** (start in production mode) and **Storage**.
4. From the repo root, connect the app:

   ```bash
   flutterfire configure --project=<your-project-id>
   ```

   This writes `lib/firebase_options.dart` and drops `google-services.json`
   into `android/app/`. Both are git-ignored — never commit credentials.

   If you prefer the manual route, download `google-services.json` into
   `android/app/` and leave `main.dart` calling `Firebase.initializeApp()`
   with no options (the Android config file is picked up automatically).

5. Point the CLI at your project:

   ```bash
   firebase use --add      # choose your project, alias it "default"
   ```

## 4. Install & run the app

```bash
flutter pub get
dart run build_runner build --delete-conflicting-outputs   # generates Freezed/json
flutter run                                                # on an Android device/emulator
```

If Firebase is not configured yet, the app shows a clear **"EduSwap needs
Firebase setup"** screen instead of a blank crash.

## 5. Deploy rules, indexes and functions

```bash
# Firestore rules + composite indexes + Storage rules
firebase deploy --only firestore:rules,firestore:indexes,storage

# Cloud Functions
cd functions && npm install && npm run build && cd ..
firebase deploy --only functions
```

### AI assistant (optional)

The assistant calls a **server-side** proxy; keys never touch the app. Set one
of these in the functions environment, then redeploy:

```bash
firebase functions:secrets:set GEMINI_API_KEY     # or:
firebase functions:secrets:set OPENAI_API_KEY
```

If neither is set, the AI screen returns a clear "not configured" message and
the rest of the app keeps working. Nothing is faked.

### Grant yourself admin

Admin access comes from a **custom claim**, never a profile field. Bootstrap the
first admin once with the Admin SDK (or the console), then use the in-app
`setAdminClaim` function thereafter:

```bash
# one-off, using the Firebase Admin SDK / gcloud with your project credentials
# auth.setCustomUserClaims(uid, { admin: true })
```

## 6. Firebase App Check

App Check is activated in `lib/shared/services/firebase_bootstrap.dart` (debug
provider in debug builds, Play Integrity in release). Register your app under
**App Check** in the console and enable enforcement on Firestore and Storage
before going to production.

## 7. Emulator suite (optional)

```bash
firebase emulators:start
```

Then point the app at the emulators in `main.dart` (add
`useFirestoreEmulator`, `useAuthEmulator`, `useFunctionsEmulator`).

## 8. Product rules baked into the code

- **No money.** There is no payment code, no checkout, no wallet, no
  monetization anywhere — and the architecture keeps it that way.
- **Private files by default.** Study files are readable only via a
  short-lived signed URL from the `getResourceAccess` function.
- **Server-authoritative.** Swap transitions, vote counts, save counts,
  moderation outcomes, roles and notifications are all applied by Cloud
  Functions, so clients cannot forge them.
- **Minors first.** Only approximate locality is collected; precise location
  and contact details are never requested or published.

## 9. Build an APK

You need the Flutter + Android toolchain once (Flutter 3.22+, Android SDK, JDK 17).
The project ships without the generated `android/` folder — the build steps
create it, and never touch your Dart code.

**Locally** — one command does everything:

```bash
# put your Firebase config in place first:
#   android/app/google-services.json   (Firebase Console > Project settings)

./scripts/build_apk.sh
# → build/app/outputs/flutter-apk/app-release.apk
```

That script runs `flutter create` (to add the `android/` folder), then
`scripts/configure_android.sh` and `scripts/patch_plugins.sh`, then code
generation and the build.

**Build requirements that are not obvious** (the scripts handle all of these,
but they are worth knowing):

- **AGP 8.1.0 + Gradle 8.3.** The `flutter create` default (AGP 7.3) cannot
  target `compileSdk 34`, which the Firebase Android SDK needs.
- **Kotlin 2.1.0.** The Firebase Android SDK ships Kotlin 2.1 metadata; an older
  Kotlin plugin fails with *"binary version of its metadata is 2.1.0"*.
- **`minSdk 23` + multidex**, because Firebase plus the plugins exceed the 64k
  method limit.
- **`syncfusion_flutter_pdfviewer` still resolves from the shut-down `jcenter`
  repo**, which now returns HTTP 403 and aborts the build.
  `scripts/patch_plugins.sh` rewrites it to `mavenCentral()` in the pub cache.
  (If you'd rather not patch the cache, swap that package for `pdfx` or
  `flutter_pdfview` and drop the patch step.)

**Without a local toolchain (GitHub Actions):** push the repo to GitHub, then
add your `google-services.json` as a base64 secret named
`GOOGLE_SERVICES_JSON_B64` (Settings → Secrets → Actions), and run the
**Build APK** workflow (or push to `main`). It builds `app-release.apk` and
uploads it as a downloadable artifact.

> A release APK built this way is unsigned (debug-signed by Flutter). For the
> Play Store, configure a signing keystore in `android/app/build.gradle` first.
> Because the app targets minors, remember to enable App Check enforcement in
> Firebase before distributing.

## 10. Next steps

The scaffold is deliberately complete but not exhaustive. Natural follow-ups:
wire FCM token registration on login, add the remaining Freezed `part` files
generation to CI, expand localization (`l10n/`) beyond Material defaults, and
add widget/golden tests under `test/`.

See `docs/architecture.md` and `docs/data_model.md` for the deeper detail.
