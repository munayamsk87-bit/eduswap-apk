import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'shared/services/firebase_bootstrap.dart';
import 'app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    await FirebaseBootstrap.initialize();
    runApp(const ProviderScope(child: EduSwapApp()));
  } catch (error, stack) {
    // Credentials missing or misconfigured — show a clear setup screen instead
    // of pretending the backend is connected.
    runApp(SetupErrorApp(message: error.toString(), details: stack.toString()));
  }
}
