import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app.dart';
import 'core/constants/build_flags.dart';
import 'offline/local_backend.dart';
import 'shared/services/firebase_bootstrap.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Offline build: no Firebase, everything on-device.
  if (kOfflineMode) {
    await LocalStore.instance.load();
    runApp(
      ProviderScope(
        overrides: offlineOverrides(),
        child: const EduSwapApp(),
      ),
    );
    return;
  }

  try {
    await FirebaseBootstrap.initialize();
    runApp(const ProviderScope(child: EduSwapApp()));
  } catch (error, stack) {
    // Credentials missing or misconfigured — show a clear setup screen instead
    // of pretending the backend is connected.
    runApp(SetupErrorApp(message: error.toString(), details: stack.toString()));
  }
}
