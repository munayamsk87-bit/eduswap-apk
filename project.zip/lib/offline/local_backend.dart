// Offline backend for EduSwap.
//
// When the app is built with --dart-define=OFFLINE=true, every provider is
// overridden to use these local implementations instead of Firebase. All data
// lives on the device (persisted to shared_preferences). No account, no
// internet, no API keys required.
//
// This is a single-device mode: there are no other users to share with, but
// login, uploads, search, saved items, Q&A, swaps and notifications all work.

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/constants/enums.dart';
import '../features/admin/data/admin_repository.dart';
import '../features/ai/data/ai_repository.dart';
import '../features/auth/data/auth_repository.dart';
import '../features/chat/data/chat_repository.dart';
import '../features/community/data/community_repository.dart';
import '../features/notifications/data/notification_repository.dart';
import '../features/resources/data/resource_repository.dart';
import '../features/skills/data/skill_repository.dart';
import '../features/swap/data/swap_repository.dart';
import '../shared/models/answer.dart';
import '../shared/models/app_notification.dart';
import '../shared/models/app_user.dart';
import '../shared/models/conversation.dart';
import '../shared/models/message.dart';
import '../shared/models/question.dart';
import '../shared/models/report.dart';
import '../shared/models/resource.dart';
import '../shared/models/saved_resource.dart';
import '../shared/models/skill_listing.dart';
import '../shared/models/swap_request.dart';
import '../shared/providers/auth_providers.dart';
import '../shared/providers/feed_providers.dart';

// ---------------------------------------------------------------------------
// Store
// ---------------------------------------------------------------------------

class LocalStore {
  LocalStore._();
  static final LocalStore instance = LocalStore._();

  static const _key = 'eduswap_offline_v1';

  final _changes = StreamController<void>.broadcast();
  Stream<void> get changes => _changes.stream;

  final Map<String, AppUser> users = {};
  final Map<String, String> passwords = {}; // email -> password
  String? sessionUid;

  final Map<String, Resource> resources = {};
  final Map<String, SavedResource> saved = {};
  final Map<String, Question> questions = {};
  final Map<String, List<Answer>> answers = {};
  final Map<String, SwapRequest> swaps = {};
  final Map<String, Conversation> conversations = {};
  final Map<String, List<Message>> messages = {};
  final Map<String, AppNotification> notifications = {};
  final Map<String, SkillListing> skills = {};
  final Map<String, Report> reports = {};

  bool _loaded = false;

  Object? _enc(Object? o) =>
      o is Timestamp ? o.millisecondsSinceEpoch : o.toString();

  Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_key);
      if (raw == null) return;
      final d = jsonDecode(raw) as Map<String, dynamic>;

      void loadMap<T>(String key, Map<String, T> target, T Function(Map<String, dynamic>) f) {
        final m = d[key];
        if (m is Map) {
          m.forEach((k, v) => target[k as String] = f((v as Map).cast<String, dynamic>()));
        }
      }

      loadMap('users', users, AppUser.fromJson);
      loadMap('resources', resources, Resource.fromJson);
      loadMap('saved', saved, SavedResource.fromJson);
      loadMap('questions', questions, Question.fromJson);
      loadMap('swaps', swaps, SwapRequest.fromJson);
      loadMap('conversations', conversations, Conversation.fromJson);
      loadMap('notifications', notifications, AppNotification.fromJson);
      loadMap('skills', skills, SkillListing.fromJson);
      loadMap('reports', reports, Report.fromJson);

      final pw = d['passwords'];
      if (pw is Map) pw.forEach((k, v) => passwords[k as String] = v as String);
      sessionUid = d['sessionUid'] as String?;

      final ans = d['answers'];
      if (ans is Map) {
        ans.forEach((k, v) {
          answers[k as String] = (v as List)
              .map((e) => Answer.fromJson((e as Map).cast<String, dynamic>()))
              .toList();
        });
      }
      final msgs = d['messages'];
      if (msgs is Map) {
        msgs.forEach((k, v) {
          messages[k as String] = (v as List)
              .map((e) => Message.fromJson((e as Map).cast<String, dynamic>()))
              .toList();
        });
      }
    } catch (_) {
      // Corrupt store — start fresh rather than crash.
    }
  }

  Future<void> _persist() async {
    try {
      final data = <String, dynamic>{
        'users': users.map((k, v) => MapEntry(k, v.toJson())),
        'passwords': passwords,
        'sessionUid': sessionUid,
        'resources': resources.map((k, v) => MapEntry(k, v.toJson())),
        'saved': saved.map((k, v) => MapEntry(k, v.toJson())),
        'questions': questions.map((k, v) => MapEntry(k, v.toJson())),
        'answers': answers.map((k, v) => MapEntry(k, v.map((a) => a.toJson()).toList())),
        'swaps': swaps.map((k, v) => MapEntry(k, v.toJson())),
        'conversations': conversations.map((k, v) => MapEntry(k, v.toJson())),
        'messages': messages.map((k, v) => MapEntry(k, v.map((m) => m.toJson()).toList())),
        'notifications': notifications.map((k, v) => MapEntry(k, v.toJson())),
        'skills': skills.map((k, v) => MapEntry(k, v.toJson())),
        'reports': reports.map((k, v) => MapEntry(k, v.toJson())),
      };
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_key, jsonEncode(data, toEncodable: _enc));
    } catch (_) {}
  }

  /// Notify listeners and persist. Call after any mutation.
  void bump() {
    _changes.add(null);
    _persist();
  }

  Stream<T> watch<T>(T Function() read) async* {
    yield read();
    await for (final _ in changes) {
      yield read();
    }
  }

  String newId() =>
      DateTime.now().microsecondsSinceEpoch.toRadixString(36) +
      (1000 + (DateTime.now().millisecond)).toString();

  void notify({
    required String userId,
    required NotificationType type,
    required String title,
    String body = '',
    Map<String, dynamic> data = const {},
  }) {
    final id = newId();
    notifications[id] = AppNotification(
      id: id,
      userId: userId,
      type: type,
      title: title,
      body: body,
      data: data,
      createdAt: DateTime.now(),
    );
  }
}

// ---------------------------------------------------------------------------
// Auth
// ---------------------------------------------------------------------------

class LocalAuthRepository implements AuthRepository {
  LocalAuthRepository(this._store);
  final LocalStore _store;

  String? get currentUid => _store.sessionUid;

  @override
  Stream<User?> authStateChanges() => Stream<User?>.value(null);

  @override
  User? get currentUser => null;

  @override
  Stream<AppUser?> watchProfile(String uid) =>
      _store.watch(() => _store.users[uid]);

  @override
  Future<AppUser?> fetchProfile(String uid) async => _store.users[uid];

  @override
  Future<void> register({
    required String email,
    required String password,
    required String displayName,
  }) async {
    final clean = email.trim().toLowerCase();
    final existing = _store.users.values
        .where((u) => u.email.toLowerCase() == clean)
        .toList();
    if (existing.isNotEmpty) {
      throw Exception('An account already exists for that email.');
    }
    final uid = _store.newId();
    _store.users[uid] = AppUser(
      uid: uid,
      displayName: displayName.trim(),
      email: clean,
      onboardingComplete: false,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
    _store.passwords[clean] = password;
    _store.sessionUid = uid;
    _store.bump();
  }

  @override
  Future<void> signIn({required String email, required String password}) async {
    final clean = email.trim().toLowerCase();
    final match = _store.users.values
        .where((u) => u.email.toLowerCase() == clean)
        .toList();
    if (match.isEmpty) {
      throw Exception('No account found for that email. Create one first.');
    }
    if (_store.passwords[clean] != password) {
      throw Exception('Incorrect email or password.');
    }
    _store.sessionUid = match.first.uid;
    _store.bump();
  }

  @override
  Future<void> signInWithGoogle() async {
    // Offline: create/reuse a local account.
    final clean = 'guest@eduswap.local';
    final existing = _store.users.values
        .where((u) => u.email == clean)
        .toList();
    if (existing.isEmpty) {
      final uid = _store.newId();
      _store.users[uid] = AppUser(
        uid: uid,
        displayName: 'Guest Student',
        email: clean,
        onboardingComplete: true,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
      _store.sessionUid = uid;
    } else {
      _store.sessionUid = existing.first.uid;
    }
    _store.bump();
  }

  @override
  Future<void> sendPasswordReset(String email) async {}

  @override
  Future<void> sendEmailVerification() async {}

  @override
  Future<void> signOut() async {
    _store.sessionUid = null;
    _store.bump();
  }

  @override
  Future<void> completeOnboarding({
    required String uid,
    required String displayName,
    required EducationLevel educationLevel,
    String? institution,
    String? board,
    required AppLanguage language,
    required List<String> subjects,
    required List<String> interests,
    String? locality,
  }) async {
    final u = _store.users[uid];
    if (u == null) return;
    _store.users[uid] = u.copyWith(
      displayName: displayName,
      educationLevel: educationLevel,
      institution: institution,
      board: board,
      preferredLanguage: language,
      subjects: subjects,
      interests: interests,
      locality: locality,
      onboardingComplete: true,
      updatedAt: DateTime.now(),
    );
    _store.bump();
  }

  @override
  Future<void> updateProfile(String uid, Map<String, dynamic> changes) async {
    final u = _store.users[uid];
    if (u == null) return;
    final merged = u.toJson()..addAll(changes);
    _store.users[uid] = AppUser.fromJson(merged);
    _store.bump();
  }

  @override
  Future<void> deleteAccount() async {
    final uid = _store.sessionUid;
    if (uid == null) return;
    final u = _store.users[uid];
    if (u != null) _store.passwords.remove(u.email.toLowerCase());
    _store.users.remove(uid);
    _store.resources.removeWhere((_, r) => r.ownerId == uid);
    _store.saved.removeWhere((_, s) => s.userId == uid);
    _store.notifications.removeWhere((_, n) => n.userId == uid);
    _store.sessionUid = null;
    _store.bump();
  }
}

// ---------------------------------------------------------------------------
// Resources
// ---------------------------------------------------------------------------

class LocalResourceRepository implements ResourceRepository {
  LocalResourceRepository(this._store);
  final LocalStore _store;

  List<Resource> get _visible =>
      _store.resources.values.where((r) => r.status == ResourceStatus.approved).toList();

  @override
  Stream<List<Resource>> watchRecent({int limit = 20}) => _store.watch(() {
        final list = _visible.toList()
          ..sort((a, b) => (b.createdAt ?? DateTime(0)).compareTo(a.createdAt ?? DateTime(0)));
        return list.take(limit).toList();
      });

  @override
  Stream<List<Resource>> watchByOwner(String ownerId) => _store.watch(() {
        final list = _store.resources.values.where((r) => r.ownerId == ownerId).toList()
          ..sort((a, b) => (b.createdAt ?? DateTime(0)).compareTo(a.createdAt ?? DateTime(0)));
        return list;
      });

  @override
  Future<Resource?> getById(String id) async => _store.resources[id];

  @override
  Future<ResourcePage> search(
    ResourceQuery query, {
    DocumentSnapshot<Map<String, dynamic>>? startAfter,
    int limit = 20,
  }) async {
    var list = _visible;
    if (query.text != null && query.text!.trim().isNotEmpty) {
      final t = query.text!.trim().toLowerCase();
      list = list.where((r) => r.title.toLowerCase().contains(t)).toList();
    }
    if (query.type != null) list = list.where((r) => r.type == query.type).toList();
    if (query.subject != null && query.subject!.isNotEmpty) {
      list = list.where((r) => r.subject == query.subject).toList();
    }
    if (query.educationLevel != null) {
      list = list.where((r) => r.educationLevel == query.educationLevel).toList();
    }
    if (query.language != null) list = list.where((r) => r.language == query.language).toList();
    switch (query.sort) {
      case ResourceSort.newest:
        list.sort((a, b) => (b.createdAt ?? DateTime(0)).compareTo(a.createdAt ?? DateTime(0)));
      case ResourceSort.relevance:
      case ResourceSort.mostSaved:
        list.sort((a, b) => b.saveCount.compareTo(a.saveCount));
    }
    return ResourcePage(items: list, lastDoc: null);
  }

  @override
  Future<String> uploadAndCreate({
    required Resource draft,
    File? file,
    File? cover,
    void Function(double progress)? onProgress,
  }) async {
    final id = draft.id.isEmpty ? _store.newId() : draft.id;
    onProgress?.call(0.3);
    _store.resources[id] = draft.copyWith(
      id: id,
      filePath: file?.path,
      coverUrl: cover?.path,
      // Offline: no moderation queue — publish immediately.
      status: ResourceStatus.approved,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
    onProgress?.call(1);
    _store.bump();
    return id;
  }

  @override
  Future<void> updateResource(String id, Map<String, dynamic> changes) async {
    final r = _store.resources[id];
    if (r == null) return;
    _store.resources[id] = Resource.fromJson(r.toJson()..addAll(changes));
    _store.bump();
  }

  @override
  Future<void> deleteResource(Resource resource) async {
    _store.resources.remove(resource.id);
    _store.bump();
  }

  @override
  Future<void> setAvailable(String id, bool available) =>
      updateResource(id, {'available': available});

  @override
  Stream<bool> watchIsSaved(String userId, String resourceId) =>
      _store.watch(() => _store.saved.containsKey('${userId}_$resourceId'));

  @override
  Stream<List<SavedResource>> watchSaved(String userId) => _store.watch(() {
        final list = _store.saved.values.where((s) => s.userId == userId).toList()
          ..sort((a, b) => (b.savedAt ?? DateTime(0)).compareTo(a.savedAt ?? DateTime(0)));
        return list;
      });

  @override
  Future<bool> toggleSave({required String userId, required Resource resource}) async {
    final key = '${userId}_${resource.id}';
    final has = _store.saved.containsKey(key);
    if (has) {
      _store.saved.remove(key);
      final r = _store.resources[resource.id];
      if (r != null) {
        _store.resources[resource.id] = r.copyWith(saveCount: (r.saveCount - 1).clamp(0, 1 << 30));
      }
    } else {
      _store.saved[key] = SavedResource(
        id: key,
        userId: userId,
        resourceId: resource.id,
        resourceTitle: resource.title,
        coverUrl: resource.coverUrl,
        savedAt: DateTime.now(),
      );
      final r = _store.resources[resource.id];
      if (r != null) _store.resources[resource.id] = r.copyWith(saveCount: r.saveCount + 1);
    }
    _store.bump();
    return !has;
  }

  @override
  Future<String> requestDownloadUrl(String resourceId) async =>
      _store.resources[resourceId]?.filePath ?? '';

  @override
  Future<void> report({
    required String reporterId,
    required Resource resource,
    required String reason,
    String details = '',
  }) async {
    final id = _store.newId();
    _store.reports[id] = Report(
      id: id,
      reporterId: reporterId,
      targetType: ReportTargetType.resource,
      targetId: resource.id,
      reason: reason,
      details: details,
      status: ReportStatus.open,
      createdAt: DateTime.now(),
    );
    _store.bump();
  }

  Stream<Resource?> watchById(String id) => _store.watch(() => _store.resources[id]);
}

// ---------------------------------------------------------------------------
// Swaps
// ---------------------------------------------------------------------------

class LocalSwapRepository implements SwapRepository {
  LocalSwapRepository(this._store);
  final LocalStore _store;

  @override
  Future<String> createRequest({
    required Resource resource,
    required String requesterId,
    required String requesterName,
    String? offeredResourceId,
    String? offeredResourceTitle,
    String message = '',
  }) async {
    final id = _store.newId();
    _store.swaps[id] = SwapRequest(
      id: id,
      resourceId: resource.id,
      resourceTitle: resource.title,
      requesterId: requesterId,
      requesterName: requesterName,
      ownerId: resource.ownerId,
      ownerName: resource.ownerName,
      offeredResourceId: offeredResourceId,
      offeredResourceTitle: offeredResourceTitle,
      message: message,
      status: SwapStatus.requested,
      participants: [requesterId, resource.ownerId],
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
      expiresAt: DateTime.now().add(const Duration(days: 14)),
    );
    _store.bump();
    return id;
  }

  @override
  Stream<List<SwapRequest>> watchOutgoing(String uid) => _store.watch(() =>
      _store.swaps.values.where((s) => s.requesterId == uid).toList());

  @override
  Stream<List<SwapRequest>> watchIncoming(String uid) => _store.watch(() =>
      _store.swaps.values.where((s) => s.ownerId == uid).toList());

  @override
  Future<void> transition({required String requestId, required String action}) async {
    final s = _store.swaps[requestId];
    if (s == null) return;
    final next = switch (action) {
      'accept' => SwapStatus.accepted,
      'decline' => SwapStatus.declined,
      'cancel' => SwapStatus.cancelled,
      'complete' => SwapStatus.completed,
      'dispute' => SwapStatus.disputed,
      _ => s.status,
    };
    _store.swaps[requestId] = s.copyWith(status: next, updatedAt: DateTime.now());
    _store.bump();
  }

  @override
  Future<void> submitFeedback({
    required String requestId,
    required int rating,
    String feedback = '',
  }) async {
    final s = _store.swaps[requestId];
    if (s == null) return;
    _store.swaps[requestId] = s.copyWith(requesterRating: rating, requesterFeedback: feedback);
    _store.bump();
  }

  @override
  Future<SwapStatus> statusOf(String requestId) async =>
      _store.swaps[requestId]?.status ?? SwapStatus.requested;
}

// ---------------------------------------------------------------------------
// Chat
// ---------------------------------------------------------------------------

class LocalChatRepository implements ChatRepository {
  LocalChatRepository(this._store);
  final LocalStore _store;

  @override
  Future<String> getOrCreateConversation({
    required String currentUid,
    required String otherUid,
    required Map<String, String> names,
    String? resourceId,
    String? resourceTitle,
    String? swapRequestId,
  }) async {
    final parts = [currentUid, otherUid]..sort();
    final id = '${parts.first}_${parts.last}${resourceId == null ? '' : '_$resourceId'}';
    if (!_store.conversations.containsKey(id)) {
      _store.conversations[id] = Conversation(
        id: id,
        participants: parts,
        participantNames: names,
        resourceId: resourceId,
        resourceTitle: resourceTitle,
        swapRequestId: swapRequestId,
        unread: {for (final p in parts) p: 0},
        createdAt: DateTime.now(),
      );
      _store.bump();
    }
    return id;
  }

  @override
  Stream<List<Conversation>> watchConversations(String uid) => _store.watch(() {
        final list = _store.conversations.values
            .where((c) => c.participants.contains(uid))
            .toList()
          ..sort((a, b) =>
              (b.lastMessageAt ?? DateTime(0)).compareTo(a.lastMessageAt ?? DateTime(0)));
        return list;
      });

  @override
  Stream<List<Message>> watchMessages(String conversationId, {int limit = 20}) =>
      _store.watch(() {
        final list = (_store.messages[conversationId] ?? []).toList()
          ..sort((a, b) => (b.createdAt ?? DateTime(0)).compareTo(a.createdAt ?? DateTime(0)));
        return list.take(limit).toList();
      });

  Stream<Conversation?> watchConversation(String id) =>
      _store.watch(() => _store.conversations[id]);

  @override
  Future<void> sendMessage({
    required String conversationId,
    required String senderId,
    required String senderName,
    required List<String> participants,
    String? text,
    String? imageUrl,
    String? replyToId,
  }) async {
    final list = _store.messages.putIfAbsent(conversationId, () => []);
    list.add(Message(
      id: _store.newId(),
      senderId: senderId,
      senderName: senderName,
      text: text?.trim(),
      imageUrl: imageUrl,
      replyToId: replyToId,
      readBy: [senderId],
      createdAt: DateTime.now(),
    ));
    final c = _store.conversations[conversationId];
    if (c != null) {
      final unread = Map<String, int>.from(c.unread);
      for (final p in participants) {
        if (p != senderId) unread[p] = (unread[p] ?? 0) + 1;
      }
      _store.conversations[conversationId] = c.copyWith(
        lastMessage: imageUrl != null ? 'Photo' : text?.trim(),
        lastMessageAt: DateTime.now(),
        unread: unread,
      );
    }
    _store.bump();
  }

  @override
  Future<void> markRead(String conversationId, String uid) async {
    final c = _store.conversations[conversationId];
    if (c == null) return;
    final unread = Map<String, int>.from(c.unread)..[uid] = 0;
    _store.conversations[conversationId] = c.copyWith(unread: unread);
    _store.bump();
  }

  @override
  Future<void> reportMessage({
    required String reporterId,
    required String messageId,
    String details = '',
  }) async {
    final id = _store.newId();
    _store.reports[id] = Report(
      id: id,
      reporterId: reporterId,
      targetType: ReportTargetType.message,
      targetId: messageId,
      reason: 'Inappropriate message',
      details: details,
      status: ReportStatus.open,
      createdAt: DateTime.now(),
    );
    _store.bump();
  }

  @override
  Future<void> blockUser({required String currentUid, required String blockedUid}) async {}
}

// ---------------------------------------------------------------------------
// Community
// ---------------------------------------------------------------------------

class LocalCommunityRepository implements CommunityRepository {
  LocalCommunityRepository(this._store);
  final LocalStore _store;

  @override
  Stream<List<Question>> watchQuestions({String? subject, int limit = 20}) =>
      _store.watch(() {
        var list = _store.questions.values.toList();
        if (subject != null && subject.isNotEmpty) {
          list = list.where((q) => q.subject == subject).toList();
        }
        list.sort((a, b) =>
            (b.createdAt ?? DateTime(0)).compareTo(a.createdAt ?? DateTime(0)));
        return list.take(limit).toList();
      });

  @override
  Future<Question?> getQuestion(String id) async => _store.questions[id];

  Stream<Question?> watchQuestion(String id) => _store.watch(() => _store.questions[id]);

  @override
  Stream<List<Answer>> watchAnswers(String questionId) => _store.watch(() {
        final list = (_store.answers[questionId] ?? []).toList()
          ..sort((a, b) => b.upvotes.compareTo(a.upvotes));
        return list;
      });

  @override
  Future<String> askQuestion({
    required String authorId,
    required String authorName,
    String? authorPhotoUrl,
    required String title,
    required String body,
    required String subject,
    required EducationLevel level,
    List<String> tags = const [],
  }) async {
    final id = _store.newId();
    _store.questions[id] = Question(
      id: id,
      authorId: authorId,
      authorName: authorName,
      authorPhotoUrl: authorPhotoUrl,
      title: title,
      body: body,
      subject: subject,
      educationLevel: level,
      tags: tags,
      createdAt: DateTime.now(),
    );
    _store.bump();
    return id;
  }

  @override
  Future<void> addAnswer({
    required String questionId,
    required String authorId,
    required String authorName,
    String? authorPhotoUrl,
    required String body,
  }) async {
    final list = _store.answers.putIfAbsent(questionId, () => []);
    list.add(Answer(
      id: _store.newId(),
      questionId: questionId,
      authorId: authorId,
      authorName: authorName,
      authorPhotoUrl: authorPhotoUrl,
      body: body,
      createdAt: DateTime.now(),
    ));
    final q = _store.questions[questionId];
    if (q != null) {
      _store.questions[questionId] = q.copyWith(answerCount: q.answerCount + 1);
    }
    _store.bump();
  }

  @override
  Future<void> voteQuestion(String questionId) async {
    final q = _store.questions[questionId];
    if (q != null) {
      _store.questions[questionId] = q.copyWith(upvotes: q.upvotes + 1);
      _store.bump();
    }
  }

  @override
  Future<void> voteAnswer(String questionId, String answerId) async {
    final list = _store.answers[questionId];
    if (list == null) return;
    final i = list.indexWhere((a) => a.id == answerId);
    if (i >= 0) {
      list[i] = list[i].copyWith(upvotes: list[i].upvotes + 1);
      _store.bump();
    }
  }

  @override
  Future<void> acceptAnswer(String questionId, String answerId) async {
    final list = _store.answers[questionId];
    if (list != null) {
      for (var i = 0; i < list.length; i++) {
        list[i] = list[i].copyWith(isAccepted: list[i].id == answerId);
      }
    }
    final q = _store.questions[questionId];
    if (q != null) _store.questions[questionId] = q.copyWith(acceptedAnswerId: answerId);
    _store.bump();
  }
}

// ---------------------------------------------------------------------------
// Skills
// ---------------------------------------------------------------------------

class LocalSkillRepository implements SkillRepository {
  LocalSkillRepository(this._store);
  final LocalStore _store;

  @override
  Stream<List<SkillListing>> watchListings({int limit = 50}) => _store.watch(() {
        final list = _store.skills.values.toList()
          ..sort((a, b) =>
              (b.createdAt ?? DateTime(0)).compareTo(a.createdAt ?? DateTime(0)));
        return list.take(limit).toList();
      });

  @override
  Future<String> create({
    required String ownerId,
    required String ownerName,
    String? ownerPhotoUrl,
    required String title,
    required String description,
    required SkillDifficulty difficulty,
    required List<String> subjects,
    required String format,
    required String availability,
    required List<String> languages,
    required bool isOffer,
  }) async {
    final id = _store.newId();
    _store.skills[id] = SkillListing(
      id: id,
      ownerId: ownerId,
      ownerName: ownerName,
      ownerPhotoUrl: ownerPhotoUrl,
      title: title,
      description: description,
      difficulty: difficulty,
      subjects: subjects,
      format: format,
      availability: availability,
      languages: languages,
      isOffer: isOffer,
      createdAt: DateTime.now(),
    );
    _store.bump();
    return id;
  }
}

// ---------------------------------------------------------------------------
// Notifications
// ---------------------------------------------------------------------------

class LocalNotificationRepository implements NotificationRepository {
  LocalNotificationRepository(this._store);
  final LocalStore _store;

  @override
  Stream<List<AppNotification>> watch(String uid, {int limit = 50}) => _store.watch(() {
        final list = _store.notifications.values.where((n) => n.userId == uid).toList()
          ..sort((a, b) =>
              (b.createdAt ?? DateTime(0)).compareTo(a.createdAt ?? DateTime(0)));
        return list.take(limit).toList();
      });

  @override
  Stream<int> watchUnreadCount(String uid) => _store.watch(() =>
      _store.notifications.values.where((n) => n.userId == uid && !n.read).length);

  @override
  Future<void> markRead(String id) async {
    final n = _store.notifications[id];
    if (n != null) {
      _store.notifications[id] = n.copyWith(read: true);
      _store.bump();
    }
  }

  @override
  Future<void> markAllRead(String uid) async {
    for (final e in _store.notifications.entries.toList()) {
      if (e.value.userId == uid) {
        _store.notifications[e.key] = e.value.copyWith(read: true);
      }
    }
    _store.bump();
  }
}

// ---------------------------------------------------------------------------
// Admin
// ---------------------------------------------------------------------------

class LocalAdminRepository implements AdminRepository {
  LocalAdminRepository(this._store);
  final LocalStore _store;

  @override
  Future<AdminStats> dashboard() async => AdminStats(
        totalUsers: _store.users.length,
        pendingResources: _store.resources.values
            .where((r) => r.status == ResourceStatus.pendingReview)
            .length,
        approvedResources: _store.resources.values
            .where((r) => r.status == ResourceStatus.approved)
            .length,
        reportedResources: _store.reports.length,
        openReports: _store.reports.values
            .where((r) => r.status == ReportStatus.open)
            .length,
      );

  @override
  Stream<List<Resource>> watchPendingResources() => _store.watch(() =>
      _store.resources.values
          .where((r) => r.status == ResourceStatus.pendingReview)
          .toList());

  @override
  Stream<List<Report>> watchReports({ReportStatus? status}) => _store.watch(() {
        var list = _store.reports.values.toList();
        if (status != null) list = list.where((r) => r.status == status).toList();
        return list;
      });

  @override
  Future<void> moderateResource({
    required String resourceId,
    required bool approve,
    String note = '',
  }) async {
    final r = _store.resources[resourceId];
    if (r == null) return;
    _store.resources[resourceId] = r.copyWith(
      status: approve ? ResourceStatus.approved : ResourceStatus.rejected,
      moderationNote: note,
      updatedAt: DateTime.now(),
    );
    _store.bump();
  }

  @override
  Future<void> resolveReport({
    required String reportId,
    required String resolution,
    String note = '',
  }) async {
    final r = _store.reports[reportId];
    if (r == null) return;
    _store.reports[reportId] = r.copyWith(
      status: resolution == 'dismissed' ? ReportStatus.dismissed : ReportStatus.resolved,
      resolutionNote: note,
      resolvedAt: DateTime.now(),
    );
    _store.bump();
  }

  @override
  Future<void> setUserSuspended({required String userId, required bool suspended}) async {
    final u = _store.users[userId];
    if (u == null) return;
    _store.users[userId] = u.copyWith(isSuspended: suspended);
    _store.bump();
  }
}

// ---------------------------------------------------------------------------
// AI
// ---------------------------------------------------------------------------

class LocalAiRepository implements AiRepository {
  @override
  Future<String> run({
    required AiTask task,
    required String input,
    EducationLevel level = EducationLevel.secondary,
    AppLanguage language = AppLanguage.english,
  }) async {
    return 'The AI Study Assistant needs an internet backend, so it is not '
        'available in this offline build.\n\n'
        'Everything else works: you can sign in, add notes and PDFs, search, '
        'save items, ask questions and swap books — all stored on this phone.';
  }
}

// ---------------------------------------------------------------------------
// Providers + overrides
// ---------------------------------------------------------------------------

final localStoreProvider = Provider<LocalStore>((_) => LocalStore.instance);
final localAuthRepositoryProvider =
    Provider<LocalAuthRepository>((ref) => LocalAuthRepository(ref.watch(localStoreProvider)));
final localResourceRepositoryProvider = Provider<LocalResourceRepository>(
    (ref) => LocalResourceRepository(ref.watch(localStoreProvider)));
final localSwapRepositoryProvider =
    Provider<LocalSwapRepository>((ref) => LocalSwapRepository(ref.watch(localStoreProvider)));
final localChatRepositoryProvider =
    Provider<LocalChatRepository>((ref) => LocalChatRepository(ref.watch(localStoreProvider)));
final localCommunityRepositoryProvider = Provider<LocalCommunityRepository>(
    (ref) => LocalCommunityRepository(ref.watch(localStoreProvider)));
final localSkillRepositoryProvider =
    Provider<LocalSkillRepository>((ref) => LocalSkillRepository(ref.watch(localStoreProvider)));
final localNotificationRepositoryProvider = Provider<LocalNotificationRepository>(
    (ref) => LocalNotificationRepository(ref.watch(localStoreProvider)));
final localAdminRepositoryProvider =
    Provider<LocalAdminRepository>((ref) => LocalAdminRepository(ref.watch(localStoreProvider)));
final localAiRepositoryProvider = Provider<LocalAiRepository>((_) => LocalAiRepository());

/// Every provider the UI reads, pointed at the local backend.
List<Override> offlineOverrides() => [
      authRepositoryProvider.overrideWith((ref) => ref.watch(localAuthRepositoryProvider)),
      resourceRepositoryProvider
          .overrideWith((ref) => ref.watch(localResourceRepositoryProvider)),
      swapRepositoryProvider.overrideWith((ref) => ref.watch(localSwapRepositoryProvider)),
      chatRepositoryProvider.overrideWith((ref) => ref.watch(localChatRepositoryProvider)),
      communityRepositoryProvider
          .overrideWith((ref) => ref.watch(localCommunityRepositoryProvider)),
      skillRepositoryProvider.overrideWith((ref) => ref.watch(localSkillRepositoryProvider)),
      notificationRepositoryProvider
          .overrideWith((ref) => ref.watch(localNotificationRepositoryProvider)),
      adminRepositoryProvider.overrideWith((ref) => ref.watch(localAdminRepositoryProvider)),
      aiRepositoryProvider.overrideWith((ref) => ref.watch(localAiRepositoryProvider)),
      appUserProvider.overrideWith((ref) => ref.watch(localAuthRepositoryProvider).watchProfile(
            ref.watch(localAuthRepositoryProvider).currentUid ?? '',
          )),
      currentUserProvider
          .overrideWith((ref) => ref.watch(localAuthRepositoryProvider).currentUid),
      isAdminProvider.overrideWith((ref) => false),
      authStateProvider.overrideWith((ref) => Stream<User?>.value(null)),
      resourceByIdProvider
          .overrideWith((ref, id) => ref.watch(localResourceRepositoryProvider).watchById(id)),
      conversationProvider.overrideWith(
          (ref, id) => ref.watch(localChatRepositoryProvider).watchConversation(id)),
      messagesProvider
          .overrideWith((ref, id) => ref.watch(localChatRepositoryProvider).watchMessages(id)),
      questionByIdProvider
          .overrideWith((ref, id) => ref.watch(localCommunityRepositoryProvider).watchQuestion(id)),
      userByIdProvider
          .overrideWith((ref, id) => ref.watch(localAuthRepositoryProvider).watchProfile(id)),
    ];
