import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/app_constants.dart';
import '../../../core/constants/enums.dart';
import '../../../shared/models/skill_listing.dart';
import '../../../shared/providers/firebase_providers.dart';

/// Free skill-sharing listings. No paid tutoring, ever.
class SkillRepository {
  SkillRepository(this._db);

  final FirebaseFirestore _db;

  CollectionReference<Map<String, dynamic>> get _col =>
      _db.collection(AppConstants.skillListingsCol);

  Stream<List<SkillListing>> watchListings({int limit = 50}) {
    return _col
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .snapshots()
        .map((s) =>
            s.docs.map((d) => SkillListing.fromJson(d.data())).toList());
  }

  Future<String> create({
    required String ownerId,
    required String ownerName,
    String? ownerPhotoUrl,
    required String title,
    required String description,
    required SkillDifficulty difficulty,
    required List<String> subjects,
    required String format,
    required String availability,
    required List<String> languages,
    required bool isOffer,
  }) async {
    final ref = _col.doc();
    await ref.set({
      'id': ref.id,
      'ownerId': ownerId,
      'ownerName': ownerName,
      'ownerPhotoUrl': ownerPhotoUrl,
      'title': title,
      'description': description,
      'difficulty': difficulty.name,
      'subjects': subjects,
      'format': format,
      'availability': availability,
      'languages': languages,
      'isOffer': isOffer,
      'createdAt': Timestamp.fromDate(DateTime.now()),
    });
    return ref.id;
  }
}

final skillRepositoryProvider = Provider<SkillRepository>((ref) {
  return SkillRepository(ref.watch(firestoreProvider));
});
