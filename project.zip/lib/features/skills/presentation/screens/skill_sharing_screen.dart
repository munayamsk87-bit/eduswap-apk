import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/enums.dart';
import '../../../../core/errors/app_exception.dart';
import '../../../../core/widgets/async_value_view.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/loading_skeleton.dart';
import '../../../../shared/models/skill_listing.dart';
import '../../../../shared/providers/auth_providers.dart';
import '../../data/skill_repository.dart';

final _skillListingsProvider = StreamProvider<List<SkillListing>>((ref) {
  return ref.watch(skillRepositoryProvider).watchListings();
});

/// Free peer-learning offers. No paid tutoring, no bookings.
class SkillSharingScreen extends ConsumerWidget {
  const SkillSharingScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final listings = ref.watch(_skillListingsProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Skill sharing')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _createSheet(context, ref),
        icon: const Icon(Icons.add),
        label: const Text('Offer a skill'),
      ),
      body: AsyncValueView<List<SkillListing>>(
        value: listings,
        onRetry: () => ref.invalidate(_skillListingsProvider),
        loading: LoadingSkeleton.list(count: 5, height: 110),
        isEmpty: (l) => l.isEmpty,
        emptyTitle: 'No skills listed yet',
        emptyMessage:
            'Offer to teach something you know — coding, maths, design.',
        data: (list) => ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: list.length,
          separatorBuilder: (_, __) => const SizedBox(height: 12),
          itemBuilder: (_, i) {
            final s = list[i];
            return Card(
              child: ListTile(
                contentPadding: const EdgeInsets.all(14),
                title: Text(s.title,
                    style: const TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 4),
                    Text(s.description, maxLines: 2,
                        overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 6),
                    Text('${s.ownerName} • ${s.difficulty.name} • ${s.format}'),
                  ],
                ),
                isThreeLine: true,
              ),
            );
          },
        ),
      ),
    );
  }

  Future<void> _createSheet(BuildContext context, WidgetRef ref) async {
    final title = TextEditingController();
    final desc = TextEditingController();
    var difficulty = SkillDifficulty.beginner;

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          left: 20, right: 20, top: 20,
          bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
        ),
        child: StatefulBuilder(
          builder: (ctx, setState) => Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Offer a skill', style: Theme.of(ctx).textTheme.titleLarge),
              const SizedBox(height: 16),
              TextField(
                controller: title,
                decoration: const InputDecoration(labelText: 'Skill title'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: desc,
                maxLines: 3,
                decoration: const InputDecoration(labelText: 'Description'),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<SkillDifficulty>(
                value: difficulty,
                decoration: const InputDecoration(labelText: 'Difficulty'),
                items: SkillDifficulty.values
                    .map((e) => DropdownMenuItem(value: e, child: Text(e.name)))
                    .toList(),
                onChanged: (v) => setState(() => difficulty = v ?? difficulty),
              ),
              const SizedBox(height: 20),
              FilledButton(
                onPressed: () async {
                  final user = ref.read(appUserProvider).valueOrNull;
                  final uid = ref.read(currentUserProvider);
                  if (user == null || uid == null || title.text.trim().isEmpty) {
                    return;
                  }
                  try {
                    await ref.read(skillRepositoryProvider).create(
                          ownerId: uid,
                          ownerName: user.displayName,
                          ownerPhotoUrl: user.photoUrl,
                          title: title.text.trim(),
                          description: desc.text.trim(),
                          difficulty: difficulty,
                          subjects: const [],
                          format: 'Online',
                          availability: 'Flexible',
                          languages: const ['English'],
                          isOffer: true,
                        );
                    if (ctx.mounted) Navigator.pop(ctx);
                  } catch (e) {
                    if (ctx.mounted) {
                      ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
                          content: Text(AppException.from(e).message)));
                    }
                  }
                },
                child: const Text('Publish'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
