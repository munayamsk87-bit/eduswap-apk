import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/async_value_view.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/loading_skeleton.dart';
import '../../../../core/widgets/section_header.dart';
import '../../../../shared/models/resource.dart';
import '../../../../shared/providers/auth_providers.dart';
import '../../../../shared/providers/feed_providers.dart';
import '../../../../shared/widgets/question_tile.dart';
import '../../../../shared/widgets/resource_card.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  static const _subjects = [
    'Mathematics',
    'Physics',
    'Chemistry',
    'Biology',
    'English',
    'Accountancy',
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final user = ref.watch(appUserProvider).valueOrNull;
    final recent = ref.watch(recentResourcesProvider);
    final questions = ref.watch(popularQuestionsProvider);
    final swaps = ref.watch(incomingSwapsProvider).valueOrNull ?? const [];
    final unread = ref.watch(unreadNotificationsProvider).valueOrNull ?? 0;

    return Scaffold(
      body: RefreshIndicator(
        onRefresh: () async {
          ref.invalidate(recentResourcesProvider);
          ref.invalidate(popularQuestionsProvider);
        },
        child: CustomScrollView(
          slivers: [
            SliverAppBar(
              floating: true,
              titleSpacing: 16,
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Hi ${user?.displayName.split(' ').first ?? 'there'} 👋',
                      style: theme.textTheme.titleMedium
                          ?.copyWith(fontWeight: FontWeight.w700)),
                  Text('Ready to learn something new?',
                      style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant)),
                ],
              ),
              actions: [
                IconButton(
                  onPressed: () => context.push(AppRoutes.wishlist),
                  icon: const Icon(Icons.bookmark_border),
                  tooltip: 'Wishlist',
                ),
                Stack(
                  alignment: Alignment.center,
                  children: [
                    IconButton(
                      onPressed: () => context.push(AppRoutes.notifications),
                      icon: const Icon(Icons.notifications_none),
                      tooltip: 'Notifications',
                    ),
                    if (unread > 0)
                      Positioned(
                        top: 8,
                        right: 8,
                        child: Container(
                          padding: const EdgeInsets.all(5),
                          decoration: const BoxDecoration(
                            color: AppColors.error,
                            shape: BoxShape.circle,
                          ),
                          child: Text('$unread',
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold)),
                        ),
                      ),
                  ],
                ),
                const SizedBox(width: 8),
              ],
            ),

            // Search bar
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
                child: GestureDetector(
                  onTap: () => context.go(AppRoutes.explore),
                  child: AbsorbPointer(
                    child: TextField(
                      decoration: InputDecoration(
                        hintText: 'Search notes, books, papers…',
                        prefixIcon: const Icon(Icons.search),
                        suffixIcon: IconButton(
                          icon: const Icon(Icons.tune),
                          onPressed: () {},
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),

            // Subject shortcuts
            SliverToBoxAdapter(
              child: SizedBox(
                height: 44,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
                  itemCount: _subjects.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (_, i) => ActionChip(
                    label: Text(_subjects[i]),
                    onPressed: () => context.go(AppRoutes.explore),
                  ),
                ),
              ),
            ),

            // AI quick access
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: _AiBanner(onTap: () => context.push(AppRoutes.aiAssistant)),
              ),
            ),

            // Active swaps
            if (swaps.isNotEmpty)
              SliverToBoxAdapter(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SectionHeader(
                      title: 'Active swap requests',
                      action: TextButton(
                        onPressed: () => context.push(AppRoutes.swapRequests),
                        child: const Text('See all'),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Text(
                        '${swaps.length} request${swaps.length == 1 ? '' : 's'} waiting for you',
                        style: theme.textTheme.bodySmall,
                      ),
                    ),
                  ],
                ),
              ),

            // Recently uploaded
            SliverToBoxAdapter(
              child: SectionHeader(
                title: 'Recently uploaded',
                action: TextButton(
                  onPressed: () => context.go(AppRoutes.explore),
                  child: const Text('Explore'),
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: AsyncValueView<List<Resource>>(
                value: recent,
                onRetry: () => ref.invalidate(recentResourcesProvider),
                loading: SizedBox(
                  height: 140,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: 3,
                    separatorBuilder: (_, __) => const SizedBox(width: 12),
                    itemBuilder: (_, __) =>
                        const SizedBox(width: 280, child: LoadingSkeleton(height: 130)),
                  ),
                ),
                isEmpty: (list) => list.isEmpty,
                emptyTitle: 'No resources yet',
                emptyMessage:
                    'Be the first to share notes or a book — it only takes a minute.',
                data: (list) => SizedBox(
                  height: 150,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: list.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 12),
                    itemBuilder: (_, i) {
                      final r = list[i];
                      return SizedBox(
                        width: 300,
                        child: ResourceCard(
                          resource: r,
                          onTap: () => context.push(AppRoutes.resource(r.id)),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),

            // Popular discussions
            SliverToBoxAdapter(
              child: SectionHeader(
                title: 'Popular discussions',
                action: TextButton(
                  onPressed: () => context.push(AppRoutes.community),
                  child: const Text('See all'),
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: AsyncValueView(
                value: questions,
                onRetry: () => ref.invalidate(popularQuestionsProvider),
                loading: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Column(children: const [
                    LoadingSkeleton(height: 84),
                    SizedBox(height: 12),
                    LoadingSkeleton(height: 84),
                  ]),
                ),
                isEmpty: (list) => list.isEmpty,
                emptyTitle: 'No questions yet',
                emptyMessage: 'Ask the first question and get help from peers.',
                data: (list) => Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Column(
                    children: [
                      for (final q in list.take(3))
                        Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: QuestionTile(
                            question: q,
                            onTap: () =>
                                context.push(AppRoutes.question(q.id)),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),

            const SliverToBoxAdapter(child: SizedBox(height: 32)),
          ],
        ),
      ),
    );
  }
}

class _AiBanner extends StatelessWidget {
  const _AiBanner({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppColors.primary, AppColors.primaryLight],
        ),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Icon(Icons.psychology_alt_rounded,
                      color: Colors.white, size: 28),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('AI Study Assistant',
                          style: theme.textTheme.titleMedium?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.w700)),
                      const SizedBox(height: 2),
                      Text('Explain, summarize, quiz yourself',
                          style: theme.textTheme.bodySmall
                              ?.copyWith(color: Colors.white70)),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right, color: Colors.white),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
