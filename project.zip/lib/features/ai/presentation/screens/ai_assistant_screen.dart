import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/enums.dart';
import '../../../../core/errors/app_exception.dart';
import '../../../../core/theme/app_colors.dart';
import '../../data/ai_repository.dart';

/// AI Study Assistant. Talks to a secure server-side proxy — keys never live
/// in the app. If no provider is configured, it says so plainly.
class AiAssistantScreen extends ConsumerStatefulWidget {
  const AiAssistantScreen({super.key});

  @override
  ConsumerState<AiAssistantScreen> createState() => _AiAssistantScreenState();
}

class _AiAssistantScreenState extends ConsumerState<AiAssistantScreen> {
  final _input = TextEditingController();
  AiTask _task = AiTask.explain;
  EducationLevel _level = EducationLevel.secondary;
  String? _answer;
  bool _busy = false;

  static const _taskLabels = {
    AiTask.explain: 'Explain a concept',
    AiTask.summarize: 'Summarize notes',
    AiTask.practiceQuestions: 'Practice questions',
    AiTask.generateMcq: 'Generate MCQs',
    AiTask.explainMistake: 'Explain my mistake',
    AiTask.revisionNotes: 'Revision notes',
    AiTask.studyPlan: 'Study plan',
    AiTask.flashcards: 'Flashcards',
    AiTask.translate: 'Translate',
  };

  @override
  void dispose() {
    _input.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    if (_input.text.trim().isEmpty) return;
    setState(() {
      _busy = true;
      _answer = null;
    });
    try {
      final text = await ref.read(aiRepositoryProvider).run(
            task: _task,
            input: _input.text.trim(),
            level: _level,
          );
      if (mounted) setState(() => _answer = text);
    } on AppException catch (e) {
      if (mounted) setState(() => _answer = '⚠️ ${e.message}');
    } catch (e) {
      if (mounted) setState(() => _answer = '⚠️ ${AppException.from(e).message}');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('AI Study Assistant')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.sky,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                const Icon(Icons.info_outline, color: AppColors.secondary),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'AI answers are generated suggestions, not verified facts. '
                    'Always double-check with your textbook.',
                    style: theme.textTheme.bodySmall,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Text('What do you need help with?',
              style: theme.textTheme.titleSmall
                  ?.copyWith(fontWeight: FontWeight.w600)),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _taskLabels.entries
                .map((e) => ChoiceChip(
                      label: Text(e.value),
                      selected: _task == e.key,
                      onSelected: (_) => setState(() => _task = e.key),
                    ))
                .toList(),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<EducationLevel>(
            value: _level,
            decoration: const InputDecoration(labelText: 'Explain for level'),
            items: EducationLevel.values
                .map((e) => DropdownMenuItem(value: e, child: Text(e.name)))
                .toList(),
            onChanged: (v) => setState(() => _level = v ?? _level),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _input,
            maxLines: 5,
            decoration: const InputDecoration(
              hintText: 'Paste a question, a topic, or your notes…',
              alignLabelWithHint: true,
            ),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: _busy ? null : _run,
            icon: _busy
                ? const SizedBox(
                    height: 18,
                    width: 18,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: Colors.white),
                  )
                : const Icon(Icons.auto_awesome),
            label: const Text('Ask'),
          ),
          if (_answer != null) ...[
            const SizedBox(height: 24),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.smart_toy_outlined,
                            color: AppColors.primary),
                        const SizedBox(width: 8),
                        Text('Assistant',
                            style: theme.textTheme.titleSmall
                                ?.copyWith(fontWeight: FontWeight.w700)),
                      ],
                    ),
                    const SizedBox(height: 10),
                    SelectableText(_answer!, style: theme.textTheme.bodyLarge),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
