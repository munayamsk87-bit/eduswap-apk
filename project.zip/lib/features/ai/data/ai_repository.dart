import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/enums.dart';
import '../../../core/errors/app_exception.dart';
import '../../../shared/providers/firebase_providers.dart';

/// The kinds of help the AI Study Assistant can give.
enum AiTask {
  explain,
  summarize,
  practiceQuestions,
  generateMcq,
  explainMistake,
  revisionNotes,
  studyPlan,
  flashcards,
  translate,
}

/// Calls the secure server-side AI proxy. API keys live only on the server —
/// nothing secret is ever embedded in the Flutter app.
class AiRepository {
  AiRepository(this._functions);

  final FirebaseFunctions _functions;

  Future<String> run({
    required AiTask task,
    required String input,
    EducationLevel level = EducationLevel.secondary,
    AppLanguage language = AppLanguage.english,
  }) async {
    try {
      final res = await _functions.httpsCallable('aiAssistant').call({
        'task': task.name,
        'input': input,
        'level': level.name,
        'language': language.name,
      });
      final data = (res.data as Map);
      if (data['configured'] == false) {
        throw const AppException(
          'AI is not configured yet. Add an LLM provider key on the server '
          '(see README) to enable the assistant.',
        );
      }
      return data['text'] as String? ?? '';
    } on FirebaseFunctionsException catch (e) {
      throw AppException(e.message ?? 'AI request failed.', code: e.code);
    }
  }
}

final aiRepositoryProvider = Provider<AiRepository>((ref) {
  return AiRepository(ref.watch(functionsProvider));
});
