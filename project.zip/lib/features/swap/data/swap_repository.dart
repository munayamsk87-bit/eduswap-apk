import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/app_constants.dart';
import '../../../core/constants/enums.dart';
import '../../../shared/models/resource.dart';
import '../../../shared/models/swap_request.dart';
import '../../../shared/providers/firebase_providers.dart';

/// Book-swap workflow. Every state transition is applied by a Cloud Function
/// so neither student can forge the other's action.
class SwapRepository {
  SwapRepository(this._db, this._functions);

  final FirebaseFirestore _db;
  final FirebaseFunctions _functions;

  CollectionReference<Map<String, dynamic>> get _col =>
      _db.collection(AppConstants.swapRequestsCol);

  Future<String> createRequest({
    required Resource resource,
    required String requesterId,
    required String requesterName,
    String? offeredResourceId,
    String? offeredResourceTitle,
    String message = '',
  }) async {
    final callable = _functions.httpsCallable('createSwapRequest');
    final res = await callable.call({
      'resourceId': resource.id,
      'resourceTitle': resource.title,
      'ownerId': resource.ownerId,
      'ownerName': resource.ownerName,
      'requesterId': requesterId,
      'requesterName': requesterName,
      'offeredResourceId': offeredResourceId,
      'offeredResourceTitle': offeredResourceTitle,
      'message': message,
    });
    return (res.data as Map)['id'] as String;
  }

  Stream<List<SwapRequest>> watchOutgoing(String uid) {
    return _col
        .where('requesterId', isEqualTo: uid)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((s) => s.docs.map((d) => SwapRequest.fromJson(d.data())).toList());
  }

  Stream<List<SwapRequest>> watchIncoming(String uid) {
    return _col
        .where('ownerId', isEqualTo: uid)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((s) => s.docs.map((d) => SwapRequest.fromJson(d.data())).toList());
  }

  /// One server-validated transition. [action] is one of:
  /// accept | decline | cancel | complete | dispute.
  Future<void> transition({
    required String requestId,
    required String action,
  }) async {
    final callable = _functions.httpsCallable('transitionSwapRequest');
    await callable.call({'requestId': requestId, 'action': action});
  }

  Future<void> submitFeedback({
    required String requestId,
    required int rating,
    String feedback = '',
  }) async {
    final callable = _functions.httpsCallable('submitSwapFeedback');
    await callable.call({
      'requestId': requestId,
      'rating': rating,
      'feedback': feedback,
    });
  }

  Future<SwapStatus> statusOf(String requestId) async {
    final doc = await _col.doc(requestId).get();
    return SwapStatus.values.byName(doc.data()?['status'] as String);
  }
}

final swapRepositoryProvider = Provider<SwapRepository>((ref) {
  return SwapRepository(
    ref.watch(firestoreProvider),
    ref.watch(functionsProvider),
  );
});
