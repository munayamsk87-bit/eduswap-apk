import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/enums.dart';
import '../../../../core/errors/app_exception.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/async_value_view.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/loading_skeleton.dart';
import '../../../../shared/models/swap_request.dart';
import '../../../../shared/providers/feed_providers.dart';
import '../../data/swap_repository.dart';

class SwapRequestsScreen extends ConsumerWidget {
  const SwapRequestsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Swap requests'),
          bottom: const TabBar(
            tabs: [Tab(text: 'Incoming'), Tab(text: 'Outgoing')],
          ),
        ),
        body: TabBarView(
          children: [
            _SwapList(
              provider: incomingSwapsProvider,
              isIncoming: true,
            ),
            _SwapList(
              provider: outgoingSwapsProvider,
              isIncoming: false,
            ),
          ],
        ),
      ),
    );
  }
}

class _SwapList extends ConsumerWidget {
  const _SwapList({required this.provider, required this.isIncoming});

  final StreamProvider<List<SwapRequest>> provider;
  final bool isIncoming;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final value = ref.watch(provider);
    return AsyncValueView<List<SwapRequest>>(
      value: value,
      onRetry: () => ref.invalidate(provider),
      loading: LoadingSkeleton.list(count: 4, height: 130),
      isEmpty: (l) => l.isEmpty,
      emptyTitle: isIncoming ? 'No incoming requests' : 'No outgoing requests',
      emptyMessage: isIncoming
          ? 'When someone wants your book, it will show up here.'
          : 'Request a book swap from a listing to get started.',
      data: (list) => ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: list.length,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (_, i) =>
            _SwapCard(request: list[i], isIncoming: isIncoming),
      ),
    );
  }
}

class _SwapCard extends ConsumerStatefulWidget {
  const _SwapCard({required this.request, required this.isIncoming});

  final SwapRequest request;
  final bool isIncoming;

  @override
  ConsumerState<_SwapCard> createState() => _SwapCardState();
}

class _SwapCardState extends ConsumerState<_SwapCard> {
  bool _busy = false;

  Future<void> _act(String action) async {
    setState(() => _busy = true);
    try {
      await ref
          .read(swapRepositoryProvider)
          .transition(requestId: widget.request.id, action: action);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Request ${action}ed.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(AppException.from(e).message)));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final r = widget.request;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(r.resourceTitle,
                      style: theme.textTheme.titleSmall
                          ?.copyWith(fontWeight: FontWeight.w600)),
                ),
                _statusChip(theme, r.status),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              widget.isIncoming
                  ? 'From ${r.requesterName}'
                  : 'To ${r.ownerName}',
              style: theme.textTheme.bodySmall,
            ),
            if (r.message.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text('“${r.message}”',
                  style: theme.textTheme.bodyMedium
                      ?.copyWith(fontStyle: FontStyle.italic)),
            ],
            const SizedBox(height: 12),
            if (_busy)
              const LinearProgressIndicator()
            else
              _actions(theme, r),
          ],
        ),
      ),
    );
  }

  Widget _actions(ThemeData theme, SwapRequest r) {
    final buttons = <Widget>[];
    if (widget.isIncoming && r.status == SwapStatus.requested) {
      buttons.add(Expanded(
        child: FilledButton(
          onPressed: () => _act('accept'),
          child: const Text('Accept'),
        ),
      ));
      buttons.add(const SizedBox(width: 10));
      buttons.add(Expanded(
        child: OutlinedButton(
          onPressed: () => _act('decline'),
          child: const Text('Decline'),
        ),
      ));
    } else if (!widget.isIncoming && r.status == SwapStatus.requested) {
      buttons.add(Expanded(
        child: OutlinedButton(
          onPressed: () => _act('cancel'),
          child: const Text('Cancel'),
        ),
      ));
    } else if (r.status == SwapStatus.accepted) {
      buttons.add(Expanded(
        child: FilledButton(
          onPressed: () => _act('complete'),
          child: const Text('Mark completed'),
        ),
      ));
    } else {
      buttons.add(const Expanded(
        child: Text('This request is closed.',
            style: TextStyle(fontStyle: FontStyle.italic)),
      ));
    }
    return Row(children: buttons);
  }

  Widget _statusChip(ThemeData theme, SwapStatus status) {
    final color = switch (status) {
      SwapStatus.requested => AppColors.warning,
      SwapStatus.accepted => AppColors.secondary,
      SwapStatus.completed => AppColors.success,
      SwapStatus.declined || SwapStatus.cancelled || SwapStatus.expired =>
        theme.colorScheme.outline,
      SwapStatus.disputed => AppColors.error,
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.14),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(status.name,
          style: theme.textTheme.labelSmall?.copyWith(color: color)),
    );
  }
}
