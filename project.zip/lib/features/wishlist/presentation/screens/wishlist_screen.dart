import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/widgets/async_value_view.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/loading_skeleton.dart';
import '../../../../shared/models/saved_resource.dart';
import '../../../../shared/providers/feed_providers.dart';

class WishlistScreen extends ConsumerWidget {
  const WishlistScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final saved = ref.watch(mySavedProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Wishlist')),
      body: AsyncValueView<List<SavedResource>>(
        value: saved,
        onRetry: () => ref.invalidate(mySavedProvider),
        loading: LoadingSkeleton.list(count: 5, height: 80),
        isEmpty: (l) => l.isEmpty,
        emptyTitle: 'Nothing saved yet',
        emptyMessage: 'Tap Save on any resource to keep it here.',
        data: (list) => ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: list.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (_, i) {
            final s = list[i];
            return Card(
              child: ListTile(
                leading: const Icon(Icons.bookmark),
                title: Text(s.resourceTitle ?? 'Saved resource'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => context.push(AppRoutes.resource(s.resourceId)),
              ),
            );
          },
        ),
      ),
    );
  }
}
