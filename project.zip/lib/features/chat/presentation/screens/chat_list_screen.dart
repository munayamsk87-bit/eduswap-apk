import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/widgets/async_value_view.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/loading_skeleton.dart';
import '../../../../shared/models/conversation.dart';
import '../../../../shared/providers/auth_providers.dart';
import '../../../../shared/providers/feed_providers.dart';

class ChatListScreen extends ConsumerWidget {
  const ChatListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final uid = ref.watch(currentUserProvider)?.uid;
    final conversations = ref.watch(myConversationsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Messages')),
      body: AsyncValueView<List<Conversation>>(
        value: conversations,
        onRetry: () => ref.invalidate(myConversationsProvider),
        loading: LoadingSkeleton.list(count: 6, height: 76),
        isEmpty: (list) => list.isEmpty,
        emptyTitle: 'No conversations yet',
        emptyMessage:
            'Chat opens when you request a book swap or contact an uploader.',
        data: (list) => ListView.separated(
          padding: const EdgeInsets.symmetric(vertical: 8),
          itemCount: list.length,
          separatorBuilder: (_, __) => const Divider(height: 1, indent: 76),
          itemBuilder: (_, i) {
            final c = list[i];
            final unread = uid == null ? 0 : (c.unread[uid] ?? 0);
            final peer = _peerName(c, uid);
            return ListTile(
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              leading: CircleAvatar(
                child: Text(peer.isEmpty ? '?' : peer[0].toUpperCase()),
              ),
              title: Text(peer,
                  maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: Text(
                c.lastMessage?.isNotEmpty == true ? c.lastMessage! : 'No messages yet',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              trailing: unread > 0
                  ? CircleAvatar(
                      radius: 12,
                      backgroundColor: Theme.of(context).colorScheme.primary,
                      child: Text('$unread',
                          style: const TextStyle(
                              color: Colors.white, fontSize: 11)),
                    )
                  : null,
              onTap: () => context.push(
                '${AppRoutes.conversation(c.id)}?peer=${Uri.encodeComponent(peer)}',
              ),
            );
          },
        ),
      ),
    );
  }

  String _peerName(Conversation c, String? uid) {
    final names = c.participantNames;
    if (names == null) return 'Student';
    for (final entry in names.entries) {
      if (entry.key != uid) return entry.value;
    }
    return names.values.isEmpty ? 'Student' : names.values.first;
  }
}
