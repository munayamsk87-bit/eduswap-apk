import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/app_exception.dart';
import '../../../../shared/models/message.dart';
import '../../../../shared/providers/auth_providers.dart';
import '../../../../shared/providers/feed_providers.dart';
import '../../data/chat_repository.dart';

/// A 1:1 conversation. Membership is enforced by Security Rules; the client
/// only ever clears its own unread counter.
class ChatRoomScreen extends ConsumerStatefulWidget {
  const ChatRoomScreen({
    super.key,
    required this.conversationId,
    this.peerName = 'Chat',
  });

  final String conversationId;
  final String peerName;

  @override
  ConsumerState<ChatRoomScreen> createState() => _ChatRoomScreenState();
}

class _ChatRoomScreenState extends ConsumerState<ChatRoomScreen> {
  final _input = TextEditingController();
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _markRead());
  }

  @override
  void dispose() {
    _input.dispose();
    super.dispose();
  }

  Future<void> _markRead() async {
    final uid = ref.read(currentUserProvider);
    if (uid == null) return;
    await ref.read(chatRepositoryProvider).markRead(widget.conversationId, uid);
  }

  Future<void> _send() async {
    final text = _input.text.trim();
    if (text.isEmpty || _sending) return;
    final user = ref.read(appUserProvider).valueOrNull;
    final uid = ref.read(currentUserProvider);
    final convo = ref.read(conversationProvider(widget.conversationId)).valueOrNull;
    if (user == null || uid == null || convo == null) return;

    setState(() => _sending = true);
    try {
      await ref.read(chatRepositoryProvider).sendMessage(
            conversationId: widget.conversationId,
            senderId: uid,
            senderName: user.displayName,
            participants: convo.participants,
            text: text,
          );
      _input.clear();
    } on AppException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(e.message)));
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final uid = ref.watch(currentUserProvider);
    final messages = ref.watch(messagesProvider(widget.conversationId));
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.peerName),
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) => _onMenu(v, uid),
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'block', child: Text('Block user')),
              PopupMenuItem(value: 'report', child: Text('Report')),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: messages.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, _) => Center(
                child: Text(AppException.from(e).message,
                    textAlign: TextAlign.center),
              ),
              data: (list) {
                if (list.isEmpty) {
                  return const Center(
                    child: Text('Say hello — start the conversation.'),
                  );
                }
                return ListView.builder(
                  reverse: true,
                  padding: const EdgeInsets.all(16),
                  itemCount: list.length,
                  itemBuilder: (_, i) {
                    final m = list[i];
                    final mine = m.senderId == uid;
                    return _bubble(theme, m, mine);
                  },
                );
              },
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _input,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => _send(),
                      decoration: const InputDecoration(
                        hintText: 'Message…',
                        contentPadding:
                            EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: _sending ? null : _send,
                    icon: _sending
                        ? const SizedBox(
                            height: 18,
                            width: 18,
                            child: CircularProgressIndicator(
                                strokeWidth: 2, color: Colors.white),
                          )
                        : const Icon(Icons.send_rounded),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _bubble(ThemeData theme, Message m, bool mine) {
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        constraints: const BoxConstraints(maxWidth: 300),
        decoration: BoxDecoration(
          color: mine
              ? theme.colorScheme.primary
              : theme.colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Text(
          m.text ?? (m.imageUrl != null ? 'Photo' : ''),
          style: TextStyle(
            color: mine ? Colors.white : theme.colorScheme.onSurface,
          ),
        ),
      ),
    );
  }

  Future<void> _onMenu(String action, String? uid) async {
    if (uid == null) return;
    final convo =
        ref.read(conversationProvider(widget.conversationId)).valueOrNull;
    if (convo == null) return;
    final peer = convo.participants.firstWhere((p) => p != uid,
        orElse: () => uid);
    try {
      if (action == 'block') {
        await ref
            .read(chatRepositoryProvider)
            .blockUser(currentUid: uid, blockedUid: peer);
      } else {
        await ref.read(chatRepositoryProvider).reportMessage(
              reporterId: uid,
              messageId: widget.conversationId,
            );
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('$action submitted.')));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(AppException.from(e).message)));
      }
    }
  }
}
