import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/app_constants.dart';
import '../../../core/errors/app_exception.dart';
import '../../../shared/models/conversation.dart';
import '../../../shared/models/message.dart';
import '../../../shared/providers/firebase_providers.dart';

/// Real-time 1:1 messaging. Membership is enforced by Security Rules; the
/// client never writes another user's read state.
class ChatRepository {
  ChatRepository(this._db);

  final FirebaseFirestore _db;

  CollectionReference<Map<String, dynamic>> get _conversations =>
      _db.collection(AppConstants.conversationsCol);

  /// Finds an existing conversation for the pair (and optional resource) or
  /// creates one. Deterministic id prevents duplicate threads.
  Future<String> getOrCreateConversation({
    required String currentUid,
    required String otherUid,
    required Map<String, String> names,
    String? resourceId,
    String? resourceTitle,
    String? swapRequestId,
  }) async {
    final parts = [currentUid, otherUid]..sort();
    final id =
        '${parts.first}_${parts.last}${resourceId == null ? '' : '_$resourceId'}';

    final ref = _conversations.doc(id);
    final existing = await ref.get();
    if (!existing.exists) {
      await ref.set({
        'participants': parts,
        'participantNames': names,
        'resourceId': resourceId,
        'resourceTitle': resourceTitle,
        'swapRequestId': swapRequestId,
        'lastMessage': '',
        'unread': {for (final p in parts) p: 0},
        'createdAt': Timestamp.fromDate(DateTime.now()),
      });
    }
    return id;
  }

  Stream<List<Conversation>> watchConversations(String uid) {
    return _conversations
        .where('participants', arrayContains: uid)
        .orderBy('lastMessageAt', descending: true)
        .snapshots()
        .map((s) => s.docs.map((d) => Conversation.fromJson(d.data())).toList());
  }

  /// Paginated message history, newest first.
  Stream<List<Message>> watchMessages(
    String conversationId, {
    int limit = AppConstants.pageSize,
  }) {
    return _conversations
        .doc(conversationId)
        .collection(AppConstants.messagesSubCol)
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .snapshots()
        .map((s) => s.docs.map((d) => Message.fromJson(d.data())).toList());
  }

  Future<void> sendMessage({
    required String conversationId,
    required String senderId,
    required String senderName,
    required List<String> participants,
    String? text,
    String? imageUrl,
    String? replyToId,
  }) async {
    if ((text == null || text.trim().isEmpty) && imageUrl == null) {
      throw const AppException('Message cannot be empty.');
    }
    final convRef = _conversations.doc(conversationId);
    final msgRef = convRef.collection(AppConstants.messagesSubCol).doc();
    final now = Timestamp.fromDate(DateTime.now());

    final batch = _db.batch();
    batch.set(msgRef, {
      'senderId': senderId,
      'senderName': senderName,
      'text': text?.trim(),
      'imageUrl': imageUrl,
      'replyToId': replyToId,
      'readBy': [senderId],
      'createdAt': now,
    });
    // Bump the conversation preview and the recipient's unread counter.
    batch.update(convRef, {
      'lastMessage': imageUrl != null ? 'Photo' : text?.trim(),
      'lastMessageAt': now,
      for (final p in participants)
        if (p != senderId) 'unread.$p': FieldValue.increment(1),
    });
    await batch.commit();
  }

  /// Marks the conversation read for [uid] only. Rules reject other users.
  Future<void> markRead(String conversationId, String uid) async {
    await _conversations.doc(conversationId).update({'unread.$uid': 0});
  }

  Future<void> reportMessage({
    required String reporterId,
    required String messageId,
    String details = '',
  }) async {
    await _db.collection(AppConstants.reportsCol).add({
      'reporterId': reporterId,
      'targetType': 'message',
      'targetId': messageId,
      'reason': 'Inappropriate message',
      'details': details,
      'status': 'open',
      'createdAt': Timestamp.fromDate(DateTime.now()),
    });
  }

  Future<void> blockUser({
    required String currentUid,
    required String blockedUid,
  }) async {
    await _db
        .collection(AppConstants.userBlocksCol)
        .doc('${currentUid}_$blockedUid')
        .set({
      'blockerId': currentUid,
      'blockedId': blockedUid,
      'createdAt': Timestamp.fromDate(DateTime.now()),
    });
  }
}

final chatRepositoryProvider = Provider<ChatRepository>((ref) {
  return ChatRepository(ref.watch(firestoreProvider));
});
