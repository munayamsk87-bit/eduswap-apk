import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/enums.dart';
import '../../../../core/errors/app_exception.dart';
import '../../../../core/router/app_router.dart';
import '../../../../shared/providers/auth_providers.dart';
import '../../data/auth_repository.dart';

/// Collects only what EduSwap needs to personalize learning. Never asks for a
/// home address or precise location.
class ProfileSetupScreen extends ConsumerStatefulWidget {
  const ProfileSetupScreen({super.key});

  @override
  ConsumerState<ProfileSetupScreen> createState() => _ProfileSetupScreenState();
}

class _ProfileSetupScreenState extends ConsumerState<ProfileSetupScreen> {
  final _name = TextEditingController();
  final _institution = TextEditingController();
  final _board = TextEditingController();
  final _locality = TextEditingController();

  EducationLevel _level = EducationLevel.secondary;
  AppLanguage _language = AppLanguage.english;
  final Set<String> _subjects = {};
  final Set<String> _interests = {};
  bool _busy = false;

  static const _subjectOptions = [
    'Mathematics',
    'Physics',
    'Chemistry',
    'Biology',
    'English',
    'Accountancy',
    'Computer Science',
    'History',
    'Geography',
  ];
  static const _interestOptions = [
    'Coding',
    'Graphic design',
    'Presentation skills',
    'Study techniques',
    'Languages',
    'Public speaking',
  ];

  @override
  void initState() {
    super.initState();
    final profile = ref.read(appUserProvider).valueOrNull;
    if (profile != null) _name.text = profile.displayName;
  }

  @override
  void dispose() {
    _name.dispose();
    _institution.dispose();
    _board.dispose();
    _locality.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final uid = ref.read(currentUserProvider)?.uid;
    if (uid == null) return;
    if (_name.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please enter a display name.')));
      return;
    }
    setState(() => _busy = true);
    try {
      await ref.read(authRepositoryProvider).completeOnboarding(
            uid: uid,
            displayName: _name.text.trim(),
            educationLevel: _level,
            institution: _institution.text.trim().isEmpty
                ? null
                : _institution.text.trim(),
            board: _board.text.trim().isEmpty ? null : _board.text.trim(),
            language: _language,
            subjects: _subjects.toList(),
            interests: _interests.toList(),
            locality:
                _locality.text.trim().isEmpty ? null : _locality.text.trim(),
          );
      if (!mounted) return;
      context.go(AppRoutes.home);
    } on AppException catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Set up your profile')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            Text('Tell us a little about you',
                style: theme.textTheme.titleLarge
                    ?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text(
              'This personalizes your home feed. Everything here is optional '
              'and editable later — we never ask for your home address.',
              style: theme.textTheme.bodyMedium
                  ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
            ),
            const SizedBox(height: 24),
            TextField(
              controller: _name,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(
                labelText: 'Display name',
                prefixIcon: Icon(Icons.person_outline),
              ),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<EducationLevel>(
              value: _level,
              decoration: const InputDecoration(
                labelText: 'Class / education level',
                prefixIcon: Icon(Icons.school_outlined),
              ),
              items: EducationLevel.values
                  .map((e) => DropdownMenuItem(
                        value: e,
                        child: Text(_levelLabel(e)),
                      ))
                  .toList(),
              onChanged: (v) => setState(() => _level = v ?? _level),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _institution,
              decoration: const InputDecoration(
                labelText: 'School / college (optional)',
                prefixIcon: Icon(Icons.apartment_outlined),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _board,
              decoration: const InputDecoration(
                labelText: 'Board / curriculum (optional)',
                prefixIcon: Icon(Icons.assignment_outlined),
              ),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<AppLanguage>(
              value: _language,
              decoration: const InputDecoration(
                labelText: 'Preferred language',
                prefixIcon: Icon(Icons.translate_outlined),
              ),
              items: AppLanguage.values
                  .map((e) => DropdownMenuItem(
                        value: e,
                        child: Text(_languageLabel(e)),
                      ))
                  .toList(),
              onChanged: (v) => setState(() => _language = v ?? _language),
            ),
            const SizedBox(height: 24),
            _chipSection(
              theme,
              'Subjects of interest',
              _subjectOptions,
              _subjects,
            ),
            const SizedBox(height: 24),
            _chipSection(
              theme,
              'Learning interests & skills',
              _interestOptions,
              _interests,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _locality,
              decoration: const InputDecoration(
                labelText: 'Approximate locality (optional)',
                prefixIcon: Icon(Icons.location_city_outlined),
                helperText: 'City or area only — never your full address.',
              ),
            ),
            const SizedBox(height: 28),
            FilledButton(
              onPressed: _busy ? null : _save,
              child: _busy
                  ? const SizedBox(
                      height: 22,
                      width: 22,
                      child: CircularProgressIndicator(strokeWidth: 2.5),
                    )
                  : const Text('Finish setup'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _chipSection(
    ThemeData theme,
    String title,
    List<String> options,
    Set<String> selected,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title,
            style: theme.textTheme.titleSmall
                ?.copyWith(fontWeight: FontWeight.w600)),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: options.map((o) {
            final isSelected = selected.contains(o);
            return FilterChip(
              label: Text(o),
              selected: isSelected,
              onSelected: (v) =>
                  setState(() => v ? selected.add(o) : selected.remove(o)),
            );
          }).toList(),
        ),
      ],
    );
  }

  String _levelLabel(EducationLevel e) => switch (e) {
        EducationLevel.primary => 'Primary',
        EducationLevel.secondary => 'Secondary (Class 6–10)',
        EducationLevel.higherSecondary => 'Higher secondary (Class 11–12)',
        EducationLevel.undergraduate => 'Undergraduate',
        EducationLevel.postgraduate => 'Postgraduate',
        EducationLevel.other => 'Other',
      };

  String _languageLabel(AppLanguage l) => switch (l) {
        AppLanguage.english => 'English',
        AppLanguage.bengali => 'Bengali',
        AppLanguage.hindi => 'Hindi',
      };
}
