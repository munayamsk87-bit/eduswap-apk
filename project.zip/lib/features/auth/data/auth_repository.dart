import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../../../core/constants/app_constants.dart';
import '../../../core/constants/enums.dart';
import '../../../core/errors/app_exception.dart';
import '../../../shared/models/app_user.dart';
import '../../../shared/providers/firebase_providers.dart';

/// Authentication + user-profile operations. Real Firebase only — no mocks.
class AuthRepository {
  AuthRepository(this._auth, this._db);

  final FirebaseAuth _auth;
  final FirebaseFirestore _db;

  Stream<User?> authStateChanges() => _auth.authStateChanges();

  User? get currentUser => _auth.currentUser;

  /// The signed-in user's id, or null.
  String? get currentUid => _auth.currentUser?.uid;

  /// Live profile document for the signed-in user.
  Stream<AppUser?> watchProfile(String uid) {
    return _db
        .collection(AppConstants.usersCol)
        .doc(uid)
        .snapshots()
        .map((doc) => doc.exists ? AppUser.fromJson(doc.data()!) : null);
  }

  Future<AppUser?> fetchProfile(String uid) async {
    final doc = await _db.collection(AppConstants.usersCol).doc(uid).get();
    return doc.exists ? AppUser.fromJson(doc.data()!) : null;
  }

  Future<void> register({
    required String email,
    required String password,
    required String displayName,
  }) async {
    try {
      final cred = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      final user = cred.user!;
      await user.updateDisplayName(displayName.trim());
      await user.sendEmailVerification();
      await _db.collection(AppConstants.usersCol).doc(user.uid).set(
            AppUser(
              uid: user.uid,
              displayName: displayName.trim(),
              email: email.trim(),
              createdAt: DateTime.now(),
              updatedAt: DateTime.now(),
              onboardingComplete: false,
            ).toJson(),
          );
    } on FirebaseAuthException catch (e) {
      throw AppException(_mapAuthError(e), code: e.code);
    }
  }

  Future<void> signIn({required String email, required String password}) async {
    try {
      await _auth.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
    } on FirebaseAuthException catch (e) {
      throw AppException(_mapAuthError(e), code: e.code);
    }
  }

  Future<void> signInWithGoogle() async {
    try {
      final googleUser = await GoogleSignIn().signIn();
      if (googleUser == null) return; // user cancelled
      final googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );
      final cred = await _auth.signInWithCredential(credential);
      // Create the profile doc on first Google sign-in.
      final user = cred.user!;
      final ref = _db.collection(AppConstants.usersCol).doc(user.uid);
      if (!(await ref.get()).exists) {
        await ref.set(
          AppUser(
            uid: user.uid,
            displayName: user.displayName ?? 'Student',
            email: user.email ?? '',
            photoUrl: user.photoURL,
            onboardingComplete: false,
            createdAt: DateTime.now(),
            updatedAt: DateTime.now(),
          ).toJson(),
        );
      }
    } on FirebaseAuthException catch (e) {
      throw AppException(_mapAuthError(e), code: e.code);
    }
  }

  Future<void> sendPasswordReset(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email.trim());
    } on FirebaseAuthException catch (e) {
      throw AppException(_mapAuthError(e), code: e.code);
    }
  }

  Future<void> sendEmailVerification() => _auth.currentUser!.sendEmailVerification();

  Future<void> signOut() async {
    await GoogleSignIn().signOut();
    await _auth.signOut();
  }

  /// Updates the onboarding/profile fields collected after registration.
  Future<void> completeOnboarding({
    required String uid,
    required String displayName,
    required EducationLevel educationLevel,
    String? institution,
    String? board,
    required AppLanguage language,
    required List<String> subjects,
    required List<String> interests,
    String? locality,
  }) async {
    await _db.collection(AppConstants.usersCol).doc(uid).update({
      'displayName': displayName,
      'educationLevel': educationLevel.name,
      'institution': institution,
      'board': board,
      'preferredLanguage': language.name,
      'subjects': subjects,
      'interests': interests,
      'locality': locality,
      'onboardingComplete': true,
      'updatedAt': Timestamp.fromDate(DateTime.now()),
    });
  }

  Future<void> updateProfile(String uid, Map<String, dynamic> changes) async {
    await _db.collection(AppConstants.usersCol).doc(uid).update({
      ...changes,
      'updatedAt': Timestamp.fromDate(DateTime.now()),
    });
  }

  /// Deletes the account. The `deleteAccount` Cloud Function purges the user's
  /// documents and Storage files, then removes the Auth record.
  Future<void> deleteAccount() async {
    await _auth.currentUser?.delete();
  }

  String _mapAuthError(FirebaseAuthException e) {
    switch (e.code) {
      case 'invalid-email':
        return 'That email address looks invalid.';
      case 'user-disabled':
        return 'This account has been disabled.';
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential':
        return 'Incorrect email or password.';
      case 'email-already-in-use':
        return 'An account already exists for that email.';
      case 'weak-password':
        return 'Choose a stronger password.';
      case 'too-many-requests':
        return 'Too many attempts. Please wait and try again.';
      default:
        return e.message ?? 'Something went wrong. Please try again.';
    }
  }
}

final authRepositoryProvider = Provider<AuthRepository>((ref) {
  return AuthRepository(
    ref.watch(firebaseAuthProvider),
    ref.watch(firestoreProvider),
  );
});
