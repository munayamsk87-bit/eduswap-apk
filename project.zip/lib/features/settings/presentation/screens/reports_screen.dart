import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../core/constants/build_flags.dart';
import '../../../../core/constants/enums.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../shared/models/report.dart';
import '../../../../shared/providers/auth_providers.dart';
import '../../../../shared/providers/firebase_providers.dart';

final _myReportsProvider = StreamProvider<List<Report>>((ref) {
  if (kOfflineMode) return Stream.value(<Report>[]);
  final uid = ref.watch(currentUserProvider);
  if (uid == null) return Stream.empty();
  return ref
      .watch(firestoreProvider)
      .collection(AppConstants.reportsCol)
      .where('reporterId', isEqualTo: uid)
      .orderBy('createdAt', descending: true)
      .snapshots()
      .map((s) => s.docs.map((d) => Report.fromJson(d.data())).toList());
});

class ReportsScreen extends ConsumerWidget {
  const ReportsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final reports = ref.watch(_myReportsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Reports & safety')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.peach,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: const [
                    Icon(Icons.shield_outlined, color: AppColors.warning),
                    SizedBox(width: 8),
                    Text('Staying safe',
                        style: TextStyle(fontWeight: FontWeight.w700)),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  'EduSwap never handles money. For physical book swaps, meet '
                  'in a public place, involve a trusted adult if you are a '
                  'minor, and never share your home address or phone number.',
                  style: theme.textTheme.bodyMedium,
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Text('My reports',
              style: theme.textTheme.titleMedium
                  ?.copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          reports.when(
            loading: () => const Padding(
              padding: EdgeInsets.all(24),
              child: Center(child: CircularProgressIndicator()),
            ),
            error: (e, _) => const Padding(
              padding: EdgeInsets.all(24),
              child: Text('Could not load your reports.'),
            ),
            data: (list) => list.isEmpty
                ? const Padding(
                    padding: EdgeInsets.symmetric(vertical: 24),
                    child: Text('You have not submitted any reports.'),
                  )
                : Column(
                    children: [
                      for (final r in list)
                        Card(
                          child: ListTile(
                            leading: const Icon(Icons.flag_outlined),
                            title: Text(r.reason),
                            subtitle: Text(
                                '${r.targetType.name} • ${r.status.name}'),
                          ),
                        ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }
}
