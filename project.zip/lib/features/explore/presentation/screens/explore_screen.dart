import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/enums.dart';
import '../../../../core/errors/app_exception.dart';
import '../../../../core/router/app_router.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/error_state.dart';
import '../../../../core/widgets/loading_skeleton.dart';
import '../../../../shared/models/resource.dart';
import '../../../resources/data/resource_repository.dart';

/// Discovery: debounced search, filters, sorting and cursor pagination.
/// Queries are bounded — the whole catalog is never downloaded.
class ExploreScreen extends ConsumerStatefulWidget {
  const ExploreScreen({super.key});

  @override
  ConsumerState<ExploreScreen> createState() => _ExploreScreenState();
}

class _ExploreScreenState extends ConsumerState<ExploreScreen> {
  final _search = TextEditingController();
  final _scroll = ScrollController();
  Timer? _debounce;

  ResourceType? _type;
  EducationLevel? _level;
  AppLanguage? _language;
  ResourceSort _sort = ResourceSort.newest;

  final List<Resource> _results = [];
  DocumentSnapshot<Map<String, dynamic>>? _cursor;
  bool _loading = false;
  bool _hasMore = false;
  Object? _error;

  @override
  void initState() {
    super.initState();
    _scroll.addListener(_onScroll);
    _runSearch();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _search.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 300 &&
        !_loading &&
        _hasMore) {
      _runSearch(more: true);
    }
  }

  void _onQueryChanged(String _) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 400), () => _runSearch());
  }

  Future<void> _runSearch({bool more = false}) async {
    if (more && (!_hasMore || _loading)) return;
    setState(() {
      _loading = true;
      _error = null;
      if (!more) {
        _results.clear();
        _cursor = null;
      }
    });
    try {
      final page = await ref.read(resourceRepositoryProvider).search(
            ResourceQuery(
              text: _search.text,
              type: _type,
              educationLevel: _level,
              language: _language,
              sort: _sort,
            ),
            startAfter: more ? _cursor : null,
          );
      if (!mounted) return;
      setState(() {
        _results.addAll(page.items);
        _cursor = page.lastDoc;
        _hasMore = page.hasMore;
      });
    } catch (e) {
      if (mounted) setState(() => _error = AppException.from(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _clearFilters() {
    setState(() {
      _type = null;
      _level = null;
      _language = null;
      _sort = ResourceSort.newest;
    });
    _runSearch();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Explore')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: TextField(
              controller: _search,
              onChanged: _onQueryChanged,
              textInputAction: TextInputAction.search,
              onSubmitted: (_) => _runSearch(),
              decoration: InputDecoration(
                hintText: 'Search by title…',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _search.text.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () {
                          _search.clear();
                          _runSearch();
                        },
                      ),
              ),
            ),
          ),
          _filterBar(),
          const Divider(height: 1),
          Expanded(child: _resultsArea()),
        ],
      ),
    );
  }

  Widget _filterBar() {
    return SizedBox(
      height: 52,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        children: [
          _dropdownChip<ResourceType>(
            label: _type?.label ?? 'Type',
            value: _type,
            items: ResourceType.values,
            itemLabel: (t) => t.label,
            onChanged: (v) {
              setState(() => _type = v);
              _runSearch();
            },
          ),
          const SizedBox(width: 8),
          _dropdownChip<EducationLevel>(
            label: _level == null ? 'Class' : _levelLabel(_level!),
            value: _level,
            items: EducationLevel.values,
            itemLabel: _levelLabel,
            onChanged: (v) {
              setState(() => _level = v);
              _runSearch();
            },
          ),
          const SizedBox(width: 8),
          _dropdownChip<AppLanguage>(
            label: _language == null ? 'Language' : _languageLabel(_language!),
            value: _language,
            items: AppLanguage.values,
            itemLabel: _languageLabel,
            onChanged: (v) {
              setState(() => _language = v);
              _runSearch();
            },
          ),
          const SizedBox(width: 8),
          _dropdownChip<ResourceSort>(
            label: switch (_sort) {
              ResourceSort.newest => 'Newest',
              ResourceSort.relevance => 'Relevant',
              ResourceSort.mostSaved => 'Most saved',
            },
            value: _sort,
            items: ResourceSort.values,
            itemLabel: (s) => switch (s) {
              ResourceSort.newest => 'Newest',
              ResourceSort.relevance => 'Most relevant',
              ResourceSort.mostSaved => 'Most saved',
            },
            onChanged: (v) {
              setState(() => _sort = v ?? _sort);
              _runSearch();
            },
          ),
          if (_type != null || _level != null || _language != null)
            Padding(
              padding: const EdgeInsets.only(left: 8),
              child: ActionChip(
                avatar: const Icon(Icons.clear, size: 16),
                label: const Text('Clear'),
                onPressed: _clearFilters,
              ),
            ),
        ],
      ),
    );
  }

  Widget _dropdownChip<T>({
    required String label,
    required T? value,
    required List<T> items,
    required String Function(T) itemLabel,
    required ValueChanged<T?> onChanged,
  }) {
    return PopupMenuButton<T?>(
      onSelected: onChanged,
      itemBuilder: (_) => [
        const PopupMenuItem(value: null, child: Text('Any')),
        ...items.map((i) => PopupMenuItem(value: i, child: Text(itemLabel(i)))),
      ],
      child: Chip(
        label: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(label),
            const Icon(Icons.arrow_drop_down, size: 18),
          ],
        ),
      ),
    );
  }

  Widget _resultsArea() {
    if (_error != null && _results.isEmpty) {
      return ErrorState(error: _error!, onRetry: () => _runSearch());
    }
    if (_loading && _results.isEmpty) {
      return LoadingSkeleton.list(count: 5, height: 110);
    }
    if (_results.isEmpty) {
      return const EmptyState(
        icon: Icons.search_off_rounded,
        title: 'No resources found',
        message: 'Try a different subject, class or keyword.',
      );
    }
    return ListView.separated(
      controller: _scroll,
      padding: const EdgeInsets.all(16),
      itemCount: _results.length + (_hasMore ? 1 : 0),
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (_, i) {
        if (i >= _results.length) {
          return const Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: Center(child: CircularProgressIndicator()),
          );
        }
        final r = _results[i];
        return ResourceCard(
          resource: r,
          onTap: () => context.push(AppRoutes.resource(r.id)),
        );
      },
    );
  }

  String _levelLabel(EducationLevel e) => switch (e) {
        EducationLevel.primary => 'Primary',
        EducationLevel.secondary => 'Secondary',
        EducationLevel.higherSecondary => 'Higher secondary',
        EducationLevel.undergraduate => 'Undergraduate',
        EducationLevel.postgraduate => 'Postgraduate',
        EducationLevel.other => 'Other',
      };

  String _languageLabel(AppLanguage l) => switch (l) {
        AppLanguage.english => 'English',
        AppLanguage.bengali => 'Bengali',
        AppLanguage.hindi => 'Hindi',
      };
}
