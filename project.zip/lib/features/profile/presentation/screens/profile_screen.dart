import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/enums.dart';
import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../shared/providers/auth_providers.dart';
import '../../../../shared/providers/feed_providers.dart';
import '../../../../shared/widgets/resource_card.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final user = ref.watch(appUserProvider).valueOrNull;
    final resources = ref.watch(myResourcesProvider);
    final isAdmin = ref.watch(isAdminProvider).valueOrNull ?? false;

    if (user == null) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        actions: [
          IconButton(
            onPressed: () => context.push(AppRoutes.settings),
            icon: const Icon(Icons.settings_outlined),
          ),
        ],
      ),
      body: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 36,
                  backgroundColor: AppColors.mint,
                  backgroundImage:
                      user.photoUrl != null ? NetworkImage(user.photoUrl!) : null,
                  child: user.photoUrl == null
                      ? Text(user.displayName.isEmpty
                          ? '?'
                          : user.displayName[0].toUpperCase())
                      : null,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(user.displayName,
                          style: theme.textTheme.titleLarge
                              ?.copyWith(fontWeight: FontWeight.w700)),
                      const SizedBox(height: 4),
                      Text(_levelLabel(user.educationLevel),
                          style: theme.textTheme.bodyMedium?.copyWith(
                              color: theme.colorScheme.onSurfaceVariant)),
                      if (user.institution?.isNotEmpty == true)
                        Text(user.institution!,
                            style: theme.textTheme.bodySmall),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                _stat(theme, '${user.reputation}', 'Reputation'),
                _stat(theme, '${resources.valueOrNull?.length ?? 0}', 'Shared'),
                _stat(theme, '${user.badges.length}', 'Badges'),
              ],
            ),
          ),
          if (user.badges.isNotEmpty) ...[
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: user.badges
                    .map((b) => Chip(
                          avatar: const Icon(Icons.workspace_premium,
                              size: 18, color: AppColors.primary),
                          label: Text(b),
                        ))
                    .toList(),
              ),
            ),
          ],
          const Divider(height: 32),
          ListTile(
            leading: const Icon(Icons.bookmark_border),
            title: const Text('Wishlist & saved'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => context.push(AppRoutes.wishlist),
          ),
          ListTile(
            leading: const Icon(Icons.swap_horiz),
            title: const Text('Swap requests'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => context.push(AppRoutes.swapRequests),
          ),
          ListTile(
            leading: const Icon(Icons.school_outlined),
            title: const Text('Skill sharing'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => context.push(AppRoutes.skillSharing),
          ),
          ListTile(
            leading: const Icon(Icons.flag_outlined),
            title: const Text('Reports & safety'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => context.push(AppRoutes.reports),
          ),
          if (isAdmin)
            ListTile(
              leading: const Icon(Icons.admin_panel_settings_outlined),
              title: const Text('Admin & moderation'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => context.push(AppRoutes.admin),
            ),
          const Divider(height: 32),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text('My uploads',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
          ),
          const SizedBox(height: 8),
          resources.when(
            loading: () => const Padding(
              padding: EdgeInsets.all(24),
              child: Center(child: CircularProgressIndicator()),
            ),
            error: (e, _) => Padding(
              padding: const EdgeInsets.all(24),
              child: Text('Could not load uploads.'),
            ),
            data: (list) {
              if (list.isEmpty) {
                return const Padding(
                  padding: EdgeInsets.symmetric(vertical: 24),
                  child: EmptyState(
                    icon: Icons.upload_file_outlined,
                    title: 'No uploads yet',
                    message: 'Share your first resource from the Add tab.',
                  ),
                );
              }
              return Column(
                children: [
                  for (final r in list)
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ResourceCard(
                            resource: r,
                            onTap: () =>
                                context.push(AppRoutes.resource(r.id)),
                          ),
                          const SizedBox(height: 4),
                          _statusBadge(theme, r.status),
                        ],
                      ),
                    ),
                ],
              );
            },
          ),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _stat(ThemeData theme, String value, String label) {
    return Expanded(
      child: Column(
        children: [
          Text(value,
              style: theme.textTheme.headlineSmall
                  ?.copyWith(fontWeight: FontWeight.w700)),
          Text(label,
              style: theme.textTheme.bodySmall
                  ?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
        ],
      ),
    );
  }

  Widget _statusBadge(ThemeData theme, ResourceStatus status) {
    final (label, color) = switch (status) {
      ResourceStatus.approved => ('Approved', AppColors.success),
      ResourceStatus.pendingReview => ('Pending review', AppColors.warning),
      ResourceStatus.rejected => ('Rejected', AppColors.error),
      ResourceStatus.removed => ('Removed', AppColors.error),
      ResourceStatus.draft => ('Draft', theme.colorScheme.outline),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(label,
          style: theme.textTheme.labelSmall?.copyWith(color: color)),
    );
  }

  String _levelLabel(EducationLevel e) => switch (e) {
        EducationLevel.primary => 'Primary',
        EducationLevel.secondary => 'Secondary',
        EducationLevel.higherSecondary => 'Higher secondary',
        EducationLevel.undergraduate => 'Undergraduate',
        EducationLevel.postgraduate => 'Postgraduate',
        EducationLevel.other => 'Other',
      };
}
