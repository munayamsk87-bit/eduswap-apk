import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../shared/providers/auth_providers.dart';
import '../../../../shared/providers/feed_providers.dart';
import '../../../../shared/widgets/resource_card.dart';
import '../../../chat/data/chat_repository.dart';

/// A student's public profile. Saved resources and private settings are never
/// shown here — only shared contributions.
class UserProfileScreen extends ConsumerWidget {
  const UserProfileScreen({super.key, required this.userId});

  final String userId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final user = ref.watch(userByIdProvider(userId)).valueOrNull;
    final resources = ref.watch(userResourcesProvider(userId));
    final myUid = ref.watch(currentUserProvider);

    if (user == null) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text(user.displayName)),
      body: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                CircleAvatar(
                  radius: 40,
                  backgroundColor: AppColors.mint,
                  backgroundImage:
                      user.photoUrl != null ? NetworkImage(user.photoUrl!) : null,
                  child: user.photoUrl == null
                      ? Text(user.displayName[0].toUpperCase(),
                          style: theme.textTheme.headlineSmall)
                      : null,
                ),
                const SizedBox(height: 12),
                Text(user.displayName,
                    style: theme.textTheme.titleLarge
                        ?.copyWith(fontWeight: FontWeight.w700)),
                if (user.institution?.isNotEmpty == true)
                  Text(user.institution!, style: theme.textTheme.bodySmall),
                const SizedBox(height: 12),
                if (user.badges.isNotEmpty)
                  Wrap(
                    spacing: 8,
                    children: user.badges
                        .map((b) => Chip(label: Text(b)))
                        .toList(),
                  ),
                const SizedBox(height: 16),
                if (myUid != null && myUid != userId)
                  FilledButton.icon(
                    onPressed: () => _message(context, ref, user.uid,
                        user.displayName, myUid),
                    icon: const Icon(Icons.chat_bubble_outline),
                    label: const Text('Message'),
                  ),
              ],
            ),
          ),
          const Divider(height: 1),
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Text('Shared resources',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
          ),
          resources.when(
            loading: () => const Padding(
              padding: EdgeInsets.all(24),
              child: Center(child: CircularProgressIndicator()),
            ),
            error: (e, _) => const Padding(
              padding: EdgeInsets.all(24),
              child: Text('Could not load resources.'),
            ),
            data: (list) => list.isEmpty
                ? const Padding(
                    padding: EdgeInsets.all(24),
                    child: Text('No public resources yet.'),
                  )
                : Column(
                    children: [
                      for (final r in list)
                        Padding(
                          padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                          child: ResourceCard(
                            resource: r,
                            onTap: () =>
                                context.push(AppRoutes.resource(r.id)),
                          ),
                        ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  Future<void> _message(
    BuildContext context,
    WidgetRef ref,
    String otherId,
    String otherName,
    String myUid,
  ) async {
    final me = ref.read(appUserProvider).valueOrNull;
    if (me == null) return;
    final id = await ref.read(chatRepositoryProvider).getOrCreateConversation(
          currentUid: myUid,
          otherUid: otherId,
          names: {myUid: me.displayName, otherId: otherName},
        );
    if (context.mounted) {
      context.push(
        '${AppRoutes.conversation(id)}?peer=${Uri.encodeComponent(otherName)}',
      );
    }
  }
}
