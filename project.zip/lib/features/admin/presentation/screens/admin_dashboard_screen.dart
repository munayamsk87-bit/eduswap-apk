import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/enums.dart';
import '../../../../core/errors/app_exception.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../shared/models/report.dart';
import '../../../../shared/models/resource.dart';
import '../../../../shared/providers/auth_providers.dart';
import '../../data/admin_repository.dart';

final _adminStatsProvider = FutureProvider<AdminStats>((ref) {
  return ref.watch(adminRepositoryProvider).dashboard();
});

final _pendingResourcesProvider = StreamProvider<List<Resource>>((ref) {
  return ref.watch(adminRepositoryProvider).watchPendingResources();
});

final _openReportsProvider = StreamProvider<List<Report>>((ref) {
  return ref
      .watch(adminRepositoryProvider)
      .watchReports(status: ReportStatus.open);
});

/// Protected moderation console. Access is gated by an admin custom claim and
/// re-verified inside every backend call — this screen is only the surface.
class AdminDashboardScreen extends ConsumerWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isAdmin = ref.watch(isAdminProvider);
    final theme = Theme.of(context);

    return isAdmin.when(
      loading: () => const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      ),
      error: (e, _) => Scaffold(
        appBar: AppBar(title: const Text('Admin')),
        body: Center(child: Text(AppException.from(e).message)),
      ),
      data: (admin) {
        if (!admin) {
          return Scaffold(
            appBar: AppBar(title: const Text('Admin')),
            body: const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text(
                  'You do not have moderator access. Roles are granted only '
                  'through trusted administrative procedures.',
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          );
        }
        return DefaultTabController(
          length: 2,
          child: Scaffold(
            appBar: AppBar(
              title: const Text('Admin & moderation'),
              bottom: const TabBar(
                tabs: [Tab(text: 'Review queue'), Tab(text: 'Reports')],
              ),
            ),
            body: TabBarView(
              children: [
                _ReviewQueue(theme: theme),
                _ReportsQueue(theme: theme),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _ReviewQueue extends ConsumerWidget {
  const _ReviewQueue({required this.theme});

  final ThemeData theme;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final stats = ref.watch(_adminStatsProvider);
    final pending = ref.watch(_pendingResourcesProvider);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        stats.when(
          loading: () => const SizedBox.shrink(),
          error: (e, _) => const SizedBox.shrink(),
          data: (s) => Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              _statCard(theme, 'Users', s.totalUsers, AppColors.sky),
              _statCard(theme, 'Pending', s.pendingResources, AppColors.lemon),
              _statCard(theme, 'Approved', s.approvedResources, AppColors.mint),
              _statCard(theme, 'Open reports', s.openReports, AppColors.peach),
            ],
          ),
        ),
        const SizedBox(height: 20),
        Text('Pending resources',
            style: theme.textTheme.titleMedium
                ?.copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        pending.when(
          loading: () => const Padding(
            padding: EdgeInsets.all(24),
            child: Center(child: CircularProgressIndicator()),
          ),
          error: (e, _) => Text(AppException.from(e).message),
          data: (list) => list.isEmpty
              ? const Padding(
                  padding: EdgeInsets.symmetric(vertical: 24),
                  child: Text('Review queue is clear.'),
                )
              : Column(
                  children: [
                    for (final r in list) _pendingCard(context, ref, r, theme),
                  ],
                ),
        ),
      ],
    );
  }

  Widget _pendingCard(
      BuildContext context, WidgetRef ref, Resource r, ThemeData theme) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(r.title,
                style: theme.textTheme.titleSmall
                    ?.copyWith(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text('${r.type.label} • ${r.ownerName}',
                style: theme.textTheme.bodySmall),
            if (r.description.isNotEmpty) ...[
              const SizedBox(height: 6),
              Text(r.description, maxLines: 2,
                  overflow: TextOverflow.ellipsis),
            ],
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: FilledButton(
                    onPressed: () => _moderate(context, ref, r, true),
                    child: const Text('Approve'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => _moderate(context, ref, r, false),
                    child: const Text('Reject'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _moderate(
      BuildContext context, WidgetRef ref, Resource r, bool approve) async {
    try {
      await ref
          .read(adminRepositoryProvider)
          .moderateResource(resourceId: r.id, approve: approve);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(approve ? 'Approved.' : 'Rejected.')),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(AppException.from(e).message)));
      }
    }
  }

  Widget _statCard(ThemeData theme, String label, int value, Color color) {
    return Container(
      width: 150,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('$value',
              style: theme.textTheme.headlineSmall
                  ?.copyWith(fontWeight: FontWeight.w700)),
          Text(label, style: theme.textTheme.bodySmall),
        ],
      ),
    );
  }
}

class _ReportsQueue extends ConsumerWidget {
  const _ReportsQueue({required this.theme});

  final ThemeData theme;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final reports = ref.watch(_openReportsProvider);
    return reports.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Center(child: Text(AppException.from(e).message)),
      data: (list) => list.isEmpty
          ? const Center(child: Text('No open reports.'))
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: list.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (_, i) {
                final r = list[i];
                return Card(
                  child: ListTile(
                    title: Text(r.reason),
                    subtitle: Text('${r.targetType.name} • ${r.targetId}'),
                    trailing: TextButton(
                      onPressed: () => _resolve(context, ref, r),
                      child: const Text('Resolve'),
                    ),
                  ),
                );
              },
            ),
    );
  }

  Future<void> _resolve(
      BuildContext context, WidgetRef ref, Report r) async {
    try {
      await ref.read(adminRepositoryProvider).resolveReport(
            reportId: r.id,
            resolution: 'resolved',
          );
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Report resolved.')));
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(AppException.from(e).message)));
      }
    }
  }
}
