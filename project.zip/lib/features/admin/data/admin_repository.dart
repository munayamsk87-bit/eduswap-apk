import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/app_constants.dart';
import '../../../core/constants/enums.dart';
import '../../../shared/models/report.dart';
import '../../../shared/models/resource.dart';
import '../../../shared/providers/firebase_providers.dart';

/// Aggregated admin metrics. Computed on the server so the client never
/// downloads whole collections to count them.
class AdminStats {
  const AdminStats({
    required this.totalUsers,
    required this.pendingResources,
    required this.approvedResources,
    required this.reportedResources,
    required this.openReports,
  });

  final int totalUsers;
  final int pendingResources;
  final int approvedResources;
  final int reportedResources;
  final int openReports;

  factory AdminStats.fromMap(Map<String, dynamic> m) => AdminStats(
        totalUsers: (m['totalUsers'] ?? 0) as int,
        pendingResources: (m['pendingResources'] ?? 0) as int,
        approvedResources: (m['approvedResources'] ?? 0) as int,
        reportedResources: (m['reportedResources'] ?? 0) as int,
        openReports: (m['openReports'] ?? 0) as int,
      );
}

/// Admin/moderation actions. Every callable re-verifies the admin custom
/// claim on the server; a hidden button is never treated as security.
class AdminRepository {
  AdminRepository(this._db, this._functions);

  final FirebaseFirestore _db;
  final FirebaseFunctions _functions;

  Future<AdminStats> dashboard() async {
    final res = await _functions.httpsCallable('getAdminDashboard').call();
    return AdminStats.fromMap((res.data as Map).cast<String, dynamic>());
  }

  Stream<List<Resource>> watchPendingResources() {
    return _db
        .collection(AppConstants.resourcesCol)
        .where('status', isEqualTo: ResourceStatus.pendingReview.name)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((s) => s.docs.map((d) => Resource.fromJson(d.data())).toList());
  }

  Stream<List<Report>> watchReports({ReportStatus? status}) {
    Query<Map<String, dynamic>> q =
        _db.collection(AppConstants.reportsCol);
    if (status != null) q = q.where('status', isEqualTo: status.name);
    return q
        .orderBy('createdAt', descending: true)
        .limit(100)
        .snapshots()
        .map((s) => s.docs.map((d) => Report.fromJson(d.data())).toList());
  }

  Future<void> moderateResource({
    required String resourceId,
    required bool approve,
    String note = '',
  }) async {
    await _functions.httpsCallable('moderateResource').call({
      'resourceId': resourceId,
      'approve': approve,
      'note': note,
    });
  }

  Future<void> resolveReport({
    required String reportId,
    required String resolution,
    String note = '',
  }) async {
    await _functions.httpsCallable('resolveReport').call({
      'reportId': reportId,
      'resolution': resolution,
      'note': note,
    });
  }

  Future<void> setUserSuspended({
    required String userId,
    required bool suspended,
  }) async {
    await _functions.httpsCallable('setUserSuspended').call({
      'userId': userId,
      'suspended': suspended,
    });
  }
}

final adminRepositoryProvider = Provider<AdminRepository>((ref) {
  return AdminRepository(
    ref.watch(firestoreProvider),
    ref.watch(functionsProvider),
  );
});
