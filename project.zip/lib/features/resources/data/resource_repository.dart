import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/app_constants.dart';
import '../../../core/constants/enums.dart';
import '../../../core/errors/app_exception.dart';
import '../../../shared/models/resource.dart';
import '../../../shared/models/saved_resource.dart';
import '../../../shared/providers/firebase_providers.dart';

/// One page of search results plus the cursor to fetch the next.
class ResourcePage {
  const ResourcePage({required this.items, this.lastDoc});

  final List<Resource> items;
  final DocumentSnapshot<Map<String, dynamic>>? lastDoc;

  bool get hasMore => lastDoc != null;
}

/// Filters shared by Explore and Home.
class ResourceQuery {
  const ResourceQuery({
    this.text,
    this.type,
    this.subject,
    this.educationLevel,
    this.board,
    this.language,
    this.ownerId,
    this.sort = ResourceSort.newest,
  });

  final String? text;
  final ResourceType? type;
  final String? subject;
  final EducationLevel? educationLevel;
  final String? board;
  final AppLanguage? language;
  final String? ownerId;
  final ResourceSort sort;
}

enum ResourceSort { newest, relevance, mostSaved }

/// All reads/writes for educational resources.
class ResourceRepository {
  ResourceRepository(this._db, this._storage, this._functions);

  final FirebaseFirestore _db;
  final FirebaseStorage _storage;
  final FirebaseFunctions _functions;

  CollectionReference<Map<String, dynamic>> get _col =>
      _db.collection(AppConstants.resourcesCol);

  // ---------------------------------------------------------------- reads

  Stream<List<Resource>> watchRecent({int limit = AppConstants.pageSize}) {
    return _col
        .where('status', isEqualTo: ResourceStatus.approved.name)
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .snapshots()
        .map((s) => s.docs.map((d) => Resource.fromJson(d.data())).toList());
  }

  Stream<List<Resource>> watchByOwner(String ownerId) {
    return _col
        .where('ownerId', isEqualTo: ownerId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((s) => s.docs.map((d) => Resource.fromJson(d.data())).toList());
  }

  Future<Resource?> getById(String id) async {
    final doc = await _col.doc(id).get();
    return doc.exists ? Resource.fromJson(doc.data()!) : null;
  }

  /// Debounced, paginated search. Never downloads the whole collection.
  Future<ResourcePage> search(
    ResourceQuery query, {
    DocumentSnapshot<Map<String, dynamic>>? startAfter,
    int limit = AppConstants.pageSize,
  }) async {
    Query<Map<String, dynamic>> q =
        _col.where('status', isEqualTo: ResourceStatus.approved.name);

    if (query.type != null) q = q.where('type', isEqualTo: query.type!.name);
    if (query.subject != null && query.subject!.isNotEmpty) {
      q = q.where('subject', isEqualTo: query.subject);
    }
    if (query.educationLevel != null) {
      q = q.where('educationLevel', isEqualTo: query.educationLevel!.name);
    }
    if (query.board != null && query.board!.isNotEmpty) {
      q = q.where('board', isEqualTo: query.board);
    }
    if (query.language != null) {
      q = q.where('language', isEqualTo: query.language!.name);
    }
    if (query.ownerId != null) q = q.where('ownerId', isEqualTo: query.ownerId);

    // Title prefix search on a lowercased field (Firestore has no full-text).
    if (query.text != null && query.text!.trim().isNotEmpty) {
      final term = query.text!.trim().toLowerCase();
      q = q
          .where('titleLower', isGreaterThanOrEqualTo: term)
          .where('titleLower', isLessThan: '$term\uf8ff');
    }

    switch (query.sort) {
      case ResourceSort.newest:
        q = q.orderBy('createdAt', descending: true);
      case ResourceSort.mostSaved:
        q = q.orderBy('saveCount', descending: true);
      case ResourceSort.relevance:
        q = q.orderBy('saveCount', descending: true);
    }

    q = q.limit(limit);
    if (startAfter != null) q = q.startAfterDocument(startAfter);

    final snap = await q.get();
    return ResourcePage(
      items: snap.docs.map((d) => Resource.fromJson(d.data())).toList(),
      lastDoc: snap.docs.length == limit ? snap.docs.last : null,
    );
  }

  // --------------------------------------------------------------- writes

  /// Uploads a file (if any) then creates the Firestore document. Returns the
  /// new resource id. Progress is reported through [onProgress] (0..1).
  Future<String> uploadAndCreate({
    required Resource draft,
    File? file,
    File? cover,
    void Function(double progress)? onProgress,
  }) async {
    final docRef = _col.doc();
    final id = docRef.id;

    String? filePath;
    String? fileUrl;
    String? coverUrl;

    try {
      if (file != null) {
        filePath =
            '${AppConstants.resourceFilesPrefix}/${draft.ownerId}/$id/${_safeName(file.path)}';
        final ref = _storage.ref(filePath);
        final task = ref.putFile(file);
        task.snapshotEvents.listen((s) {
          if (s.totalBytes > 0) {
            onProgress?.call(s.bytesTransferred / s.totalBytes);
          }
        });
        await task;
        // Store the path only. Restricted files are never given a permanent
        // public link — the client fetches a signed URL via `getResourceAccess`,
        // which checks authorization on the server.
        fileUrl = null;
      }
      if (cover != null) {
        final ref = _storage.ref(
            '${AppConstants.coversPrefix}/${draft.ownerId}/$id/${_safeName(cover.path)}');
        await ref.putFile(cover);
        coverUrl = await ref.getDownloadURL();
      }

      final resource = draft.copyWith(
        id: id,
        filePath: filePath,
        fileUrl: fileUrl,
        coverUrl: coverUrl,
        status: ResourceStatus.pendingReview,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      await docRef.set({
        ...resource.toJson(),
        'titleLower': resource.title.toLowerCase(),
      });
      return id;
    } catch (e) {
      // Roll back any orphaned upload before surfacing the error.
      if (filePath != null) {
        try {
          await _storage.ref(filePath).delete();
        } catch (_) {}
      }
      throw AppException.from(e);
    }
  }

  Future<void> updateResource(String id, Map<String, dynamic> changes) async {
    await _col.doc(id).update({
      ...changes,
      'updatedAt': Timestamp.fromDate(DateTime.now()),
    });
  }

  Future<void> deleteResource(Resource resource) async {
    try {
      if (resource.filePath != null) {
        await _storage.ref(resource.filePath).delete();
      }
      await _col.doc(resource.id).delete();
    } catch (e) {
      throw AppException.from(e);
    }
  }

  Future<void> setAvailable(String id, bool available) =>
      updateResource(id, {'available': available});

  // ------------------------------------------------------ saves / wishlist

  Stream<bool> watchIsSaved(String userId, String resourceId) {
    return _db
        .collection(AppConstants.savedResourcesCol)
        .doc('${userId}_$resourceId')
        .snapshots()
        .map((d) => d.exists);
  }

  Stream<List<SavedResource>> watchSaved(String userId) {
    return _db
        .collection(AppConstants.savedResourcesCol)
        .where('userId', isEqualTo: userId)
        .orderBy('savedAt', descending: true)
        .snapshots()
        .map((s) =>
            s.docs.map((d) => SavedResource.fromJson(d.data())).toList());
  }

  /// Toggling a save goes through a Cloud Function so the `saveCount` counter
  /// stays consistent and duplicate saves are impossible.
  Future<bool> toggleSave({
    required String userId,
    required Resource resource,
  }) async {
    final callable = _functions.httpsCallable('toggleSaveResource');
    final res = await callable.call({
      'userId': userId,
      'resourceId': resource.id,
      'resourceTitle': resource.title,
      'coverUrl': resource.coverUrl,
    });
    return (res.data as Map)['saved'] as bool? ?? false;
  }

  /// Fetches a fresh download URL through an authorization check — restricted
  /// files are never served by a permanently public link.
  Future<String> requestDownloadUrl(String resourceId) async {
    final callable = _functions.httpsCallable('getResourceAccess');
    final res = await callable.call({'resourceId': resourceId});
    return (res.data as Map)['url'] as String;
  }

  Future<void> report({
    required String reporterId,
    required Resource resource,
    required String reason,
    String details = '',
  }) async {
    await _db.collection(AppConstants.reportsCol).add({
      'reporterId': reporterId,
      'targetType': ReportTargetType.resource.name,
      'targetId': resource.id,
      'reason': reason,
      'details': details,
      'status': ReportStatus.open.name,
      'createdAt': Timestamp.fromDate(DateTime.now()),
    });
  }

  String _safeName(String path) {
    final name = path.split(RegExp(r'[/\\]')).last;
    return name.replaceAll(RegExp(r'[^\w.\-]'), '_');
  }
}

final resourceRepositoryProvider = Provider<ResourceRepository>((ref) {
  return ResourceRepository(
    ref.watch(firestoreProvider),
    ref.watch(storageProvider),
    ref.watch(functionsProvider),
  );
});
