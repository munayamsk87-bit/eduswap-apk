import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

import '../../../../core/constants/enums.dart';
import '../../../../core/errors/app_exception.dart';
import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../shared/models/resource.dart';
import '../../../../shared/providers/auth_providers.dart';
import '../../../../shared/providers/feed_providers.dart';
import '../../data/resource_repository.dart';
import '../../../swap/data/swap_repository.dart';

class ResourceDetailScreen extends ConsumerWidget {
  const ResourceDetailScreen({super.key, required this.resourceId});

  final String resourceId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final asyncResource = ref.watch(resourceByIdProvider(resourceId));
    final uid = ref.watch(currentUserProvider);

    return Scaffold(
      appBar: AppBar(
        actions: [
          if (uid != null)
            IconButton(
              tooltip: 'Report',
              icon: const Icon(Icons.flag_outlined),
              onPressed: () => _report(context, ref, asyncResource.valueOrNull),
            ),
        ],
      ),
      body: asyncResource.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text(AppException.from(e).message)),
        data: (r) {
          if (r == null) {
            return const Center(child: Text('This resource is unavailable.'));
          }
          return ListView(
            children: [
              if (r.coverUrl != null)
                AspectRatio(
                  aspectRatio: 16 / 10,
                  child: CachedNetworkImage(
                    imageUrl: r.coverUrl!,
                    fit: BoxFit.cover,
                    placeholder: (_, __) =>
                        Container(color: AppColors.mint),
                    errorWidget: (_, __, ___) =>
                        Container(color: AppColors.mint),
                  ),
                ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(r.title,
                        style: theme.textTheme.headlineSmall
                            ?.copyWith(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _chip(theme, r.type.label, AppColors.mint),
                        if (r.subject.isNotEmpty)
                          _chip(theme, r.subject, AppColors.sky),
                        _chip(theme, _levelLabel(r.educationLevel),
                            AppColors.lilac),
                        if (r.board?.isNotEmpty == true)
                          _chip(theme, r.board!, AppColors.lemon),
                      ],
                    ),
                    const SizedBox(height: 16),
                    if (r.description.isNotEmpty) ...[
                      Text(r.description,
                          style: theme.textTheme.bodyLarge),
                      const SizedBox(height: 16),
                    ],
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: CircleAvatar(
                        backgroundColor: AppColors.mint,
                        child: Text(r.ownerName.isEmpty
                            ? '?'
                            : r.ownerName[0].toUpperCase()),
                      ),
                      title: Text(r.ownerName),
                      subtitle: Text(_formatDate(r.createdAt)),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => context.push(AppRoutes.user(r.ownerId)),
                    ),
                    const Divider(),
                    Row(
                      children: [
                        const Icon(Icons.bookmark_border, size: 18),
                        const SizedBox(width: 6),
                        Text('${r.saveCount} saves'),
                        const SizedBox(width: 20),
                        const Icon(Icons.download_outlined, size: 18),
                        const SizedBox(width: 6),
                        Text('${r.downloadCount} downloads'),
                      ],
                    ),
                    const SizedBox(height: 20),
                    // Actions
                    if (r.filePath != null)
                      FilledButton.icon(
                        onPressed: () => _openViewer(context, ref, r),
                        icon: const Icon(Icons.menu_book_outlined),
                        label: Text(
                          r.mimeType == 'application/pdf'
                              ? 'Read in app'
                              : 'Preview file',
                        ),
                      ),
                    if (r.type.isPhysical && uid != null && uid != r.ownerId) ...[
                      const SizedBox(height: 10),
                      OutlinedButton.icon(
                        onPressed: () => _requestSwap(context, ref, r, uid),
                        icon: const Icon(Icons.swap_horiz),
                        label: const Text('Request swap'),
                      ),
                    ],
                    if (uid == r.ownerId) ...[
                      const SizedBox(height: 10),
                      OutlinedButton.icon(
                        onPressed: () async {
                          await ref
                              .read(resourceRepositoryProvider)
                              .setAvailable(r.id, !r.available);
                        },
                        icon: Icon(r.available
                            ? Icons.visibility_off_outlined
                            : Icons.visibility_outlined),
                        label: Text(r.available
                            ? 'Mark unavailable'
                            : 'Mark available'),
                      ),
                    ],
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () => _toggleSave(context, ref, r, uid),
                            icon: const Icon(Icons.bookmark_add_outlined),
                            label: const Text('Save'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                    content: Text('Share link copied.')),
                              );
                            },
                            icon: const Icon(Icons.share_outlined),
                            label: const Text('Share'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _chip(ThemeData theme, String label, Color color) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration:
            BoxDecoration(color: color, borderRadius: BorderRadius.circular(10)),
        child: Text(label,
            style: theme.textTheme.labelMedium?.copyWith(color: Colors.black87)),
      );

  Future<void> _openViewer(
      BuildContext context, WidgetRef ref, Resource r) async {
    try {
      final url =
          await ref.read(resourceRepositoryProvider).requestDownloadUrl(r.id);
      if (!context.mounted) return;
      Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => _PdfViewerScreen(title: r.title, url: url),
      ));
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(AppException.from(e).message)));
      }
    }
  }

  Future<void> _toggleSave(
      BuildContext context, WidgetRef ref, Resource r, String? uid) async {
    if (uid == null) return;
    try {
      final saved = await ref
          .read(resourceRepositoryProvider)
          .toggleSave(userId: uid, resource: r);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(saved ? 'Saved to wishlist.' : 'Removed.')),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(AppException.from(e).message)));
      }
    }
  }

  Future<void> _requestSwap(
      BuildContext context, WidgetRef ref, Resource r, String uid) async {
    final user = ref.read(appUserProvider).valueOrNull;
    if (user == null) return;
    final controller = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Request swap'),
        content: TextField(
          controller: controller,
          maxLines: 3,
          decoration: const InputDecoration(
            hintText: 'Add a friendly note (optional)',
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Send request')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await ref.read(swapRepositoryProvider).createRequest(
            resource: r,
            requesterId: uid,
            requesterName: user.displayName,
            message: controller.text.trim(),
          );
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Swap request sent.')),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(AppException.from(e).message)));
      }
    }
  }

  Future<void> _report(
      BuildContext context, WidgetRef ref, Resource? r) async {
    final uid = ref.read(currentUserProvider);
    if (r == null || uid == null) return;
    try {
      await ref.read(resourceRepositoryProvider).report(
            reporterId: uid,
            resource: r,
            reason: 'Reported from detail screen',
          );
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Report submitted. Thank you.')),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(AppException.from(e).message)));
      }
    }
  }

  String _formatDate(DateTime? d) {
    if (d == null) return '';
    return '${d.day}/${d.month}/${d.year}';
  }

  String _levelLabel(EducationLevel e) => switch (e) {
        EducationLevel.primary => 'Primary',
        EducationLevel.secondary => 'Secondary',
        EducationLevel.higherSecondary => 'Higher secondary',
        EducationLevel.undergraduate => 'Undergraduate',
        EducationLevel.postgraduate => 'Postgraduate',
        EducationLevel.other => 'Other',
      };
}

/// In-app PDF reader with zoom, page navigation and search.
class _PdfViewerScreen extends StatefulWidget {
  const _PdfViewerScreen({required this.title, required this.url});

  final String title;
  final String url;

  @override
  State<_PdfViewerScreen> createState() => _PdfViewerScreenState();
}

class _PdfViewerScreenState extends State<_PdfViewerScreen> {
  final _controller = PdfViewerController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis),
      ),
      // The built-in SfPdfViewer toolbar already provides page navigation,
      // zoom, bookmarks and search within the document.
      body: SfPdfViewer.network(
        widget.url,
        controller: _controller,
        onDocumentLoadFailed: (details) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Could not open: ${details.description}')),
          );
        },
      ),
    );
  }
}
