import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../core/constants/enums.dart';
import '../../../../core/errors/app_exception.dart';
import '../../../../core/router/app_router.dart';
import '../../../../core/utils/validators.dart';
import '../../../../shared/models/resource.dart';
import '../../../../shared/providers/auth_providers.dart';
import '../../../resources/data/resource_repository.dart';

/// Upload flow: choose type → enter details → attach → validate → submit.
/// Files go to Firebase Storage, metadata to Firestore, and the listing starts
/// in `pendingReview`.
class AddResourceScreen extends ConsumerStatefulWidget {
  const AddResourceScreen({super.key});

  @override
  ConsumerState<AddResourceScreen> createState() => _AddResourceScreenState();
}

class _AddResourceScreenState extends ConsumerState<AddResourceScreen> {
  final _formKey = GlobalKey<FormState>();
  final _title = TextEditingController();
  final _description = TextEditingController();
  final _subject = TextEditingController();
  final _board = TextEditingController();
  final _tags = TextEditingController();
  final _condition = TextEditingController();
  final _locality = TextEditingController();

  ResourceType _type = ResourceType.pdfNotes;
  EducationLevel _level = EducationLevel.secondary;
  AppLanguage _language = AppLanguage.english;

  File? _file;
  File? _cover;
  double _progress = 0;
  bool _uploading = false;

  static const _allowedExtensions = [
    'pdf', 'doc', 'docx', 'ppt', 'pptx', 'png', 'jpg', 'jpeg',
  ];

  @override
  void dispose() {
    _title.dispose();
    _description.dispose();
    _subject.dispose();
    _board.dispose();
    _tags.dispose();
    _condition.dispose();
    _locality.dispose();
    super.dispose();
  }

  Future<void> _pickFile() async {
    final res = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: _allowedExtensions,
      withData: false,
    );
    if (res == null || res.files.single.path == null) return;
    final picked = res.files.single;

    // Validate size before accepting the file.
    if ((picked.size) > AppConstants.maxResourceFileBytes) {
      _snack('File is too large. Maximum is 25 MB.');
      return;
    }
    setState(() => _file = File(picked.path!));
  }

  Future<void> _pickCover() async {
    final picker = ImagePicker();
    final x = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (x == null) return;
    final f = File(x.path);
    if (await f.length() > AppConstants.maxImageBytes) {
      _snack('Cover image must be under 5 MB.');
      return;
    }
    setState(() => _cover = f);
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    final user = ref.read(appUserProvider).valueOrNull;
    final uid = ref.read(currentUserProvider);
    if (user == null || uid == null) return;

    // Duplicate-submission protection: lock the button while in flight.
    if (_uploading) return;
    setState(() {
      _uploading = true;
      _progress = 0;
    });

    final draft = Resource(
      id: '',
      ownerId: uid,
      ownerName: user.displayName,
      ownerPhotoUrl: user.photoUrl,
      title: _title.text.trim(),
      description: _description.text.trim(),
      type: _type,
      subject: _subject.text.trim(),
      educationLevel: _level,
      board: _board.text.trim().isEmpty ? null : _board.text.trim(),
      language: _language,
      tags: _tags.text
          .split(',')
          .map((t) => t.trim())
          .where((t) => t.isNotEmpty)
          .toList(),
      bookAuthor: null,
      condition: _type.isPhysical ? _condition.text.trim() : null,
      exchangeLocality: _type.isPhysical ? _locality.text.trim() : null,
      available: true,
    );

    try {
      await ref.read(resourceRepositoryProvider).uploadAndCreate(
            draft: draft,
            file: _file,
            cover: _cover,
            onProgress: (p) => setState(() => _progress = p),
          );
      if (!mounted) return;
      await _showSubmitted();
    } on AppException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack(AppException.from(e).message);
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  Future<void> _showSubmitted() async {
    await showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        icon: const Icon(Icons.check_circle_outline, size: 40),
        title: const Text('Submitted for review'),
        content: const Text(
          'Thanks for sharing! Your resource is pending moderation and will '
          'appear once approved.',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              context.go(AppRoutes.home);
            },
            child: const Text('Done'),
          ),
        ],
      ),
    );
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Add a resource')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text('What are you sharing?',
                style: theme.textTheme.titleMedium
                    ?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            DropdownButtonFormField<ResourceType>(
              value: _type,
              decoration: const InputDecoration(labelText: 'Resource type'),
              items: ResourceType.values
                  .map((t) => DropdownMenuItem(value: t, child: Text(t.label)))
                  .toList(),
              onChanged: (v) => setState(() => _type = v ?? _type),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _title,
              decoration: const InputDecoration(labelText: 'Title *'),
              validator: (v) => Validators.required(v, field: 'Title'),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _description,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'Description'),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _subject,
              decoration: const InputDecoration(labelText: 'Subject'),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<EducationLevel>(
              value: _level,
              decoration: const InputDecoration(labelText: 'Class / level'),
              items: EducationLevel.values
                  .map((e) => DropdownMenuItem(value: e, child: Text(e.name)))
                  .toList(),
              onChanged: (v) => setState(() => _level = v ?? _level),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _board,
              decoration:
                  const InputDecoration(labelText: 'Board / curriculum'),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<AppLanguage>(
              value: _language,
              decoration: const InputDecoration(labelText: 'Language'),
              items: AppLanguage.values
                  .map((e) => DropdownMenuItem(value: e, child: Text(e.name)))
                  .toList(),
              onChanged: (v) => setState(() => _language = v ?? _language),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _tags,
              decoration: const InputDecoration(
                labelText: 'Tags',
                helperText: 'Comma separated, e.g. algebra, class10',
              ),
            ),
            if (_type.isPhysical) ...[
              const SizedBox(height: 16),
              TextFormField(
                controller: _condition,
                decoration: const InputDecoration(
                    labelText: 'Book condition (e.g. Good, Like new)'),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _locality,
                decoration: const InputDecoration(
                  labelText: 'General exchange locality',
                  helperText: 'Area or city only — never a full address.',
                ),
              ),
            ],
            const SizedBox(height: 24),
            Text('Attachments',
                style: theme.textTheme.titleSmall
                    ?.copyWith(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            _attachmentRow(
              label: _file == null
                  ? 'Attach file (PDF, doc, image)'
                  : _file!.path.split(Platform.pathSeparator).last,
              icon: Icons.attach_file,
              onTap: _pickFile,
            ),
            const SizedBox(height: 8),
            _attachmentRow(
              label: _cover == null ? 'Add cover image' : 'Cover selected',
              icon: Icons.image_outlined,
              onTap: _pickCover,
            ),
            const SizedBox(height: 8),
            Text(
              'Only upload material you have permission to share. '
              'Maximum file size: 25 MB.',
              style: theme.textTheme.bodySmall
                  ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
            ),
            const SizedBox(height: 24),
            if (_uploading) ...[
              LinearProgressIndicator(value: _progress == 0 ? null : _progress),
              const SizedBox(height: 8),
              Text('Uploading… ${(_progress * 100).toStringAsFixed(0)}%',
                  style: theme.textTheme.bodySmall),
              const SizedBox(height: 16),
            ],
            FilledButton.icon(
              onPressed: _uploading ? null : _submit,
              icon: const Icon(Icons.cloud_upload_outlined),
              label: const Text('Submit for review'),
            ),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  Widget _attachmentRow({
    required String label,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return OutlinedButton.icon(
      onPressed: onTap,
      icon: Icon(icon),
      label: Align(
        alignment: Alignment.centerLeft,
        child: Text(label, overflow: TextOverflow.ellipsis),
      ),
    );
  }
}
