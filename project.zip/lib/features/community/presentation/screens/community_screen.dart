import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/enums.dart';
import '../../../../core/errors/app_exception.dart';
import '../../../../core/router/app_router.dart';
import '../../../../core/widgets/async_value_view.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/loading_skeleton.dart';
import '../../../../shared/models/question.dart';
import '../../../../shared/providers/auth_providers.dart';
import '../../../../shared/providers/feed_providers.dart';
import '../../../../shared/widgets/question_tile.dart';
import '../../data/community_repository.dart';

class CommunityScreen extends ConsumerWidget {
  const CommunityScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final questions = ref.watch(popularQuestionsProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Community Q&A')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _askSheet(context, ref),
        icon: const Icon(Icons.add),
        label: const Text('Ask'),
      ),
      body: AsyncValueView<List<Question>>(
        value: questions,
        onRetry: () => ref.invalidate(popularQuestionsProvider),
        loading: LoadingSkeleton.list(count: 5, height: 96),
        isEmpty: (l) => l.isEmpty,
        emptyTitle: 'No questions yet',
        emptyMessage: 'Be the first to ask — peers and mentors can help.',
        data: (list) => ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: list.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (_, i) => QuestionTile(
            question: list[i],
            onTap: () => context.push(AppRoutes.question(list[i].id)),
          ),
        ),
      ),
    );
  }

  Future<void> _askSheet(BuildContext context, WidgetRef ref) async {
    final title = TextEditingController();
    final body = TextEditingController();
    final subject = TextEditingController();
    var level = EducationLevel.secondary;

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          left: 20,
          right: 20,
          top: 20,
          bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
        ),
        child: StatefulBuilder(
          builder: (ctx, setState) => Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Ask a question',
                  style: Theme.of(ctx).textTheme.titleLarge),
              const SizedBox(height: 16),
              TextField(
                controller: title,
                decoration: const InputDecoration(labelText: 'Question title'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: body,
                maxLines: 3,
                decoration:
                    const InputDecoration(labelText: 'Details (optional)'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: subject,
                decoration: const InputDecoration(labelText: 'Subject'),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<EducationLevel>(
                value: level,
                decoration: const InputDecoration(labelText: 'Class / level'),
                items: EducationLevel.values
                    .map((e) =>
                        DropdownMenuItem(value: e, child: Text(e.name)))
                    .toList(),
                onChanged: (v) => setState(() => level = v ?? level),
              ),
              const SizedBox(height: 20),
              FilledButton(
                onPressed: () async {
                  final user = ref.read(appUserProvider).valueOrNull;
                  final uid = ref.read(currentUserProvider);
                  if (user == null || uid == null) return;
                  if (title.text.trim().isEmpty) return;
                  try {
                    final id = await ref
                        .read(communityRepositoryProvider)
                        .askQuestion(
                          authorId: uid,
                          authorName: user.displayName,
                          authorPhotoUrl: user.photoUrl,
                          title: title.text.trim(),
                          body: body.text.trim(),
                          subject: subject.text.trim(),
                          level: level,
                        );
                    if (ctx.mounted) Navigator.pop(ctx);
                    if (context.mounted) {
                      context.push(AppRoutes.question(id));
                    }
                  } catch (e) {
                    if (ctx.mounted) {
                      ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
                          content: Text(AppException.from(e).message)));
                    }
                  }
                },
                child: const Text('Post question'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
