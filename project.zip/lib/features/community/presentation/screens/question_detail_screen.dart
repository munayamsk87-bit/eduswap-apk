import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/errors/app_exception.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../shared/models/answer.dart';
import '../../../../shared/providers/auth_providers.dart';
import '../../../../shared/providers/feed_providers.dart';
import '../../data/community_repository.dart';

class QuestionDetailScreen extends ConsumerStatefulWidget {
  const QuestionDetailScreen({super.key, required this.questionId});

  final String questionId;

  @override
  ConsumerState<QuestionDetailScreen> createState() =>
      _QuestionDetailScreenState();
}

class _QuestionDetailScreenState
    extends ConsumerState<QuestionDetailScreen> {
  final _answer = TextEditingController();
  bool _posting = false;

  @override
  void dispose() {
    _answer.dispose();
    super.dispose();
  }

  Future<void> _post() async {
    final text = _answer.text.trim();
    if (text.isEmpty) return;
    final user = ref.read(appUserProvider).valueOrNull;
    final uid = ref.read(currentUserProvider);
    if (user == null || uid == null) return;
    setState(() => _posting = true);
    try {
      await ref.read(communityRepositoryProvider).addAnswer(
            questionId: widget.questionId,
            authorId: uid,
            authorName: user.displayName,
            authorPhotoUrl: user.photoUrl,
            body: text,
          );
      _answer.clear();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(AppException.from(e).message)));
      }
    } finally {
      if (mounted) setState(() => _posting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final question = ref.watch(questionByIdProvider(widget.questionId));
    final answers = ref.watch(answersProvider(widget.questionId));
    final uid = ref.watch(currentUserProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Question')),
      body: question.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text(AppException.from(e).message)),
        data: (q) {
          if (q == null) {
            return const Center(child: Text('This question was removed.'));
          }
          final isOwner = q.authorId == uid;
          return Column(
            children: [
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Text(q.title,
                        style: theme.textTheme.titleLarge
                            ?.copyWith(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 6),
                    Text('${q.authorName} • ${q.subject}',
                        style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant)),
                    if (q.body.isNotEmpty) ...[
                      const SizedBox(height: 12),
                      Text(q.body, style: theme.textTheme.bodyLarge),
                    ],
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        OutlinedButton.icon(
                          onPressed: () => ref
                              .read(communityRepositoryProvider)
                              .voteQuestion(q.id),
                          icon: const Icon(Icons.arrow_upward, size: 18),
                          label: Text('${q.upvotes} helpful'),
                        ),
                      ],
                    ),
                    const Divider(height: 32),
                    Text('${q.answerCount} answers',
                        style: theme.textTheme.titleSmall
                            ?.copyWith(fontWeight: FontWeight.w600)),
                    const SizedBox(height: 8),
                    answers.when(
                      loading: () =>
                          const Center(child: CircularProgressIndicator()),
                      error: (e, _) => Text(AppException.from(e).message),
                      data: (list) => list.isEmpty
                          ? const Padding(
                              padding: EdgeInsets.symmetric(vertical: 24),
                              child: Text('No answers yet — be the first.'),
                            )
                          : Column(
                              children: [
                                for (final a in list)
                                  _AnswerCard(
                                    answer: a,
                                    canAccept: isOwner,
                                    onAccept: () => ref
                                        .read(communityRepositoryProvider)
                                        .acceptAnswer(q.id, a.id),
                                    onVote: () => ref
                                        .read(communityRepositoryProvider)
                                        .voteAnswer(q.id, a.id),
                                  ),
                              ],
                            ),
                    ),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
              SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _answer,
                          maxLines: 3,
                          minLines: 1,
                          decoration: const InputDecoration(
                              hintText: 'Write your answer…'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      IconButton.filled(
                        onPressed: _posting ? null : _post,
                        icon: const Icon(Icons.send_rounded),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _AnswerCard extends StatelessWidget {
  const _AnswerCard({
    required this.answer,
    required this.canAccept,
    required this.onAccept,
    required this.onVote,
  });

  final Answer answer;
  final bool canAccept;
  final VoidCallback onAccept;
  final VoidCallback onVote;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 14,
                  backgroundColor: AppColors.mint,
                  child: Text(answer.authorName.isEmpty
                      ? '?'
                      : answer.authorName[0].toUpperCase()),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(answer.authorName,
                      style: theme.textTheme.bodySmall
                          ?.copyWith(fontWeight: FontWeight.w600)),
                ),
                if (answer.isAccepted)
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: AppColors.success.withOpacity(0.14),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text('Accepted',
                        style:
                            TextStyle(color: AppColors.success, fontSize: 11)),
                  ),
              ],
            ),
            const SizedBox(height: 10),
            Text(answer.body, style: theme.textTheme.bodyMedium),
            const SizedBox(height: 10),
            Row(
              children: [
                TextButton.icon(
                  onPressed: onVote,
                  icon: const Icon(Icons.arrow_upward, size: 16),
                  label: Text('${answer.upvotes}'),
                ),
                if (canAccept && !answer.isAccepted)
                  TextButton(
                    onPressed: onAccept,
                    child: const Text('Mark as accepted'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
