import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/app_constants.dart';
import '../../../core/constants/enums.dart';
import '../../../shared/models/answer.dart';
import '../../../shared/models/question.dart';
import '../../../shared/providers/firebase_providers.dart';

/// Q&A community. Votes, counters and accepted-answer flags are all applied
/// server-side to prevent repeat voting and fraudulent engagement.
class CommunityRepository {
  CommunityRepository(this._db, this._functions);

  final FirebaseFirestore _db;
  final FirebaseFunctions _functions;

  CollectionReference<Map<String, dynamic>> get _questions =>
      _db.collection(AppConstants.questionsCol);

  Stream<List<Question>> watchQuestions({
    String? subject,
    int limit = AppConstants.pageSize,
  }) {
    Query<Map<String, dynamic>> q = _questions;
    if (subject != null && subject.isNotEmpty) {
      q = q.where('subject', isEqualTo: subject);
    }
    return q
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .snapshots()
        .map((s) => s.docs.map((d) => Question.fromJson(d.data())).toList());
  }

  Future<Question?> getQuestion(String id) async {
    final doc = await _questions.doc(id).get();
    return doc.exists ? Question.fromJson(doc.data()!) : null;
  }

  Stream<List<Answer>> watchAnswers(String questionId) {
    return _questions
        .doc(questionId)
        .collection(AppConstants.answersSubCol)
        .orderBy('upvotes', descending: true)
        .snapshots()
        .map((s) => s.docs.map((d) => Answer.fromJson(d.data())).toList());
  }

  Future<String> askQuestion({
    required String authorId,
    required String authorName,
    String? authorPhotoUrl,
    required String title,
    required String body,
    required String subject,
    required EducationLevel level,
    List<String> tags = const [],
  }) async {
    final ref = _questions.doc();
    await ref.set({
      'id': ref.id,
      'authorId': authorId,
      'authorName': authorName,
      'authorPhotoUrl': authorPhotoUrl,
      'title': title,
      'body': body,
      'subject': subject,
      'educationLevel': level.name,
      'tags': tags,
      'upvotes': 0,
      'answerCount': 0,
      'createdAt': Timestamp.fromDate(DateTime.now()),
    });
    return ref.id;
  }

  Future<void> addAnswer({
    required String questionId,
    required String authorId,
    required String authorName,
    String? authorPhotoUrl,
    required String body,
  }) async {
    final qRef = _questions.doc(questionId);
    final aRef = qRef.collection(AppConstants.answersSubCol).doc();
    final batch = _db.batch();
    batch.set(aRef, {
      'id': aRef.id,
      'questionId': questionId,
      'authorId': authorId,
      'authorName': authorName,
      'authorPhotoUrl': authorPhotoUrl,
      'body': body,
      'upvotes': 0,
      'isAccepted': false,
      'createdAt': Timestamp.fromDate(DateTime.now()),
    });
    batch.update(qRef, {'answerCount': FieldValue.increment(1)});
    await batch.commit();
  }

  Future<void> voteQuestion(String questionId) async {
    await _functions.httpsCallable('voteQuestion').call({'questionId': questionId});
  }

  Future<void> voteAnswer(String questionId, String answerId) async {
    await _functions
        .httpsCallable('voteAnswer')
        .call({'questionId': questionId, 'answerId': answerId});
  }

  Future<void> acceptAnswer(String questionId, String answerId) async {
    await _functions
        .httpsCallable('acceptAnswer')
        .call({'questionId': questionId, 'answerId': answerId});
  }
}

final communityRepositoryProvider = Provider<CommunityRepository>((ref) {
  return CommunityRepository(
    ref.watch(firestoreProvider),
    ref.watch(functionsProvider),
  );
});
