import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/widgets/async_value_view.dart';
import '../../../../core/widgets/empty_state.dart';
import '../../../../core/widgets/loading_skeleton.dart';
import '../../../../shared/models/app_notification.dart';
import '../../../../shared/providers/auth_providers.dart';
import '../../../../shared/providers/feed_providers.dart';
import '../../data/notification_repository.dart';
import '../../../../core/constants/enums.dart';

class NotificationsScreen extends ConsumerWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final uid = ref.watch(currentUserProvider)?.uid;
    final notifications = ref.watch(myNotificationsProvider);
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        actions: [
          if (uid != null)
            TextButton(
              onPressed: () => ref
                  .read(notificationRepositoryProvider)
                  .markAllRead(uid),
              child: const Text('Mark all read'),
            ),
        ],
      ),
      body: AsyncValueView<List<AppNotification>>(
        value: notifications,
        onRetry: () => ref.invalidate(myNotificationsProvider),
        loading: LoadingSkeleton.list(count: 6, height: 72),
        isEmpty: (l) => l.isEmpty,
        emptyTitle: 'No notifications',
        emptyMessage: 'Swap requests, replies and moderation updates show here.',
        data: (list) => ListView.separated(
          itemCount: list.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (_, i) {
            final n = list[i];
            return ListTile(
              leading: CircleAvatar(
                backgroundColor: n.read
                    ? theme.colorScheme.surfaceContainerHighest
                    : theme.colorScheme.primaryContainer,
                child: Icon(_icon(n), size: 20),
              ),
              title: Text(n.title,
                  style: TextStyle(
                    fontWeight: n.read ? FontWeight.normal : FontWeight.w700,
                  )),
              subtitle: n.body.isEmpty ? null : Text(n.body),
              trailing: n.read
                  ? null
                  : Container(
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                          color: Colors.blue, shape: BoxShape.circle),
                    ),
              onTap: () => ref
                  .read(notificationRepositoryProvider)
                  .markRead(n.id),
            );
          },
        ),
      ),
    );
  }

  IconData _icon(AppNotification n) {
    switch (n.type) {
      case NotificationType.newMessage:
        return Icons.chat_bubble_outline;
      case NotificationType.newSwapRequest:
        return Icons.swap_horiz;
      case NotificationType.swapAccepted:
        return Icons.check_circle_outline;
      case NotificationType.swapDeclined:
        return Icons.cancel_outlined;
      case NotificationType.questionReply:
        return Icons.forum_outlined;
      case NotificationType.helpfulAnswer:
        return Icons.thumb_up_outlined;
      case NotificationType.moderationResult:
        return Icons.verified_outlined;
      case NotificationType.reportResolution:
        return Icons.flag_outlined;
      case NotificationType.accountSecurity:
        return Icons.security;
    }
  }
}
