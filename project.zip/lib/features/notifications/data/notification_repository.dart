import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/app_constants.dart';
import '../../../shared/models/app_notification.dart';
import '../../../shared/providers/firebase_providers.dart';

/// In-app notifications. FCM delivery is handled by backend triggers.
class NotificationRepository {
  NotificationRepository(this._db);

  final FirebaseFirestore _db;

  CollectionReference<Map<String, dynamic>> get _col =>
      _db.collection(AppConstants.notificationsCol);

  Stream<List<AppNotification>> watch(String uid, {int limit = 50}) {
    return _col
        .where('userId', isEqualTo: uid)
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .snapshots()
        .map((s) =>
            s.docs.map((d) => AppNotification.fromJson(d.data())).toList());
  }

  Stream<int> watchUnreadCount(String uid) {
    return _col
        .where('userId', isEqualTo: uid)
        .where('read', isEqualTo: false)
        .snapshots()
        .map((s) => s.docs.length);
  }

  Future<void> markRead(String id) => _col.doc(id).update({'read': true});

  Future<void> markAllRead(String uid) async {
    final batch = _db.batch();
    final docs = await _col
        .where('userId', isEqualTo: uid)
        .where('read', isEqualTo: false)
        .get();
    for (final d in docs.docs) {
      batch.update(d.reference, {'read': true});
    }
    await batch.commit();
  }
}

final notificationRepositoryProvider =
    Provider<NotificationRepository>((ref) {
  return NotificationRepository(ref.watch(firestoreProvider));
});
