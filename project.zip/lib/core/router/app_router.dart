import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/admin/presentation/screens/admin_dashboard_screen.dart';
import '../../features/ai/presentation/screens/ai_assistant_screen.dart';
import '../../features/auth/presentation/screens/forgot_password_screen.dart';
import '../../features/auth/presentation/screens/login_screen.dart';
import '../../features/auth/presentation/screens/onboarding_screen.dart';
import '../../features/auth/presentation/screens/profile_setup_screen.dart';
import '../../features/auth/presentation/screens/register_screen.dart';
import '../../features/auth/presentation/screens/splash_screen.dart';
import '../../features/chat/presentation/screens/chat_list_screen.dart';
import '../../features/chat/presentation/screens/chat_room_screen.dart';
import '../../features/community/presentation/screens/community_screen.dart';
import '../../features/community/presentation/screens/question_detail_screen.dart';
import '../../features/explore/presentation/screens/explore_screen.dart';
import '../../features/home/presentation/screens/home_screen.dart';
import '../../features/notifications/presentation/screens/notifications_screen.dart';
import '../../features/profile/presentation/screens/profile_screen.dart';
import '../../features/profile/presentation/screens/user_profile_screen.dart';
import '../../features/resources/presentation/screens/resource_detail_screen.dart';
import '../../features/settings/presentation/screens/reports_screen.dart';
import '../../features/settings/presentation/screens/settings_screen.dart';
import '../../features/skills/presentation/screens/skill_sharing_screen.dart';
import '../../features/swap/presentation/screens/swap_requests_screen.dart';
import '../../features/upload/presentation/screens/add_resource_screen.dart';
import '../../features/wishlist/presentation/screens/wishlist_screen.dart';
import '../../shared/providers/auth_providers.dart';
import '../widgets/main_scaffold.dart';

/// Every path in the app. Screens navigate with these, never with raw strings.
class AppRoutes {
  AppRoutes._();

  static const splash = '/';
  static const onboarding = '/onboarding';
  static const login = '/login';
  static const register = '/register';
  static const forgotPassword = '/forgot-password';
  static const profileSetup = '/setup';

  static const home = '/home';
  static const explore = '/explore';
  static const upload = '/upload';
  static const chat = '/chat';
  static const chatRoom = '/chat-room'; // /chat-room/:id
  static const profile = '/profile';

  static const resourceDetail = '/resource'; // /resource/:id
  static const swapRequests = '/swaps';
  static const aiAssistant = '/ai';
  static const community = '/community';
  static const questionDetail = '/question'; // /question/:id
  static const skillSharing = '/skills';
  static const notifications = '/notifications';
  static const wishlist = '/wishlist';
  static const userProfile = '/user'; // /user/:id
  static const settings = '/settings';
  static const reports = '/reports';
  static const admin = '/admin';

  static String resource(String id) => '$resourceDetail/$id';
  static String conversation(String id) => '$chatRoom/$id';
  static String question(String id) => '$questionDetail/$id';
  static String user(String id) => '$userProfile/$id';
}

/// Paths reachable without being signed in.
const _publicRoutes = <String>{
  AppRoutes.splash,
  AppRoutes.onboarding,
  AppRoutes.login,
  AppRoutes.register,
  AppRoutes.forgotPassword,
};

final routerProvider = Provider<GoRouter>((ref) {
  // The router is created once. Auth changes trigger a re-evaluation of the
  // redirect via a Listenable, instead of rebuilding the router (which would
  // reset the navigation stack).
  final refresh = ValueNotifier<int>(0);
  ref.listen(authStateProvider, (_, __) => refresh.value++);
  ref.onDispose(refresh.dispose);

  return GoRouter(
    initialLocation: AppRoutes.splash,
    debugLogDiagnostics: false,
    refreshListenable: refresh,
    redirect: (context, state) {
      final auth = ref.read(authStateProvider);
      final signedIn = auth.valueOrNull != null;
      final goingPublic = _publicRoutes.contains(state.matchedLocation);

      // Wait for the first auth emission before deciding.
      if (auth.isLoading) return null;

      if (!signedIn && !goingPublic) {
        return AppRoutes.login;
      }
      if (signedIn && goingPublic && state.matchedLocation != AppRoutes.splash) {
        return AppRoutes.home;
      }
      return null;
    },
    routes: [
      GoRoute(
        path: AppRoutes.splash,
        builder: (_, __) => const SplashScreen(),
      ),
      GoRoute(
        path: AppRoutes.onboarding,
        builder: (_, __) => const OnboardingScreen(),
      ),
      GoRoute(
        path: AppRoutes.login,
        builder: (_, __) => const LoginScreen(),
      ),
      GoRoute(
        path: AppRoutes.register,
        builder: (_, __) => const RegisterScreen(),
      ),
      GoRoute(
        path: AppRoutes.forgotPassword,
        builder: (_, __) => const ForgotPasswordScreen(),
      ),
      GoRoute(
        path: AppRoutes.profileSetup,
        builder: (_, __) => const ProfileSetupScreen(),
      ),

      // The five primary tabs live in one shell so the bottom bar persists.
      StatefulShellRoute.indexedStack(
        builder: (_, __, navigationShell) => MainScaffold(shell: navigationShell),
        branches: [
          StatefulShellBranch(routes: [
            GoRoute(path: AppRoutes.home, builder: (_, __) => const HomeScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: AppRoutes.explore, builder: (_, __) => const ExploreScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: AppRoutes.upload, builder: (_, __) => const AddResourceScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: AppRoutes.chat, builder: (_, __) => const ChatListScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: AppRoutes.profile, builder: (_, __) => const ProfileScreen()),
          ]),
        ],
      ),

      // Secondary routes (pushed above the shell).
      GoRoute(
        path: '${AppRoutes.resourceDetail}/:id',
        builder: (_, state) =>
            ResourceDetailScreen(resourceId: state.pathParameters['id']!),
      ),
      GoRoute(
        path: '${AppRoutes.chatRoom}/:id',
        builder: (_, state) => ChatRoomScreen(
          conversationId: state.pathParameters['id']!,
          peerName: state.uri.queryParameters['peer'] ?? 'Chat',
        ),
      ),
      GoRoute(
        path: AppRoutes.swapRequests,
        builder: (_, __) => const SwapRequestsScreen(),
      ),
      GoRoute(
        path: AppRoutes.aiAssistant,
        builder: (_, __) => const AiAssistantScreen(),
      ),
      GoRoute(
        path: AppRoutes.community,
        builder: (_, __) => const CommunityScreen(),
      ),
      GoRoute(
        path: '${AppRoutes.questionDetail}/:id',
        builder: (_, state) =>
            QuestionDetailScreen(questionId: state.pathParameters['id']!),
      ),
      GoRoute(
        path: AppRoutes.skillSharing,
        builder: (_, __) => const SkillSharingScreen(),
      ),
      GoRoute(
        path: AppRoutes.notifications,
        builder: (_, __) => const NotificationsScreen(),
      ),
      GoRoute(
        path: AppRoutes.wishlist,
        builder: (_, __) => const WishlistScreen(),
      ),
      GoRoute(
        path: '${AppRoutes.userProfile}/:id',
        builder: (_, state) =>
            UserProfileScreen(userId: state.pathParameters['id']!),
      ),
      GoRoute(
        path: AppRoutes.settings,
        builder: (_, __) => const SettingsScreen(),
      ),
      GoRoute(
        path: AppRoutes.reports,
        builder: (_, __) => const ReportsScreen(),
      ),
      GoRoute(
        path: AppRoutes.admin,
        builder: (_, __) => const AdminDashboardScreen(),
      ),
    ],
    errorBuilder: (context, state) => Scaffold(
      appBar: AppBar(title: const Text('Not found')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.explore_off_outlined, size: 56),
              const SizedBox(height: 16),
              Text('We could not find that screen.',
                  style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              Text(state.uri.toString(),
                  style: Theme.of(context).textTheme.bodySmall),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: () => context.go(AppRoutes.home),
                child: const Text('Go home'),
              ),
            ],
          ),
        ),
      ),
    ),
  );
});
