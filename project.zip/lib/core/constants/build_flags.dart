/// Build-time flags.
///
/// Build the offline (no-backend) variant with:
///   flutter build apk --dart-define=OFFLINE=true
const bool kOfflineMode = bool.fromEnvironment('OFFLINE', defaultValue: false);
