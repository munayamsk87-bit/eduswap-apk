/// Enumerations shared across the app. Stored in Firestore as their [name].

enum EducationLevel { primary, secondary, higherSecondary, undergraduate, postgraduate, other }

enum ResourceType {
  textbook,
  physicalBook,
  pdfNotes,
  typedNotes,
  handwrittenNotes,
  questionPaper,
  worksheet,
  studyGuide,
  educationalImage,
  skillResource,
}

enum ResourceStatus { draft, pendingReview, approved, rejected, removed }

enum SwapStatus { requested, accepted, declined, cancelled, completed, expired, disputed }

enum SkillDifficulty { beginner, intermediate, advanced }

enum ReportTargetType { resource, message, user, question, answer }

enum ReportStatus { open, reviewing, resolved, dismissed }

enum NotificationType {
  newMessage,
  newSwapRequest,
  swapAccepted,
  swapDeclined,
  questionReply,
  helpfulAnswer,
  moderationResult,
  reportResolution,
  accountSecurity,
}

enum AppLanguage { english, bengali, hindi }

extension ResourceTypeX on ResourceType {
  String get label => switch (this) {
        ResourceType.textbook => 'Textbook',
        ResourceType.physicalBook => 'Physical book (swap)',
        ResourceType.pdfNotes => 'PDF notes',
        ResourceType.typedNotes => 'Typed notes',
        ResourceType.handwrittenNotes => 'Handwritten notes',
        ResourceType.questionPaper => 'Question paper',
        ResourceType.worksheet => 'Practice worksheet',
        ResourceType.studyGuide => 'Study guide',
        ResourceType.educationalImage => 'Educational image',
        ResourceType.skillResource => 'Skill resource',
      };

  bool get isPhysical => this == ResourceType.physicalBook;
}
