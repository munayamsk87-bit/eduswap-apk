/// App-wide constants. Keep magic values here so screens stay consistent.
class AppConstants {
  AppConstants._();

  static const appName = 'EduSwap';
  static const tagline = 'Learn together. Share freely.';

  // Firestore collection names (mirror of the documented data model).
  static const usersCol = 'users';
  static const resourcesCol = 'resources';
  static const swapRequestsCol = 'swapRequests';
  static const conversationsCol = 'conversations';
  static const messagesSubCol = 'messages';
  static const questionsCol = 'questions';
  static const answersSubCol = 'answers';
  static const savedResourcesCol = 'savedResources';
  static const skillListingsCol = 'skillListings';
  static const learningRequestsCol = 'learningRequests';
  static const notificationsCol = 'notifications';
  static const reportsCol = 'reports';
  static const moderationCasesCol = 'moderationCases';
  static const userBlocksCol = 'userBlocks';
  static const reputationEventsCol = 'reputationEvents';
  static const adminAuditLogsCol = 'adminAuditLogs';
  static const appConfigCol = 'appConfiguration';

  // Storage prefixes.
  static const resourceFilesPrefix = 'resource_files';
  static const coversPrefix = 'covers';
  static const avatarsPrefix = 'avatars';
  static const chatImagesPrefix = 'chat_images';

  // Limits.
  static const maxResourceFileBytes = 25 * 1024 * 1024; // 25 MB
  static const maxImageBytes = 5 * 1024 * 1024; // 5 MB
  static const pageSize = 20;

  // Feature flags read from appConfiguration; safe defaults.
  static const aiEnabledByDefault = false;
  static const moderationRequiredByDefault = true;
}
