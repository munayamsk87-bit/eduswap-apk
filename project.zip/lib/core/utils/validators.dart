/// Form validators used across auth and upload forms.
class Validators {
  Validators._();

  static final _emailRe = RegExp(r'^[\w.+-]+@[\w-]+\.[\w.-]+$');

  static String? email(String? v) {
    final value = v?.trim() ?? '';
    if (value.isEmpty) return 'Enter your email';
    if (!_emailRe.hasMatch(value)) return 'Enter a valid email';
    return null;
  }

  static String? password(String? v) {
    final value = v ?? '';
    if (value.isEmpty) return 'Enter a password';
    if (value.length < 8) return 'Use at least 8 characters';
    return null;
  }

  static String? required(String? v, {String field = 'This field'}) {
    if ((v ?? '').trim().isEmpty) return '$field is required';
    return null;
  }

  static String? maxLen(String? v, int max, {String field = 'This field'}) {
    if ((v ?? '').length > max) return '$field must be under $max characters';
    return null;
  }
}
