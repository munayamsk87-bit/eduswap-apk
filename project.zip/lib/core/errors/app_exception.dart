/// A single, UI-friendly error type so screens never surface raw exceptions.
class AppException implements Exception {
  const AppException(this.message, {this.code});

  final String message;
  final String? code;

  @override
  String toString() => message;

  factory AppException.from(Object error) {
    final text = error.toString();
    // Strip noisy SDK prefixes; keep the human part.
    if (text.contains('permission-denied')) {
      return const AppException('You do not have permission to do that.');
    }
    if (text.contains('unavailable') || text.contains('network')) {
      return const AppException('No connection. Please check your network and retry.');
    }
    if (text.contains('unauthenticated')) {
      return const AppException('Your session expired. Please sign in again.');
    }
    return AppException(text.replaceFirst(RegExp(r'^\[.*?\]\s*'), ''));
  }
}
