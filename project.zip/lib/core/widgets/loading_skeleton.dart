import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

/// Shimmer placeholder used while lists and cards load.
class LoadingSkeleton extends StatelessWidget {
  const LoadingSkeleton({super.key, this.height = 96, this.radius = 20});

  final double height;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final base = Theme.of(context).colorScheme.surfaceContainerHighest;
    return Shimmer.fromColors(
      baseColor: base.withOpacity(0.6),
      highlightColor: base.withOpacity(0.2),
      child: Container(
        height: height,
        decoration: BoxDecoration(
          color: base,
          borderRadius: BorderRadius.circular(radius),
        ),
      ),
    );
  }

  /// A column of shimmering card placeholders.
  static Widget list({int count = 5, double height = 96}) {
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: count,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (_, __) => LoadingSkeleton(height: height),
    );
  }
}
