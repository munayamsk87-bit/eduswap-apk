import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'empty_state.dart';
import 'error_state.dart';

/// Renders a Riverpod [AsyncValue] with consistent loading / empty / error UI.
class AsyncValueView<T> extends StatelessWidget {
  const AsyncValueView({
    super.key,
    required this.value,
    required this.data,
    this.onRetry,
    this.loading,
    this.isEmpty,
    this.emptyTitle = 'Nothing here yet',
    this.emptyMessage,
  });

  final AsyncValue<T> value;
  final Widget Function(T data) data;
  final VoidCallback? onRetry;
  final Widget? loading;
  final bool Function(T data)? isEmpty;
  final String emptyTitle;
  final String? emptyMessage;

  @override
  Widget build(BuildContext context) {
    return value.when(
      skipLoadingOnRefresh: true,
      loading: () => loading ?? const Center(child: CircularProgressIndicator()),
      error: (error, _) => ErrorState(error: error, onRetry: onRetry),
      data: (d) {
        if (isEmpty?.call(d) ?? false) {
          return EmptyState(title: emptyTitle, message: emptyMessage);
        }
        return data(d);
      },
    );
  }
}
