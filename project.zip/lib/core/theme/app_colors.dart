import 'package:flutter/material.dart';

/// Brand palette. Primary green #2E7D32, secondary blue #1976D2.
class AppColors {
  AppColors._();

  static const primary = Color(0xFF2E7D32);
  static const primaryDark = Color(0xFF1B5E20);
  static const primaryLight = Color(0xFF60AD5E);
  static const secondary = Color(0xFF1976D2);
  static const secondaryDark = Color(0xFF0D47A1);

  static const surface = Color(0xFFFBFBF7);
  static const surfaceDark = Color(0xFF121512);

  // Pastel accents for subject chips, badges and empty states.
  static const mint = Color(0xFFE6F4EA);
  static const sky = Color(0xFFE3F2FD);
  static const peach = Color(0xFFFFF1E6);
  static const lilac = Color(0xFFF0E9FB);
  static const lemon = Color(0xFFFBF7E0);

  static const success = Color(0xFF2E7D32);
  static const warning = Color(0xFFEF6C00);
  static const error = Color(0xFFC62828);
}
