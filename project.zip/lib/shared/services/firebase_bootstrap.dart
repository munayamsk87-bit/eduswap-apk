import 'dart:developer' as developer;

import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/foundation.dart';

/// Initializes Firebase once at startup.
///
/// On Android, dropping your `google-services.json` into
/// `android/app/` is enough for [Firebase.initializeApp] to find config.
/// If you ran `flutterfire configure`, pass the generated
/// `DefaultFirebaseOptions.currentPlatform` instead (see README).
///
/// Nothing here fakes a connection: if credentials are missing, initialization
/// throws and the app shows a clear setup message rather than pretending.
class FirebaseBootstrap {
  FirebaseBootstrap._();

  static Future<void> initialize() async {
    await Firebase.initializeApp();

    // App Check protects backend resources from abuse. In debug builds use the
    // debug provider; in release builds switch to Play Integrity.
    await FirebaseAppCheck.instance.activate(
      androidProvider:
          kDebugMode ? AndroidProvider.debug : AndroidProvider.playIntegrity,
    );

    // Route framework errors to Crashlytics; keep console logging in debug.
    FlutterError.onError = (details) {
      if (kDebugMode) {
        FlutterError.presentError(details);
      } else {
        FirebaseCrashlytics.instance.recordFlutterFatalError(details);
      }
    };

    developer.log('Firebase initialized', name: 'bootstrap');
  }
}
