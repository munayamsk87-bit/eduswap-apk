import 'package:freezed_annotation/freezed_annotation.dart';

import 'firestore_converters.dart';

part 'conversation.freezed.dart';
part 'conversation.g.dart';

/// A one-to-one conversation, optionally linked to a resource or swap request.
/// Membership is enforced by Firestore Security Rules, not just the client.
@freezed
class Conversation with _$Conversation {
  const factory Conversation({
    required String id,
    required List<String> participants,
    Map<String, String>? participantNames,
    String? resourceId,
    String? resourceTitle,
    String? swapRequestId,
    String? lastMessage,
    @Default(<String, int>{}) Map<String, int> unread,
    @JsonKey(fromJson: timestampFromJson, toJson: timestampToJson)
    DateTime? lastMessageAt,
    @JsonKey(fromJson: timestampFromJson, toJson: timestampToJson)
    DateTime? createdAt,
  }) = _Conversation;

  factory Conversation.fromJson(Map<String, dynamic> json) =>
      _$ConversationFromJson(json);
}
