import 'package:freezed_annotation/freezed_annotation.dart';

import '../../core/constants/enums.dart';
import 'firestore_converters.dart';

part 'swap_request.freezed.dart';
part 'swap_request.g.dart';

/// A non-monetary book-swap request between two students. All state
/// transitions are validated server-side (see functions/src/index.ts).
@freezed
class SwapRequest with _$SwapRequest {
  const factory SwapRequest({
    required String id,
    required String resourceId,
    required String resourceTitle,
    required String requesterId,
    required String requesterName,
    required String ownerId,
    required String ownerName,
    String? offeredResourceId,
    String? offeredResourceTitle,
    @Default('') String message,
    @Default(SwapStatus.requested) SwapStatus status,
    @Default(<String>[]) List<String> participants,
    // Feedback is optional and only after completion.
    int? requesterRating,
    int? ownerRating,
    String? requesterFeedback,
    String? ownerFeedback,
    @JsonKey(fromJson: timestampFromJson, toJson: timestampToJson)
    DateTime? createdAt,
    @JsonKey(fromJson: timestampFromJson, toJson: timestampToJson)
    DateTime? updatedAt,
    @JsonKey(fromJson: timestampFromJson, toJson: timestampToJson)
    DateTime? expiresAt,
  }) = _SwapRequest;

  factory SwapRequest.fromJson(Map<String, dynamic> json) =>
      _$SwapRequestFromJson(json);
}
