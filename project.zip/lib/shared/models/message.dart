import 'package:freezed_annotation/freezed_annotation.dart';

import 'firestore_converters.dart';

part 'message.freezed.dart';
part 'message.g.dart';

/// A single chat message. Images are validated and stored in Storage; never
/// store base64 blobs in Firestore.
@freezed
class Message with _$Message {
  const factory Message({
    required String id,
    required String senderId,
    String? senderName,
    String? text,
    String? imageUrl,
    String? replyToId,
    @Default(<String>[]) List<String> readBy,
    @JsonKey(fromJson: timestampFromJson, toJson: timestampToJson)
    DateTime? createdAt,
  }) = _Message;

  factory Message.fromJson(Map<String, dynamic> json) => _$MessageFromJson(json);
}
