import 'package:freezed_annotation/freezed_annotation.dart';

import '../../core/constants/enums.dart';
import 'firestore_converters.dart';

part 'question.freezed.dart';
part 'question.g.dart';

/// A community question. Personal details are never shown in public threads.
@freezed
class Question with _$Question {
  const factory Question({
    required String id,
    required String authorId,
    required String authorName,
    String? authorPhotoUrl,
    required String title,
    @Default('') String body,
    @Default('') String subject,
    @Default(EducationLevel.secondary) EducationLevel educationLevel,
    String? imageUrl,
    @Default(<String>[]) List<String> tags,
    @Default(0) int upvotes,
    @Default(0) int answerCount,
    String? acceptedAnswerId,
    @JsonKey(fromJson: timestampFromJson, toJson: timestampToJson)
    DateTime? createdAt,
  }) = _Question;

  factory Question.fromJson(Map<String, dynamic> json) => _$QuestionFromJson(json);
}
