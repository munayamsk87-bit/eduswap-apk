import 'package:freezed_annotation/freezed_annotation.dart';

import '../../core/constants/enums.dart';
import 'firestore_converters.dart';

part 'resource.freezed.dart';
part 'resource.g.dart';

/// An educational resource listing: a book, notes, a question paper, etc.
/// Files live in Firebase Storage; only metadata is stored here.
@freezed
class Resource with _$Resource {
  const factory Resource({
    required String id,
    required String ownerId,
    required String ownerName,
    String? ownerPhotoUrl,
    required String title,
    @Default('') String description,
    required ResourceType type,
    String? category,
    @Default('') String subject,
    @Default(EducationLevel.secondary) EducationLevel educationLevel,
    String? board,
    @Default(AppLanguage.english) AppLanguage language,
    @Default(<String>[]) List<String> tags,
    String? coverUrl,
    String? fileUrl,
    String? filePath,
    int? fileSizeBytes,
    String? mimeType,
    // Physical-book specific.
    String? bookAuthor,
    String? condition,
    String? exchangeLocality,
    @Default(<String>[]) List<String> swapPreferences,
    @Default(true) bool available,
    // Lifecycle & counters.
    @Default(ResourceStatus.pendingReview) ResourceStatus status,
    String? moderationNote,
    @Default(0) int saveCount,
    @Default(0) int downloadCount,
    @JsonKey(fromJson: timestampFromJson, toJson: timestampToJson)
    DateTime? createdAt,
    @JsonKey(fromJson: timestampFromJson, toJson: timestampToJson)
    DateTime? updatedAt,
  }) = _Resource;

  factory Resource.fromJson(Map<String, dynamic> json) => _$ResourceFromJson(json);
}
