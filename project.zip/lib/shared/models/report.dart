import 'package:freezed_annotation/freezed_annotation.dart';

import '../../core/constants/enums.dart';
import 'firestore_converters.dart';

part 'report.freezed.dart';
part 'report.g.dart';

/// A safety report about a resource, message, user, question or answer.
@freezed
class Report with _$Report {
  const factory Report({
    required String id,
    required String reporterId,
    required ReportTargetType targetType,
    required String targetId,
    required String reason,
    @Default('') String details,
    @Default(ReportStatus.open) ReportStatus status,
    String? resolvedBy,
    String? resolutionNote,
    @JsonKey(fromJson: timestampFromJson, toJson: timestampToJson)
    DateTime? createdAt,
    @JsonKey(fromJson: timestampFromJson, toJson: timestampToJson)
    DateTime? resolvedAt,
  }) = _Report;

  factory Report.fromJson(Map<String, dynamic> json) => _$ReportFromJson(json);
}
