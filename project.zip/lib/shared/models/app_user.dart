import 'package:freezed_annotation/freezed_annotation.dart';

import '../../core/constants/enums.dart';
import 'firestore_converters.dart';

part 'app_user.freezed.dart';
part 'app_user.g.dart';

/// A student (or staff) account. Private settings live in a subcollection,
/// not on this public-facing document.
@freezed
class AppUser with _$AppUser {
  const factory AppUser({
    required String uid,
    required String displayName,
    required String email,
    String? photoUrl,
    @Default(EducationLevel.secondary) EducationLevel educationLevel,
    String? institution,
    String? board,
    @Default(AppLanguage.english) AppLanguage preferredLanguage,
    @Default(<String>[]) List<String> subjects,
    @Default(<String>[]) List<String> interests,
    String? locality,
    String? bio,
    @Default('student') String role, // 'student' | 'moderator' | 'admin'
    @Default(0) int reputation,
    @Default(<String>[]) List<String> badges,
    @Default(false) bool isSuspended,
    @Default(true) bool onboardingComplete,
    @JsonKey(fromJson: timestampFromJson, toJson: timestampToJson)
    DateTime? createdAt,
    @JsonKey(fromJson: timestampFromJson, toJson: timestampToJson)
    DateTime? updatedAt,
  }) = _AppUser;

  factory AppUser.fromJson(Map<String, dynamic> json) => _$AppUserFromJson(json);
}
