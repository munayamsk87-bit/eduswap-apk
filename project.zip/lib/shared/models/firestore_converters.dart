import 'package:cloud_firestore/cloud_firestore.dart';

/// Reusable json_serializable converters between Firestore [Timestamp] and
/// Dart [DateTime]. Keeps every model consistent and null-safe.
DateTime? timestampFromJson(Object? value) {
  if (value == null) return null;
  if (value is Timestamp) return value.toDate();
  if (value is String) return DateTime.tryParse(value);
  if (value is int) return DateTime.fromMillisecondsSinceEpoch(value);
  return null;
}

DateTime timestampFromJsonRequired(Object? value) =>
    timestampFromJson(value) ?? DateTime.fromMillisecondsSinceEpoch(0);

Object? timestampToJson(DateTime? value) =>
    value == null ? null : Timestamp.fromDate(value);
