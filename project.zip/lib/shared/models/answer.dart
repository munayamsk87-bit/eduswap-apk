import 'package:freezed_annotation/freezed_annotation.dart';

import 'firestore_converters.dart';

part 'answer.freezed.dart';
part 'answer.g.dart';

/// An answer to a community [Question]. Only the question owner or a moderator
/// may mark it accepted — enforced server-side.
@freezed
class Answer with _$Answer {
  const factory Answer({
    required String id,
    required String questionId,
    required String authorId,
    required String authorName,
    String? authorPhotoUrl,
    @Default('') String body,
    String? imageUrl,
    @Default(0) int upvotes,
    @Default(false) bool isAccepted,
    @JsonKey(fromJson: timestampFromJson, toJson: timestampToJson)
    DateTime? createdAt,
  }) = _Answer;

  factory Answer.fromJson(Map<String, dynamic> json) => _$AnswerFromJson(json);
}
