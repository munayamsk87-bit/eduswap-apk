import 'package:freezed_annotation/freezed_annotation.dart';

import '../../core/constants/enums.dart';
import 'firestore_converters.dart';

part 'app_notification.freezed.dart';
part 'app_notification.g.dart';

/// An in-app notification. Also mirrored to FCM by trusted backend code —
/// never written from arbitrary clients.
@freezed
class AppNotification with _$AppNotification {
  const factory AppNotification({
    required String id,
    required String userId,
    required NotificationType type,
    required String title,
    @Default('') String body,
    @Default(<String, dynamic>{}) Map<String, dynamic> data,
    @Default(false) bool read,
    @JsonKey(fromJson: timestampFromJson, toJson: timestampToJson)
    DateTime? createdAt,
  }) = _AppNotification;

  factory AppNotification.fromJson(Map<String, dynamic> json) =>
      _$AppNotificationFromJson(json);
}
