import 'package:freezed_annotation/freezed_annotation.dart';

import '../../core/constants/enums.dart';
import 'firestore_converters.dart';

part 'skill_listing.freezed.dart';
part 'skill_listing.g.dart';

/// A free, non-monetized skill-sharing offer or request.
@freezed
class SkillListing with _$SkillListing {
  const factory SkillListing({
    required String id,
    required String ownerId,
    required String ownerName,
    String? ownerPhotoUrl,
    required String title,
    @Default('') String description,
    @Default(SkillDifficulty.beginner) SkillDifficulty difficulty,
    @Default(<String>[]) List<String> subjects,
    @Default('Online') String format,
    @Default('Flexible') String availability,
    @Default(<String>[]) List<String> languages,
    @Default(true) bool isOffer, // true = offering to teach, false = requesting
    @JsonKey(fromJson: timestampFromJson, toJson: timestampToJson)
    DateTime? createdAt,
  }) = _SkillListing;

  factory SkillListing.fromJson(Map<String, dynamic> json) =>
      _$SkillListingFromJson(json);
}
