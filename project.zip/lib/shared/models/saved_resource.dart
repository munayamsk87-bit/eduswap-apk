import 'package:freezed_annotation/freezed_annotation.dart';

import 'firestore_converters.dart';

part 'saved_resource.freezed.dart';
part 'saved_resource.g.dart';

/// A wishlist / bookmark entry. Kept in its own collection so "most saved"
/// counts are cheap and privacy stays intact.
@freezed
class SavedResource with _$SavedResource {
  const factory SavedResource({
    required String id,
    required String userId,
    required String resourceId,
    String? resourceTitle,
    String? coverUrl,
    @JsonKey(fromJson: timestampFromJson, toJson: timestampToJson)
    DateTime? savedAt,
  }) = _SavedResource;

  factory SavedResource.fromJson(Map<String, dynamic> json) =>
      _$SavedResourceFromJson(json);
}
