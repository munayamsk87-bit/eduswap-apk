import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Theme preference — follows the system by default, overridable in Settings.
final themeModeProvider = StateProvider<ThemeMode>((_) => ThemeMode.system);

/// Notification toggles (persisted via the user's private settings document
/// in a full build; kept in-memory here for the scaffold).
final pushEnabledProvider = StateProvider<bool>((_) => true);
final emailUpdatesProvider = StateProvider<bool>((_) => false);
