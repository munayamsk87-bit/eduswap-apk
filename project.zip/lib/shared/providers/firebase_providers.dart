import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Thin wrappers around the Firebase SDKs so repositories depend on providers,
/// not singletons — this keeps everything testable and overridable.
final firebaseAuthProvider = Provider<FirebaseAuth>((_) => FirebaseAuth.instance);

final firestoreProvider =
    Provider<FirebaseFirestore>((_) => FirebaseFirestore.instance);

final storageProvider =
    Provider<FirebaseStorage>((_) => FirebaseStorage.instance);

final functionsProvider =
    Provider<FirebaseFunctions>((_) => FirebaseFunctions.instance);

final messagingProvider =
    Provider<FirebaseMessaging>((_) => FirebaseMessaging.instance);

final analyticsProvider =
    Provider<FirebaseAnalytics>((_) => FirebaseAnalytics.instance);
