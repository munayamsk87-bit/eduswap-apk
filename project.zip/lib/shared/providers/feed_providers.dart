import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants/app_constants.dart';
import '../../features/chat/data/chat_repository.dart';
import '../../features/community/data/community_repository.dart';
import '../../features/notifications/data/notification_repository.dart';
import '../../features/resources/data/resource_repository.dart';
import '../../features/swap/data/swap_repository.dart';
import '../models/answer.dart';
import '../models/app_user.dart';
import '../models/app_notification.dart';
import '../models/conversation.dart';
import '../models/message.dart';
import '../models/question.dart';
import '../models/resource.dart';
import '../models/saved_resource.dart';
import '../models/swap_request.dart';
import 'auth_providers.dart';
import 'firebase_providers.dart';

/// Central feed providers. Screens watch these instead of talking to
/// repositories directly, which keeps rebuilds tight and testable.

final recentResourcesProvider = StreamProvider<List<Resource>>((ref) {
  return ref.watch(resourceRepositoryProvider).watchRecent(limit: 20);
});

final popularQuestionsProvider = StreamProvider<List<Question>>((ref) {
  return ref
      .watch(communityRepositoryProvider)
      .watchQuestions(limit: 10);
});

final myResourcesProvider = StreamProvider<List<Resource>>((ref) {
  final uid = ref.watch(currentUserProvider);
  if (uid == null) return Stream.empty();
  return ref.watch(resourceRepositoryProvider).watchByOwner(uid);
});

final myConversationsProvider = StreamProvider<List<Conversation>>((ref) {
  final uid = ref.watch(currentUserProvider);
  if (uid == null) return Stream.empty();
  return ref.watch(chatRepositoryProvider).watchConversations(uid);
});

final myNotificationsProvider = StreamProvider<List<AppNotification>>((ref) {
  final uid = ref.watch(currentUserProvider);
  if (uid == null) return Stream.empty();
  return ref.watch(notificationRepositoryProvider).watch(uid);
});

final unreadNotificationsProvider = StreamProvider<int>((ref) {
  final uid = ref.watch(currentUserProvider);
  if (uid == null) return Stream.value(0);
  return ref.watch(notificationRepositoryProvider).watchUnreadCount(uid);
});

final mySavedProvider = StreamProvider<List<SavedResource>>((ref) {
  final uid = ref.watch(currentUserProvider);
  if (uid == null) return Stream.empty();
  return ref.watch(resourceRepositoryProvider).watchSaved(uid);
});

final incomingSwapsProvider = StreamProvider<List<SwapRequest>>((ref) {
  final uid = ref.watch(currentUserProvider);
  if (uid == null) return Stream.empty();
  return ref.watch(swapRepositoryProvider).watchIncoming(uid);
});

final outgoingSwapsProvider = StreamProvider<List<SwapRequest>>((ref) {
  final uid = ref.watch(currentUserProvider);
  if (uid == null) return Stream.empty();
  return ref.watch(swapRepositoryProvider).watchOutgoing(uid);
});

/// A single resource by id, watched live (used by the detail screen).
final resourceByIdProvider =
    StreamProvider.family<Resource?, String>((ref, id) {
  return ref
      .watch(firestoreProvider)
      .collection(AppConstants.resourcesCol)
      .doc(id)
      .snapshots()
      .map((d) => d.exists ? Resource.fromJson(d.data()!) : null);
});

/// Live conversation document.
final conversationProvider =
    StreamProvider.family<Conversation?, String>((ref, id) {
  return ref
      .watch(firestoreProvider)
      .collection(AppConstants.conversationsCol)
      .doc(id)
      .snapshots()
      .map((d) => d.exists ? Conversation.fromJson(d.data()!) : null);
});

/// Paginated message history for a conversation (newest first).
final messagesProvider =
    StreamProvider.family<List<Message>, String>((ref, conversationId) {
  return ref.watch(chatRepositoryProvider).watchMessages(conversationId);
});

/// A user's public resources by owner id.
final userResourcesProvider =
    StreamProvider.family<List<Resource>, String>((ref, ownerId) {
  return ref.watch(resourceRepositoryProvider).watchByOwner(ownerId);
});

/// A public user profile by id, watched live.
final userByIdProvider =
    StreamProvider.family<AppUser?, String>((ref, id) {
  return ref
      .watch(firestoreProvider)
      .collection(AppConstants.usersCol)
      .doc(id)
      .snapshots()
      .map((d) => d.exists ? AppUser.fromJson(d.data()!) : null);
});

/// Answers for a question, ordered by upvotes.
final answersProvider =
    StreamProvider.family<List<Answer>, String>((ref, questionId) {
  return ref.watch(communityRepositoryProvider).watchAnswers(questionId);
});

/// A single question by id, watched live.
final questionByIdProvider =
    StreamProvider.family<Question?, String>((ref, id) {
  return ref
      .watch(firestoreProvider)
      .collection(AppConstants.questionsCol)
      .doc(id)
      .snapshots()
      .map((d) => d.exists ? Question.fromJson(d.data()!) : null);
});
