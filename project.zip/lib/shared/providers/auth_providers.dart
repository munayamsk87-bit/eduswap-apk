import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../features/auth/data/auth_repository.dart';
import '../models/app_user.dart';

/// Raw Firebase auth state. The router redirects on this.
final authStateProvider = StreamProvider<User?>((ref) {
  return ref.watch(authRepositoryProvider).authStateChanges();
});

/// The signed-in user's uid, or null.
final currentUserProvider = Provider<String?>((ref) {
  return ref.watch(authStateProvider).valueOrNull?.uid;
});

/// Live profile document for the signed-in user.
final appUserProvider = StreamProvider<AppUser?>((ref) {
  final uid = ref.watch(currentUserProvider);
  if (uid == null) return Stream.empty();
  return ref.watch(authRepositoryProvider).watchProfile(uid);
});

/// Privileged role comes from Firebase custom claims — never from a profile
/// field a user could edit. The profile `role` is for display only.
final isAdminProvider = FutureProvider<bool>((ref) async {
  final user = ref.watch(authStateProvider).valueOrNull;
  if (user == null) return false;
  final token = await user.getIdTokenResult(true);
  return token.claims?['admin'] == true;
});
